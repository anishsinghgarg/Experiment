package com.platterpayservices.model;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

public class EndpointDataModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer epId;
	private String epName, epMrchntId, epUserName, epPass, epContact, epEmail, epLogoName, accountNo;
	public Integer getEpId() {
		return epId;
	}
	public void setEpId(Integer epId) {
		this.epId = epId;
	}
	public String getEpName() {
		return epName;
	}
	public void setEpName(String epName) {
		this.epName = epName;
	}
	public String getEpMrchntId() {
		return epMrchntId;
	}
	public void setEpMrchntId(String epMrchntId) {
		this.epMrchntId = epMrchntId;
	}
	public String getEpUserName() {
		return epUserName;
	}
	public void setEpUserName(String epUserName) {
		this.epUserName = epUserName;
	}
	public String getEpPass() {
		return epPass;
	}
	public void setEpPass(String epPass) {
		this.epPass = epPass;
	}
	public String getEpContact() {
		return epContact;
	}
	public void setEpContact(String epContact) {
		this.epContact = epContact;
	}
	public String getEpEmail() {
		return epEmail;
	}
	public void setEpEmail(String epEmail) {
		this.epEmail = epEmail;
	}
	public String getEpLogoName() {
		return epLogoName;
	}
	public void setEpLogoName(String epLogoName) {
		this.epLogoName = epLogoName;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	
}
