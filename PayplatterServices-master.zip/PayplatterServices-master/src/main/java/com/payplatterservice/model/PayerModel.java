package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "payer_master")
public class PayerModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer id;
	private String firstName;
	private String lastName;
	private String emailId;
	private String contact;
	private String add1;
	private String add2;
	private String city;
	private String state;
	private String country;
	private String zip;
	private String status,registration_no,payerDevice_ID;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer serviceId;

	@Column(columnDefinition = "INT(11) default '1'")
	private Integer payer_level_id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "createdDate", nullable = false, columnDefinition = "TIMESTAMP default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP")
	private Date createdDate = new Date();

	/*
	 * @OneToMany(mappedBy = "payerBean") List<PayerMerchantModel>
	 * payerMerchantList;
	 */

	@Transient
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer personnelID;

	@Transient
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer merchantID;

	@Transient
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer menuID;

	@Transient
	@JsonSerialize(using = ToStringSerializer.class)
	private String menuName;
	
	@Transient
	private String venueBookingType;
	
	@Transient
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer seqNo;
	
	@Transient
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer mapping_id;
	
	@Transient
	@JsonSerialize(using=ToStringSerializer.class)
	private String searchKey;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getAdd1() {
		return add1;
	}

	public void setAdd1(String add1) {
		this.add1 = add1;
	}

	public String getAdd2() {
		return add2;
	}

	public void setAdd2(String add2) {
		this.add2 = add2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public Integer getPayer_level_id() {
		return payer_level_id;
	}

	public void setPayer_level_id(Integer payer_level_id) {
		this.payer_level_id = payer_level_id;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getPersonnelID() {
		return personnelID;
	}

	public void setPersonnelID(Integer personnelID) {
		this.personnelID = personnelID;
	}

	public Integer getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(Integer merchantID) {
		this.merchantID = merchantID;
	}

	public Integer getMenuID() {
		return menuID;
	}

	public void setMenuID(Integer menuID) {
		this.menuID = menuID;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public Integer getMapping_id() {
		return mapping_id;
	}

	public void setMapping_id(Integer mapping_id) {
		this.mapping_id = mapping_id;
	}

	public String getRegistration_no() {
		return registration_no;
	}

	public void setRegistration_no(String registration_no) {
		this.registration_no = registration_no;
	}

	public String getVenueBookingType() {
		return venueBookingType;
	}

	public void setVenueBookingType(String venueBookingType) {
		this.venueBookingType = venueBookingType;
	}

	public String getSearchKey() {
		return searchKey;
	}

	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}

	public String getPayerDevice_ID() {
		return payerDevice_ID;
	}

	public void setPayerDevice_ID(String payerDevice_ID) {
		this.payerDevice_ID = payerDevice_ID;
	}

}
