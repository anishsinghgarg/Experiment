package com.payplatterservice.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payplatterservice.configuration.DBConnection;
import com.payplatterservice.configuration.ReportDBConnection;
import com.payplatterservice.model.SampleFormModel;
import com.payplatterservice.model.TempTableMISDataEcoTouristCenterModel;
import com.payplatterservice.model.TempTableMISDataHorticultureAppModel;
import com.payplatterservice.model.TempTableModelTrakingPayment;

@Repository
public class TransitportFormServicesImpl implements TransitportFormServices {

	private static final Logger logger = Logger.getLogger(TransitportFormServicesImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public SampleFormModel saveFormDetails(SampleFormModel model) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.save(model);
			session.getTransaction().commit();
			return model;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public SampleFormModel updateFormDetails(SampleFormModel model) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.update(model);
			session.getTransaction().commit();
			return model;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public TempTableModelTrakingPayment saveTempTableFormDetails(TempTableModelTrakingPayment model) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.save(model);
			session.getTransaction().commit();
			return model;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public TempTableMISDataEcoTouristCenterModel saveTempTableForMISFormDetails(
			TempTableMISDataEcoTouristCenterModel ecoTouristCenterPayment) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.save(ecoTouristCenterPayment);
			session.getTransaction().commit();
			return ecoTouristCenterPayment;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public int getMaximumFormId() {
		Session session = sessionFactory.openSession();
		int id = 0;
		try {
			id = (Integer) session.createQuery("select max(formId) from SampleFormModel").uniqueResult() + 1;
			System.out.println("Last ID of Transaction Table is =" + (id - 1));
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Updating Form ID =" + id);
		return id;
	}

	@Override
	public int getMaximumTouristCenterFormId() {
		Session session = sessionFactory.openSession();
		int id = 0;
		try {
			id = (Integer) session.createQuery("select max(id) from TempTableMISDataEcoTouristCenterModel")
					.uniqueResult() + 1;
			System.out.println("Last ID of TempTableMISDataEcoTouristCenterModel Table is =" + (id - 1));
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("TempTableMISDataEcoTouristCenterModel Form ID =" + id);
		return id;
	}

	@Override
	public int getMaximumTrekkingFormId() {
		Session session = sessionFactory.openSession();
		int id = 0;
		try {
			id = (Integer) session.createQuery("select max(id) from TempTableModelTrakingPayment").uniqueResult() + 1;
			System.out.println("Last ID of TempTableModelTrakingPayment Table is =" + (id - 1));
		} catch (Exception e) {
			e.printStackTrace();
			id = 1;
		}
		System.out.println("TempTableModelTrakingPayment Form ID =" + id);
		return id;
	}

	@Override
	public TempTableMISDataHorticultureAppModel saveFormData(TempTableMISDataHorticultureAppModel model) {
		ReportDBConnection conn = new ReportDBConnection();
		Connection con = null;
		Statement stmt = null;
		int counter = 0;
		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		try {
			String query = "insert into reports_tb_14(`Contact`, `adultCount`, `childCount`, `cameraCount`, `videoCamera`, `twoWheeler`,`fourWheeler`,"
					+ " `maxWheeler`, `cashAmount`, `cardAmount`, `timeOfBillGenerated`, `billNo`,`walkerCount`, `heavyShootingCount`, `rentRecoveryCount`, `additionalParam`,`mId`,`ppTxnId`,`heavyShootingAmount`,`rentRecoveryAmount`)"
					+ " values('" + model.getContact() + "','" + model.getAdultCount() + "','" + model.getChildCount()
					+ "','" + model.getCameraCount() + "','" + model.getVideoCamera() + "','" + model.getTwoWheeler()
					+ "'," + "'" + model.getFourWheeler() + "','" + model.getMaxWheeler() + "','"
					+ model.getCashAmount() + "','" + model.getCardAmount() + "','" + model.getTimeOfBillGenerated()
					+ "','" + model.getBillNo() + "'," + "'" + model.getWalkerCount() + "','"
					+ model.getHeavyShootingCount() + "','" + model.getRentRecoveryCount() + "','"
					+ model.getAdditionalParam() + "','" + model.getmId() + "','" + model.getPpTxnId() + "','"
					+ model.getHeavyShootingAmount() + "','" + model.getRentRecoveryAmount() + "')";

			logger.info("Sql Query " + query);
			counter = stmt.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
			logger.info("Counter value is :::::::::" + counter);
			if (counter == 1) {
				return model;
			} else {
				return null;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public Integer getMaximumHorticultureId() {
		ReportDBConnection conn = new ReportDBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		try {
			String sql = "select max(id) from temp_tp_54";
			logger.info("SQL Query get Transaction Details  ::" + sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Integer maxID = rs.getInt(1);
				maxID = maxID + 1;
				System.out.println(maxID);

			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();

			}
			try {
				rs.close();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return null;
	}

	@Override
	public TempTableMISDataHorticultureAppModel getHorticultureAppReceiptCount(
			TempTableMISDataHorticultureAppModel model) {
		ReportDBConnection conn = new ReportDBConnection();
		Connection con = null;
		Statement stmt = null;
		String fromDate = null;
		String toDate = null;
		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		try {
			/*
			 * try {
			 * 
			 * SimpleDateFormat sdfDate = new SimpleDateFormat(
			 * "yyyy-MM-dd HH:mm:ss");// dd/MM/yyyy Date now = new Date();
			 * String strDate = sdfDate.format(now); logger.info("Date :: " +
			 * strDate); toDate = strDate;
			 * 
			 * strDate = strDate.substring(0, 10); logger.info(strDate);
			 * fromDate = strDate.concat(" 00:00:00"); logger.info(
			 * "Final From Date :: " + fromDate + " & To Date " + toDate);
			 * 
			 * } catch (Exception e) { // TODO: handle exception }
			 */
			String sql = "SELECT count(id) as totalCount, SUM(adultCount) as adultCount,SUM(childCount) as childCount,SUM(cameraCount) as cameraCount,"
					+ "SUM(videoCamera) as videoCamera,SUM(twoWheeler) as twoWheeler,SUM(fourWheeler) as fourWheeler"
					+ ",SUM(maxWheeler) as maxWheeler,SUM(cashAmount) as cashAmount,SUM(cardAmount) as cardAmount,"
					+ "SUM(walkerCount) as walkerCount,SUM(heavyShootingCount) as heavyShootingCount,SUM(heavyShootingAmount) as heavyShootingAmount,SUM(rentRecoveryAmount) as rentRecoveryAmount,SUM(rentRecoveryCount) as rentRecoveryCount FROM pp_reports.reports_tb_14 where mId='"
					+ model.getmId() + "' AND timeOfBillGenerated BETWEEN '" + model.getTimeOfBillGenerated()
					+ "' AND '" + model.getAdditionalParam() + "'";
			logger.info("SQL Query get Receipt Count  ::" + sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {

				model.setTotalCount(rs.getString("totalCount"));
				model.setAdultCount(rs.getString("adultCount"));
				model.setChildCount(rs.getString("childCount"));
				model.setCameraCount(rs.getString("cameraCount"));
				model.setVideoCamera(rs.getString("videoCamera"));
				model.setTwoWheeler(rs.getString("twoWheeler"));
				model.setFourWheeler(rs.getString("fourWheeler"));
				model.setMaxWheeler(rs.getString("maxWheeler"));
				model.setCashAmount(rs.getString("cashAmount"));
				model.setCardAmount(rs.getString("cardAmount"));
				model.setWalkerCount(rs.getString("walkerCount"));
				model.setHeavyShootingCount(rs.getString("heavyShootingCount"));
				model.setRentRecoveryCount(rs.getString("rentRecoveryCount"));
				model.setHeavyShootingAmount(rs.getString("heavyShootingAmount"));
				model.setRentRecoveryAmount(rs.getString("rentRecoveryAmount"));
			}
			return model;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();

			}
			try {
				rs.close();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

	}

	@Override
	public TempTableMISDataHorticultureAppModel getHorticultureAppLastBillNo(
			TempTableMISDataHorticultureAppModel model) {
		ReportDBConnection conn = new ReportDBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		try {

			String sql = "SELECT billNo,timeOfBillGenerated FROM pp_reports.reports_tb_14 WHERE mId='"+model.getmId()+"' ORDER by id desc limit 1";
			logger.info("SQL Query get Receipt Count  ::" + sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {

				model.setBillNo(rs.getString("billNo"));
				model.setTimeOfBillGenerated(rs.getString("timeOfBillGenerated"));

			}
			return model;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();

			}
			try {
				rs.close();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

	}
}
