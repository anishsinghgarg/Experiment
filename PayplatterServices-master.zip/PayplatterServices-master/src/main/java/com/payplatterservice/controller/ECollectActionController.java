package com.payplatterservice.controller;

import java.io.Serializable;
import java.util.regex.Pattern;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.payplatterservice.model.ECollectModel;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PlatterPayTransactionBean;
import com.payplatterservice.security.Encryption;
import com.payplatterservice.service.ECollectService;
import com.payplatterservice.service.TransactionsService;

@RestController
public class ECollectActionController implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(ECollectActionController.class);
	@Autowired
	TransactionsService services;

	@Autowired
	ECollectService eCollectService;

	@RequestMapping(value = "/PaymentTransferInquiryRequest/", method = RequestMethod.POST, produces = "application/json")
	public String PaymentTransferInquiryRequest(@RequestBody ECollectModel model, UriComponentsBuilder ucBuilder) {
		String status = null;
		String statusmsg = null;
		String StatusCode = null;
		String descryptCodeStr = "";
		String tokenNO = null;
		String txnAmount = null;
		String mobNo = null;
		String txnDate = null;
		
		try {
			logger.info("Transaction Validation Request ::::");

			PlatterPayTransactionBean ppBean = new PlatterPayTransactionBean();
			Encryption encCode = new Encryption();

			logger.info("Final Enc Code ::" + model.getInquiryRequest());
			try {
				String authkey = "zcjrujdGPEqqBYHG";
				String authiv = "DNmnGWhWeaj9wG6f";
				descryptCodeStr = encCode.decrypt(authkey, authiv, model.getInquiryRequest());
				logger.info("Encrypted Code ::" + descryptCodeStr);

			} catch (Exception e) {
				e.printStackTrace();
			}
			if (descryptCodeStr != null) {
				logger.info("Descripted Value is not null :::::");
				String[] plainTextValue = descryptCodeStr.split(Pattern.quote("|"));
				tokenNO = plainTextValue[0];
				tokenNO = tokenNO.trim();
				logger.info("Token NUmber ::" + tokenNO);
				txnAmount = plainTextValue[1];
				mobNo = plainTextValue[2];
				txnDate = plainTextValue[3];
				logger.info("Got Token No =" + tokenNO + " and Amount =" + txnAmount);

				try {

					ppBean = eCollectService.txnRequestValidation(tokenNO, txnAmount, mobNo);
					logger.info("TXN ID ::" + ppBean.getTxnId());
					if (ppBean != null && ppBean.getStatus().equalsIgnoreCase("PENDING")) {
						logger.info("Bean not null and Transaction status is PENDING");
						status = "SUCCESS";
						StatusCode = "0000";
						statusmsg = "This Customer Exist";
						return "{\"Status\":\"" + status + "\",\"StatusCode\":\"" + StatusCode
								+ "\",\"StatusMessage\":\"" + statusmsg + "\",\"Transaction_Date\":\""
								+ ppBean.getTransDate() + "\",\"TokenNO\":\"" + ppBean.getChallanNo()
								+ "\",\"VirtualAccountNO\":\"" + ppBean.getChallanNo()
								+ "\",\"PayerName\":\"" + ppBean.getPayeeFirstName() + "" + ppBean.getPayeeLstName()
								+ "\",\"Trans_Amount\":\"" + ppBean.getActAmount() + "\"}";
					} else {
						logger.info("Bean not null or Transaction status is SUCCESS");
						status = "Fail";
						StatusCode = "0005";
						if ("SUCCESS".equalsIgnoreCase(ppBean.getStatus())) {
							statusmsg = "Transaction Already Complited :";
						} else if ("conflict".equalsIgnoreCase(ppBean.getStatus())) {
							statusmsg = "Contact Number or Email ID has been Changed";
						} else {
							statusmsg = "DUPLICATE_TOKEN";
						}

						return "{\"Status\":\"" + status + "\",\"StatusCode\":\"" + StatusCode
								+ "\",\"StatusMessage\":\"" + statusmsg + "\"}";
					}

				} catch (NullPointerException ex) {
					status = "Fail";
					StatusCode = "0003";

					statusmsg = "INVALID_TOKEN or INCorrect value";
					ex.printStackTrace();
					return "{\"Status\":\"" + status + "\",\"StatusCode\":\"" + StatusCode + "\",\"StatusMessage\":\""
							+ statusmsg + "\"}";
				} catch (Exception e) {
					status = "Fail";
					StatusCode = "9999";
					statusmsg = "Something Wrong";
					e.printStackTrace();
					return "{\"Status\":\"" + status + "\",\"StatusCode\":\"" + StatusCode + "\",\"StatusMessage\":\""
							+ statusmsg + "\"}";
				}
			} else {
				logger.info("Descripted Value is null :::::");
				status = "Fail";
				StatusCode = "0003";
				statusmsg = "INVALID_TOKEN or INCorrect value";

				return "{\"Status\":\"" + status + "\",\"StatusCode\":\"" + StatusCode + "\",\"StatusMessage\":\""
						+ statusmsg + "\"}";
			}

		} catch (ArrayIndexOutOfBoundsException ex) {

			status = "Fail";
			StatusCode = "0003";

			statusmsg = "INVALID_TOKEN or INCorrect value";
			ex.printStackTrace();
			return "{\"Status\":\"" + status + "\",\"StatusCode\":\"" + StatusCode + "\",\"StatusMessage\":\""
					+ statusmsg + "\"}";
		} catch (Exception e) {
			status = "Fail";
			StatusCode = "0003";

			statusmsg = "INVALID_TOKEN or INCorrect value";
			e.printStackTrace();
			return "{\"Status\":\"" + status + "\",\"StatusCode\":\"" + StatusCode + "\",\"StatusMessage\":\""
					+ statusmsg + "\"}";
		}
	}

	@RequestMapping(value = "/PaymentTransferNotifyRequest/", method = RequestMethod.POST, produces = "application/json")
	public String PaymentTransferNotifyRequest(@RequestBody ECollectModel model, UriComponentsBuilder ucBuilder) {

		logger.info("Transaction Notify Request ::::");
		PlatterPayTransactionBean ppBean = new PlatterPayTransactionBean();
		Encryption encCode = new Encryption();

		String returnMsg = null;
		String StatusCode = null;
		String statusmsg = null;
		Boolean exist = false;
		String descryptCodeStr = "";

		String challanNO = null;
		String txnAmount = null;
		String txnCompliteDate = null;
		String payAmount = null;
		String payode = null;
		String payStatus = null;
		// Double payAmount=null;
		String RMTR_FULL_NAME = null;
		String RMTR_BANK_NAME = null;
		String RMTR_ACCOUNT_TYPE = null;
		String RMTR_ACCOUNT_IFSC = null;
		String RMTR_ACCOUNT_NUMBER = null;
		String BENE_FULL_NAME = null;
		String BENE_ACCOUNT_TYPE = null;
		String VIRTUAL_ACCOUNT_NO = null;
		String BENE_ACCOUNT_NO = null;
		String BENE_ACCOUNT_IFSC = null;
		String BENE_BANK_NAME = null;

		try {

			logger.info("Final Enc Code ::" + model.getNotifyRequest());
			try {

				String authkey = "zcjrujdGPEqqBYHG";
				String authiv = "DNmnGWhWeaj9wG6f";

				descryptCodeStr = encCode.decrypt(authkey, authiv, model.getNotifyRequest());
				descryptCodeStr = descryptCodeStr.replaceAll("[\\-\\+\\.\\/^:,!@#&*()_{}<>?\"\']","");
				descryptCodeStr = descryptCodeStr.replaceAll("\\\\", "NA");

				logger.info("Encrypted Code ::" + descryptCodeStr);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (descryptCodeStr != null) {
				logger.info("Descripted Value is not null ::");
				String[] ChallNoAndAmount = descryptCodeStr.split(Pattern.quote("|"));

				try {
					if (ChallNoAndAmount != null) {
						challanNO = ChallNoAndAmount[0].trim();
						challanNO = challanNO.trim().trim();
						txnAmount = ChallNoAndAmount[1].trim();
						txnCompliteDate = ChallNoAndAmount[2].trim();
						payAmount = ChallNoAndAmount[3].trim();
						payode = ChallNoAndAmount[4].trim();
						payStatus = ChallNoAndAmount[5].trim();
						RMTR_BANK_NAME = ChallNoAndAmount[6].trim();
						RMTR_ACCOUNT_TYPE = ChallNoAndAmount[7].trim();
						RMTR_ACCOUNT_NUMBER = ChallNoAndAmount[8].trim();
						RMTR_FULL_NAME = ChallNoAndAmount[9].trim();
						RMTR_ACCOUNT_IFSC = ChallNoAndAmount[10].trim();
						BENE_FULL_NAME = ChallNoAndAmount[11].trim();
						BENE_ACCOUNT_TYPE = ChallNoAndAmount[12].trim();
						VIRTUAL_ACCOUNT_NO = ChallNoAndAmount[13].trim();
						BENE_ACCOUNT_NO = ChallNoAndAmount[14].trim();
						BENE_ACCOUNT_IFSC = ChallNoAndAmount[15].trim();
						BENE_BANK_NAME = ChallNoAndAmount[16].trim();
					} else {
						challanNO = ChallNoAndAmount[0].trim();
						challanNO = challanNO.trim();
						txnAmount = ChallNoAndAmount[1].trim();
						txnCompliteDate = ChallNoAndAmount[2].trim();
						payAmount = ChallNoAndAmount[3].trim();
						payode = ChallNoAndAmount[4].trim();
						payStatus = ChallNoAndAmount[5].trim();
						RMTR_BANK_NAME = ChallNoAndAmount[6].trim();
						RMTR_ACCOUNT_TYPE = ChallNoAndAmount[7].trim();
						RMTR_ACCOUNT_NUMBER = ChallNoAndAmount[8].trim();
						RMTR_FULL_NAME = ChallNoAndAmount[9].trim();
						RMTR_ACCOUNT_IFSC = ChallNoAndAmount[10].trim();
						BENE_FULL_NAME = ChallNoAndAmount[11].trim();
						VIRTUAL_ACCOUNT_NO = ChallNoAndAmount[13].trim();

					}

				} catch (Exception e) {
					// TODO: handle exception
					challanNO = ChallNoAndAmount[0].trim();
					challanNO = challanNO.trim();
					txnAmount = ChallNoAndAmount[1].trim();
					txnCompliteDate = ChallNoAndAmount[2].trim();
					payAmount = ChallNoAndAmount[3].trim();
					payode = ChallNoAndAmount[4].trim();
					payStatus = ChallNoAndAmount[5].trim();
					RMTR_BANK_NAME = ChallNoAndAmount[6].trim();
					RMTR_ACCOUNT_TYPE = ChallNoAndAmount[7].trim();
					RMTR_ACCOUNT_NUMBER = ChallNoAndAmount[8].trim();
					RMTR_FULL_NAME = ChallNoAndAmount[9].trim();
					RMTR_ACCOUNT_IFSC = ChallNoAndAmount[10].trim();
					BENE_FULL_NAME = ChallNoAndAmount[11].trim();
					VIRTUAL_ACCOUNT_NO = ChallNoAndAmount[13].trim();
				}
				/*
				 * RMTR_TO_BENE_NOTE= ChallNoAndAmount[16];
				 */
				logger.info("Got Token No =" + challanNO + ", Amount =" + txnAmount + ", Transaction Com Date="
						+ txnCompliteDate + ", Paye Amount=" + payAmount + ", PayMode =" + payode + ", PayStatus="
						+ payStatus + ", RMTR Bank Name=" + RMTR_BANK_NAME + ", RMTR ACCOUNT TYPE=" + RMTR_ACCOUNT_TYPE
						+ ", RMTR_ACCOUNT_NUMBER=" + RMTR_ACCOUNT_NUMBER + ", RMTR FULL NAME=" + RMTR_FULL_NAME
						+ ", RMTR ACCOUNT IFSC=" + RMTR_ACCOUNT_IFSC + ", BENE FULL NAME=" + BENE_FULL_NAME
						+ ", BENE ACCOUNT TYPE=" + BENE_ACCOUNT_TYPE + ", VIRTUAL ACCOUNT NO=" + VIRTUAL_ACCOUNT_NO
						+ ", BENE ACCOUNT NO=" + BENE_ACCOUNT_NO + ", BENE ACCOUNT IFSC=" + BENE_ACCOUNT_IFSC);

				try {
					returnMsg = eCollectService.updateTransaction(challanNO, payStatus, payStatus, payode, txnCompliteDate,
							BENE_BANK_NAME, BENE_ACCOUNT_NO, BENE_ACCOUNT_NO, BENE_FULL_NAME, BENE_ACCOUNT_IFSC,
							RMTR_FULL_NAME, RMTR_ACCOUNT_NUMBER, RMTR_BANK_NAME, RMTR_ACCOUNT_IFSC, VIRTUAL_ACCOUNT_NO);

					// String
					// sql="UPDATE platterpay.challan_detail SET challan_status='SUCCESS',challan_status_ws='ATMPT',Pay_Mode='NEF',cheqDate='',Bank_Name='BNENAME',Client_Account_Number='BNEAccNO',Credit_AccountNo='BNEAccNo',beneFiciaryName='Ravi',ifscCode='BNEIFC',remitter_name='ABC',remitter_acc_no='4567',remitter_bank_name='HDFC',remitter_bank_ifsc='HD12345'where challanNo=''";
					if (returnMsg.equalsIgnoreCase("SUCCESS")) {
						StatusCode = "0000";
						statusmsg = "Transaction Updated Successfully";
						return "{\"StatusCode\":\"" + StatusCode + "\" , \"StatusMSG\":\"" + statusmsg + "\" }";
					} else {
						logger.info("Some Incorrect value or parameter in request");
						StatusCode = "0003";
						statusmsg = "INVALID_TOKEN or INCorrect value";
						return "{\"StatusCode\":\"" + StatusCode + "\" , \"StatusMSG\":\"" + statusmsg + "\" }";
					}
				} catch (Exception e) {
					logger.info("In Catch Block");
					StatusCode = "9999";
					statusmsg = "Server Error";

					e.printStackTrace();
					return "{\"StatusCode\":\"" + StatusCode + "\" , \"StatusMSG\":\"" + statusmsg + "\" }";
				}

			} else {
				logger.info("Some Incorrect value or parameter in request");
				StatusCode = "0003";
				statusmsg = "INVALID_TOKEN or INCorrect value";
				return "{\"StatusCode\":\"" + StatusCode + "\" , \"StatusMSG\":\"" + statusmsg + "\" }";
			}
		} catch (Exception e) {
			logger.info("Some Incorrect value or parameter in request");
			StatusCode = "9999";
			statusmsg = "Server Error";
			e.printStackTrace();
			return "{\"StatusCode\":\"" + StatusCode + "\" , \"StatusMSG\":\"" + statusmsg + "\" }";
		}

	}

}
