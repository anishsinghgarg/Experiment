package com.payplatterservice.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayPlatterCentralOutStandingModel;
import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PayerParameterModel;
import com.payplatterservice.model.PayplatterCentralInvoicesModel;
import com.payplatterservice.model.PersonnelAppointmentModel;
import com.payplatterservice.model.SearchKeyModel;
import com.payplatterservice.model.TransitportPersonnelAvailabilityModel;
import com.payplatterservice.model.TransitportPersonnelModel;

public interface MerchantService {

	MerchantsModel getMerchantDetailsByID(MerchantsModel model);

	PayerParameterModel createInvoicesForPayer(PayerParameterModel payerPramModel);

	PayPlatterCentralOutStandingModel getTotalOutstandingDetailsByPayerIDMerchantId(PayerModel prModel,
			MerchantsModel merModel);

	Integer getlastInvoiceNoClient();

	PayplatterCentralInvoicesModel createInvoiceInCentralInvoicesTable(PayplatterCentralInvoicesModel centralInvoices);

	PayerParameterModel updateInvoiceRecord(PayerParameterModel payerPramModel);

	List<MerchantConfigPreferencesModel> getAllPreferencesBasedOnMerchant(String key,String value);

	List<Object[]> getMerchantTransactionList(MerchantsModel model);

	List<TransitportPersonnelModel> getMerchantPersonnelList(Integer merchantID);

	PersonnelAppointmentModel getMerchantAppointmentDetails(Integer personnel_id);

	PersonnelAppointmentModel getMerchantAppointmentDetails(ArrayList<Integer> tokenId);

	List<MerchantConfigPreferencesModel> getSearchApperancesPreferences(String key, String value);

	


	 List<MerchantsModel> getMerchantListBasedOnSearch(String key, Integer setIndID) ;

	

	
	

	

}
