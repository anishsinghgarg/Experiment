package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;


@Entity
@Table(name = "transitport_asset_reservations")
public class TransitportAssetReservationsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer reservation_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer asset_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer availability_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer asset_category_id, asset_type_id, merchant_id;
	private String first_name, last_name, contact, email;
	private Date reservationDate;
	private String status;
	private String comment;
	private Date reservationDateFrom, reservationDateTo;
	private String ismultiSlot; //Flag to separate multi-slot flow
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer availability_id_end;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer form_instance_id;
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	private TransitportAssetsModel asset_data;
	/*@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true,fetch=FetchType.EAGER)
	private TransitportAssetAvailabilityModel availability_data;*/
	
	private String asset_ids;
	@Transient
	private String dateFrom,dateTo;
	@Transient
	private TransitportAssetsModel assetData;
	
	@Transient	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="transitport_asset_reservations_transitport_asset_availability", joinColumns={@JoinColumn(referencedColumnName="reservation_id")}
    , inverseJoinColumns={@JoinColumn(referencedColumnName="availability_id")}) 
    private Set<TransitportAssetAvailabilityModel> multi_availability_data=new HashSet<TransitportAssetAvailabilityModel>(0); //Added to introduce multislot reservation without breaking current flow

	public Integer getReservation_id() {
		return reservation_id;
	}

	public void setReservation_id(Integer reservation_id) {
		this.reservation_id = reservation_id;
	}

	public Integer getAsset_id() {
		return asset_id;
	}

	public void setAsset_id(Integer asset_id) {
		this.asset_id = asset_id;
	}

	public Integer getAvailability_id() {
		return availability_id;
	}

	public void setAvailability_id(Integer availability_id) {
		this.availability_id = availability_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getReservationDate() {
		return reservationDate;
	}

	public void setReservationDate(Date reservationDate) {
		this.reservationDate = reservationDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Date getReservationDateFrom() {
		return reservationDateFrom;
	}

	public void setReservationDateFrom(Date reservationDateFrom) {
		this.reservationDateFrom = reservationDateFrom;
	}

	public Date getReservationDateTo() {
		return reservationDateTo;
	}

	public void setReservationDateTo(Date reservationDateTo) {
		this.reservationDateTo = reservationDateTo;
	}

	public String getIsmultiSlot() {
		return ismultiSlot;
	}

	public void setIsmultiSlot(String ismultiSlot) {
		this.ismultiSlot = ismultiSlot;
	}

	public Integer getAvailability_id_end() {
		return availability_id_end;
	}

	public void setAvailability_id_end(Integer availability_id_end) {
		this.availability_id_end = availability_id_end;
	}

	public Integer getForm_instance_id() {
		return form_instance_id;
	}

	public void setForm_instance_id(Integer form_instance_id) {
		this.form_instance_id = form_instance_id;
	}

	public TransitportAssetsModel getAsset_data() {
		return asset_data;
	}

	public void setAsset_data(TransitportAssetsModel asset_data) {
		this.asset_data = asset_data;
	}

	/*public TransitportAssetAvailabilityModel getAvailability_data() {
		return availability_data;
	}

	public void setAvailability_data(TransitportAssetAvailabilityModel availability_data) {
		this.availability_data = availability_data;
	}*/
	//@ManyToMany(mappedBy="availability_id")
	public Set<TransitportAssetAvailabilityModel> getMulti_availability_data() {
		return multi_availability_data;
	}

	public void setMulti_availability_data(Set<TransitportAssetAvailabilityModel> multi_availability_data) {
		this.multi_availability_data = multi_availability_data;
	}

	public TransitportAssetsModel getAssetData() {
		return assetData;
	}

	public void setAssetData(TransitportAssetsModel assetData) {
		this.assetData = assetData;
	}

	public String getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}

	public String getDateTo() {
		return dateTo;
	}

	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}

	public Integer getAsset_category_id() {
		return asset_category_id;
	}

	public void setAsset_category_id(Integer asset_category_id) {
		this.asset_category_id = asset_category_id;
	}

	public Integer getAsset_type_id() {
		return asset_type_id;
	}

	public void setAsset_type_id(Integer asset_type_id) {
		this.asset_type_id = asset_type_id;
	}

	public Integer getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}

	public String getAsset_ids() {
		return asset_ids;
	}

	public void setAsset_ids(String asset_ids) {
		this.asset_ids = asset_ids;
	}


}
