package com.payplatterservice.model;

import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

public class MerchantServicesDetailsBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonSerialize(using=ToStringSerializer.class)	
	private Integer mid;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer service_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private String servicesName;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer form_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer context_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer pgid;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer payment_flow_id;
	
	@JsonSerialize(using=ToStringSerializer.class)
	private String status;
	
	public Integer getMid() {
		return mid;
	}
	public void setMid(Integer mid) {
		this.mid = mid;
	}
	public Integer getService_id() {
		return service_id;
	}
	public void setService_id(Integer service_id) {
		this.service_id = service_id;
	}
	public String getServicesName() {
		return servicesName;
	}
	public void setServicesName(String servicesName) {
		this.servicesName = servicesName;
	}
	public Integer getForm_id() {
		return form_id;
	}
	public void setForm_id(Integer form_id) {
		this.form_id = form_id;
	}
	public Integer getContext_id() {
		return context_id;
	}
	public void setContext_id(Integer context_id) {
		this.context_id = context_id;
	}
	public Integer getPgid() {
		return pgid;
	}
	public void setPgid(Integer pgid) {
		this.pgid = pgid;
	}
	public Integer getPayment_flow_id() {
		return payment_flow_id;
	}
	public void setPayment_flow_id(Integer payment_flow_id) {
		this.payment_flow_id = payment_flow_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}



}
