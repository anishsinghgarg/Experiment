package com.platterpayservices.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


import org.hibernate.annotations.GenericGenerator;

public class ClientDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer clientId;
	@Column(unique = true)
	private String clientCode;
	private String clientName, clientContact, clientEmail, clientUsername, clientPass;
	private String successReturnURL, failureReturnURL;
	private String clientKey, clientIV;
	private String authFlag, authType;
	private Integer clientTypeId;

	private String bankClientParam;

	@Column(columnDefinition = "VARCHAR(255) default 'N'")
	private String bypassOptionsFlag;

	@Column(columnDefinition = "varchar(255) default 'Y'")
	private String redirect_to_new_layout;

	@Column(columnDefinition = "varchar(255) default 'No'")
	private String statusEnquiryFlag;

	@Column(columnDefinition = "varchar(255) default 'No'")
	private String is_refund_applicable;

	@Column(columnDefinition = "varchar(255) default 'N'")
	private String applicable_for_challan;

	@Column(columnDefinition = "INT(11) default '0'")
	private Integer isApplication;

	/*@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "client_application", joinColumns = @JoinColumn(name = "clientId"), inverseJoinColumns = @JoinColumn(name = "appId"))
	private Set<ApplicationDataBean> application;

	*/
	@Column(columnDefinition = "varchar(2) default 'N'")
	private String sendPaymentRetrievalNotification;

	public Integer getClientId() {
		return clientId;
	}

	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}

	public String getClientCode() {
		return clientCode;
	}

	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientContact() {
		return clientContact;
	}

	public void setClientContact(String clientContact) {
		this.clientContact = clientContact;
	}

	public String getClientEmail() {
		return clientEmail;
	}

	public void setClientEmail(String clientEmail) {
		this.clientEmail = clientEmail;
	}

	public String getClientUsername() {
		return clientUsername;
	}

	public void setClientUsername(String clientUsername) {
		this.clientUsername = clientUsername;
	}

	public String getClientPass() {
		return clientPass;
	}

	public void setClientPass(String clientPass) {
		this.clientPass = clientPass;
	}

	public String getSuccessReturnURL() {
		return successReturnURL;
	}

	public void setSuccessReturnURL(String successReturnURL) {
		this.successReturnURL = successReturnURL;
	}

	public String getFailureReturnURL() {
		return failureReturnURL;
	}

	public void setFailureReturnURL(String failureReturnURL) {
		this.failureReturnURL = failureReturnURL;
	}

	public String getClientKey() {
		return clientKey;
	}

	public void setClientKey(String clientKey) {
		this.clientKey = clientKey;
	}

	public String getClientIV() {
		return clientIV;
	}

	public void setClientIV(String clientIV) {
		this.clientIV = clientIV;
	}

	public String getAuthFlag() {
		return authFlag;
	}

	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}

	public String getAuthType() {
		return authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public Integer getClientTypeId() {
		return clientTypeId;
	}

	public void setClientTypeId(Integer clientTypeId) {
		this.clientTypeId = clientTypeId;
	}

	public String getBankClientParam() {
		return bankClientParam;
	}

	public void setBankClientParam(String bankClientParam) {
		this.bankClientParam = bankClientParam;
	}

	public String getBypassOptionsFlag() {
		return bypassOptionsFlag;
	}

	public void setBypassOptionsFlag(String bypassOptionsFlag) {
		this.bypassOptionsFlag = bypassOptionsFlag;
	}

	public String getRedirect_to_new_layout() {
		return redirect_to_new_layout;
	}

	public void setRedirect_to_new_layout(String redirect_to_new_layout) {
		this.redirect_to_new_layout = redirect_to_new_layout;
	}

	public String getStatusEnquiryFlag() {
		return statusEnquiryFlag;
	}

	public void setStatusEnquiryFlag(String statusEnquiryFlag) {
		this.statusEnquiryFlag = statusEnquiryFlag;
	}

	public String getIs_refund_applicable() {
		return is_refund_applicable;
	}

	public void setIs_refund_applicable(String is_refund_applicable) {
		this.is_refund_applicable = is_refund_applicable;
	}

	public String getApplicable_for_challan() {
		return applicable_for_challan;
	}

	public void setApplicable_for_challan(String applicable_for_challan) {
		this.applicable_for_challan = applicable_for_challan;
	}

	public Integer getIsApplication() {
		return isApplication;
	}

	public void setIsApplication(Integer isApplication) {
		this.isApplication = isApplication;
	}

	public String getSendPaymentRetrievalNotification() {
		return sendPaymentRetrievalNotification;
	}

	public void setSendPaymentRetrievalNotification(String sendPaymentRetrievalNotification) {
		this.sendPaymentRetrievalNotification = sendPaymentRetrievalNotification;
	}
	
	
	
	
}
