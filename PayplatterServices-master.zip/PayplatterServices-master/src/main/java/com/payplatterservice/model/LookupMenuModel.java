package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Proxy;

@Entity
@Table(name = "lookup_menus")
public class LookupMenuModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer menu_id;
	

	private String menu_action_name, menu_description,menu_type,operator_menu_action_name;
	private Integer menu_order;
	public Integer getMenu_id() {
		return menu_id;
	}
	public void setMenu_id(Integer menu_id) {
		this.menu_id = menu_id;
	}
	public String getMenu_action_name() {
		return menu_action_name;
	}
	public void setMenu_action_name(String menu_action_name) {
		this.menu_action_name = menu_action_name;
	}
	public String getMenu_description() {
		return menu_description;
	}
	public void setMenu_description(String menu_description) {
		this.menu_description = menu_description;
	}
	public String getMenu_type() {
		return menu_type;
	}
	public void setMenu_type(String menu_type) {
		this.menu_type = menu_type;
	}
	public String getOperator_menu_action_name() {
		return operator_menu_action_name;
	}
	public void setOperator_menu_action_name(String operator_menu_action_name) {
		this.operator_menu_action_name = operator_menu_action_name;
	}
	public Integer getMenu_order() {
		return menu_order;
	}
	public void setMenu_order(Integer menu_order) {
		this.menu_order = menu_order;
	}
	
	

}
