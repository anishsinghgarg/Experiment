package com.payplatterservice.operationservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payplatterservice.security.KeyGenerator;
import com.payplatterservice.service.PlatterPayOnBoardingServices;
import com.platterpayservices.model.ClientDetails;

@Repository
public class PlatterPayOnboardingImpl implements PlatterPayOnboarding {

	

	@Autowired
	PlatterPayOnBoardingServices platterPayOnboarding;

	@Override
	public ClientDetails generateClientDetails(ClientDetails clientDetails) {
		KeyGenerator keyGenerator=new KeyGenerator();
		clientDetails = keyGenerator.GenerateLoginCreds(clientDetails);
		if (clientDetails != null) {
			clientDetails = keyGenerator.GenerateKey(clientDetails);

			clientDetails = keyGenerator.GenerateIV(clientDetails);
		}
		System.out.println(
				"Client Details :: " + clientDetails.getClientUsername() + " Pass: " + clientDetails.getClientPass()
						+ " AUthKey " + clientDetails.getClientKey() + " AuthIV " + clientDetails.getClientIV());
		return clientDetails;
	}

}
