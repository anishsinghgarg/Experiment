 package com.payplatterservice.model;

import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

public class BCObjectKeyModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer merchantID;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer payerID;
	private String businessContextName;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer mapping_id;

	public Integer getMerchantID() {
		return merchantID;
	}
	public void setMerchantID(Integer merchantID) {
		this.merchantID = merchantID;
	}
	public Integer getPayerID() {
		return payerID;
	}
	public void setPayerID(Integer payerID) {
		this.payerID = payerID;
	}
	public String getBusinessContextName() {
		return businessContextName;
	}
	public void setBusinessContextName(String businessContextName) {
		this.businessContextName = businessContextName;
	}
	public Integer getMapping_id() {
		return mapping_id;
	}
	public void setMapping_id(Integer mapping_id) {
		this.mapping_id = mapping_id;
	}
	
	

}
