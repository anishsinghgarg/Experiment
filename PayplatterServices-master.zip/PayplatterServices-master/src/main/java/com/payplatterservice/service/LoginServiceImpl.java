package com.payplatterservice.service;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.payplatterservice.model.Login;
import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayerModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class LoginServiceImpl implements LoginService {

	private static final Logger logger = Logger.getLogger(LoginServiceImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	public LoginServiceImpl() {
	}

	public Login validateLigin(Login login) {
		Login loginvalidation = new Login();
		Session session = sessionFactory.openSession();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<Login> query = builder.createQuery(Login.class);
			Root<Login> root = query.from(Login.class);
			logger.info("Password ::" + login.getPassword());
			query.select(root).where(builder.and(builder.equal(root.get("password"), login.getPassword())),
					builder.equal(root.get("userName"), login.getUserName()));
			Query<Login> q = session.createQuery(query);
			loginvalidation = (Login) q.list().get(0);
			return (Login) q.list().get(0);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return loginvalidation;
	}

	public PayerModel getUserProfile(PayerModel payer) {
		Session session = sessionFactory.openSession();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayerModel> query = builder.createQuery(PayerModel.class);
			Root<PayerModel> root = query.from(PayerModel.class);
			logger.info("Payer ID ::" + payer.getId());

			query.select(root).where(builder.equal(root.get("id"), payer.getId()));

			Query<PayerModel> q = session.createQuery(query);
			q.list().get(0);

			logger.info("Payed Details :" + ((PayerModel) q.list().get(0)).getId());

			return (PayerModel) q.list().get(0);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	public MerchantsModel getMerchantProfile(MerchantsModel merchant) {
		Session session = sessionFactory.openSession();
		try {
			return (MerchantsModel) session.get(MerchantsModel.class, merchant.getId());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public Login createLogin(Login login) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(login);
			session.getTransaction().commit();
			return login;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public List<PayerModel> getSearchedPayer(PayerModel payer) {
		Session session = sessionFactory.openSession();
		List<PayerModel> list = new ArrayList<PayerModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayerModel> query = builder.createQuery(PayerModel.class);
			Root<PayerModel> root = query.from(PayerModel.class);
			if (payer.getSearchKey().equalsIgnoreCase("searchByName")) {
				query.select(root).where(builder.and(builder.equal(root.get("firstName"), payer.getFirstName())),
						builder.equal(root.get("lastName"), payer.getLastName()));
			} else if (payer.getSearchKey().equalsIgnoreCase("searchByCountry")) {
				query.select(root).where(builder.equal(root.get("country"), payer.getCountry()));
			} else if (payer.getSearchKey().equalsIgnoreCase("searchByState")) {
				query.select(root).where(builder.equal(root.get("state"), payer.getState()));
			} else {
				return null;
			}

			Query<PayerModel> q = session.createQuery(query);
			list = q.getResultList();
			return list;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public List<MerchantConfigPreferencesModel> merchantPreferencesList(MerchantsModel merchantsModel) {
		Session session = sessionFactory.openSession();
		List<MerchantConfigPreferencesModel> list = new ArrayList<MerchantConfigPreferencesModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<MerchantConfigPreferencesModel> query = builder
					.createQuery(MerchantConfigPreferencesModel.class);
			Root<MerchantConfigPreferencesModel> root = query.from(MerchantConfigPreferencesModel.class);

			query.select(root).where(builder.equal(root.get("merchant_id"), merchantsModel.getId()));
			Query<MerchantConfigPreferencesModel> q = session.createQuery(query);
			list = q.getResultList();
			return list;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception During Checking Merchant Preferences List : " + e.getMessage());
			return null;
		} finally {
			session.close();
		}
	}

}
