package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "merchant_config_preferences")
public class MerchantConfigPreferencesModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer id;
	private String parameter_value;
	private Integer merchant_id;
	private String comment;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "parameter_id_Fk", referencedColumnName = "id")
	private LookupParameterModel lookupPramMOdel;
	
	@Transient
	private MerchantsModel merchantDataModel;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getParameter_value() {
		return parameter_value;
	}
	public void setParameter_value(String parameter_value) {
		this.parameter_value = parameter_value;
	}
	public Integer getMerchant_id() {
		return merchant_id;
	}
	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public LookupParameterModel getLookupPramMOdel() {
		return lookupPramMOdel;
	}
	public void setLookupPramMOdel(LookupParameterModel lookupPramMOdel) {
		this.lookupPramMOdel = lookupPramMOdel;
	}
	public MerchantsModel getMerchantDataModel() {
		return merchantDataModel;
	}
	public void setMerchantDataModel(MerchantsModel merchantDataModel) {
		this.merchantDataModel = merchantDataModel;
	}
	
	
}
