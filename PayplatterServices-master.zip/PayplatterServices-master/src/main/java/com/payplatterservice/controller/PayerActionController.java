package com.payplatterservice.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.UriComponentsBuilder;

import com.payplatterservice.model.FormDetailsModel;
import com.payplatterservice.model.BusinessContextModel;
import com.payplatterservice.model.CustomerRequestModel;
import com.payplatterservice.model.IndustryModel;
import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.MessageConfigurationModel;
import com.payplatterservice.model.MessageModel;
import com.payplatterservice.model.PayPlatterEcomMerchandiseBookingsBean;
import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PayerDocumentModel;
import com.payplatterservice.model.PayerMenuModel;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PayplatterBusinessContextServiceMappings;
import com.payplatterservice.model.PayplatterBusinessContexts;
import com.payplatterservice.model.PayplatterCentralInvoicesModel;
import com.payplatterservice.model.PersonnelAppointmentModel;
import com.payplatterservice.model.SampleFormModel;
import com.payplatterservice.model.SamplePickupModel;
import com.payplatterservice.model.SearchKeyModel;
import com.payplatterservice.model.TransitportAssetReservationsModel;
import com.payplatterservice.model.TransitportAssetsModel;
import com.payplatterservice.model.TransitportPersonnelModel;
import com.payplatterservice.model.VenueAppointmentModel;
import com.payplatterservice.operationservice.PayerOperationServices;
import com.payplatterservice.service.LoginService;
import com.payplatterservice.service.MerchantServicesService;
import com.payplatterservice.service.PayerService;
import com.payplatterservice.service.TransactionsService;

@RestController
public class PayerActionController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(PayerActionController.class);
	@Autowired
	TransactionsService services;

	@Autowired
	LoginService loginservices;

	@Autowired
	PayerService payerservices;
	@Autowired
	MerchantServicesService merServices;
	@Autowired
	PayerOperationServices payerOperServices;

	@RequestMapping(value = "/getPayerTransactionMerchantWise/", method = RequestMethod.POST, produces = "application/json")
	public List<PayPlatterTransactionModel> getPayerTransactionMerchantWise(
			@RequestBody PayPlatterTransactionModel transModel, UriComponentsBuilder ucBuilder) {
		List<PayPlatterTransactionModel> model = new ArrayList<PayPlatterTransactionModel>();
		MerchantsModel mModel = new MerchantsModel();

		try {
			mModel.setId(Integer.parseInt(transModel.getTempMID_Fk()));
			mModel = loginservices.getMerchantProfile(mModel);
			if (mModel != null) {
				transModel.setMerchantsBean(mModel);
				model = services.getPayerTransModel(transModel);
				return model;
			} else {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
	
	@RequestMapping(value="/updatePayerDetails/",method=RequestMethod.POST,produces="application/json")
	public PayerModel updatePayerDetails(@RequestBody PayerModel model,UriComponentsBuilder ucBuilder){
		PayerModel tempModel=new PayerModel();
		tempModel=payerservices.getPayerDetailsById(model);
		logger.info("Payer Details :: "+tempModel.getId());
		if (tempModel!=null) {
			tempModel.setPayerDevice_ID(model.getPayerDevice_ID());
			tempModel=payerservices.updatePayerDetails(tempModel);
		}
		return tempModel;
	}

	@RequestMapping(value = "/getPayerTransaction/", method = RequestMethod.POST, produces = "application/json")
	public List<PayPlatterTransactionModel> getPayerTransaction(@RequestBody PayPlatterTransactionModel txnDetails,
			UriComponentsBuilder ucBuilder) {
		List<PayPlatterTransactionModel> list = new ArrayList<PayPlatterTransactionModel>();
		list = services.getPayerTransModel(txnDetails);
		if (list != null) {
			return list;
		} else {
			return null;
		}

	}

	@RequestMapping(value = "/getPayerTransactionDeatils/", method = RequestMethod.POST, produces = "application/json")
	public PayPlatterTransactionModel getPayerTransactionDeatils(@RequestBody PayPlatterTransactionModel txnDetails,
			UriComponentsBuilder ucBuilder) {
		PayPlatterTransactionModel list = new PayPlatterTransactionModel();
		list = services.getPayerTransModels(txnDetails);

		return list;
	}

	@RequestMapping(value = "/getPayerInvoice/", method = RequestMethod.POST, produces = "application/json")
	public PayplatterCentralInvoicesModel getPayerInvoice(@RequestBody PayplatterCentralInvoicesModel invoice,
			UriComponentsBuilder ucBuilder) {
		PayplatterCentralInvoicesModel model = new PayplatterCentralInvoicesModel();
		model = payerservices.getPayerInvoice(invoice);
		if (model != null) {
			return model;
		} else {
			return null;
		}

	}

	@RequestMapping(value = "/getPayerInvoiceList/", method = RequestMethod.POST, produces = "application/json")
	public List<PayplatterCentralInvoicesModel> getPayerInvoiceList(@RequestBody PayplatterCentralInvoicesModel model,
			UriComponentsBuilder ucBuilder) {
		List<PayplatterCentralInvoicesModel> list = new ArrayList<PayplatterCentralInvoicesModel>();
		logger.info("ID ::" + model.getPayer_id());
		list = payerservices.getPayerInvoiceList(model);
		return list;
	}

	@RequestMapping(value = "/getPayerMerchantList/", method = RequestMethod.POST, produces = "application/json")
	public List<MerchantsModel> getPayerMerchantList(@RequestBody PayerModel model, UriComponentsBuilder ucBuilder) {
		List<MerchantsModel> list = new ArrayList<MerchantsModel>();
		list = payerservices.getMerchantList(model);

		return list;
	}

	@RequestMapping(value = "/getMerchantServicesList/", method = RequestMethod.POST, produces = "application/json")
	public List<PayplatterBusinessContextServiceMappings> getMerchantServicesList(@RequestBody MerchantsModel model,
			UriComponentsBuilder ucBuilder) {
		MerchantsModel merModel = new MerchantsModel();
		List<PayplatterBusinessContextServiceMappings> businesscontextmappings = new ArrayList<PayplatterBusinessContextServiceMappings>();
		businesscontextmappings = merServices.getServicesList(model);
		businesscontextmappings = businesscontextmappings.stream().distinct().collect(Collectors.toList());
		int loopSize = businesscontextmappings.size();
		if (loopSize > 0) {
			for (int i = 0; i < loopSize; i++) {
				// To Get Merchant Data
				merModel.setId(businesscontextmappings.get(i).getMerchant_id());
				businesscontextmappings.get(i).setMerchantdata(loginservices.getMerchantProfile(merModel));
				// To Get Business Context
				businesscontextmappings.get(i).setContextdata(
						merServices.getBusinessContextByID(businesscontextmappings.get(i).getContext_id()));
				// To Get Services Data
				businesscontextmappings.get(i).setServicedata(
						merServices.getServiceMasterByID(businesscontextmappings.get(i).getService_id()));
			}
		}
		return businesscontextmappings;
	}

	@RequestMapping(value = "/saveCustomerToMerchantConversion/", method = RequestMethod.PUT, produces = "application/json")
	public String saveCustomerToMerchantConvversion(@RequestBody CustomerRequestModel customerReqModel,
			UriComponentsBuilder ucBuilder) {
		CustomerRequestModel reModel = new CustomerRequestModel();
		PayerModel model = new PayerModel();
		model.setId(customerReqModel.getRequest_id());
		customerReqModel.setPayerBean(model);

		reModel = payerservices.saveCustomerConversionData(customerReqModel);
		return "{\"status\":\"success\",\"AddMSG\":\"Added Success\"}";
	}

	@RequestMapping(value = "/OpenCustomerConversion/", method = RequestMethod.POST, produces = "application/json")
	public List<CustomerRequestModel> OpenCustomerConversion(@RequestBody CustomerRequestModel customerModel,
			UriComponentsBuilder ucBuilder) {
		List<CustomerRequestModel> list = new ArrayList<CustomerRequestModel>();
		String key = "PAYERID";
		list = payerservices.getCustomerConversion(customerModel, key);
		logger.info("Return Size::" + list.size());
		return list;
	}

	@RequestMapping(value = "/getPayerMessages/", method = RequestMethod.POST, produces = "application/json")
	public List<MessageModel> getPayerMessages(@RequestBody MessageConfigurationModel model,
			UriComponentsBuilder ucBuilder) {
		List<MessageModel> list = new ArrayList<MessageModel>();

		try {
			list = payerservices.getMessageList(model);
			return list;
		} catch (IndexOutOfBoundsException ex) {
			ex.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@RequestMapping(value = "/getPayerMessagesDetails/", method = RequestMethod.POST, produces = "application/json")
	public MessageModel getPayerMessagesDetails(@RequestBody MessageModel model, UriComponentsBuilder ucBuilder) {
		PayerModel payerModel = new PayerModel();
		try {

			model = payerservices.getMessageDetails(model);
			return model;
		} catch (IndexOutOfBoundsException ex) {
			ex.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@RequestMapping(value = "/getPayerMerchantDocuments/", method = RequestMethod.POST, produces = "application/json")
	public List<PayerDocumentModel> getPayerMerchantDocuments(@RequestBody PayerDocumentModel model,
			UriComponentsBuilder ucBuilder) {
		List<PayerDocumentModel> list = new ArrayList<PayerDocumentModel>();
		try {
			list = payerservices.getPayerMerchantDocuments(model);
			return list;
		} catch (IndexOutOfBoundsException ex) {
			ex.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@RequestMapping(value = "/getPayerBookingDetails/", method = RequestMethod.POST, produces = "application/json")
	public List<Object> getPayerBookingDetails(@RequestBody PayerModel model, UriComponentsBuilder ucBuilder) {
		FormDetailsModel formDetails = new FormDetailsModel();
		SampleFormModel formData = new SampleFormModel();
		List<PersonnelAppointmentModel> appointment = new ArrayList<PersonnelAppointmentModel>();
		SamplePickupModel sampleModel = new SamplePickupModel();
		VenueAppointmentModel venueModel = new VenueAppointmentModel();
		HashMap<String, Object> filter = new HashMap<>();
		BusinessContextModel businessContextModel = new BusinessContextModel();
		List<TransitportPersonnelModel> personnel = new ArrayList<TransitportPersonnelModel>();
		// ArrayList<BusinessContextModel>();
		List<BusinessContextModel> list = new ArrayList<BusinessContextModel>();
		List<Object> listObject = new ArrayList<Object>();
		List<Object> listObjectApp = new ArrayList<Object>();
		List<Object> listObjectPer = new ArrayList<Object>();
		ArrayList<Integer> IntegerTakenList = new ArrayList<>();
		List<PayplatterBusinessContextServiceMappings> bContextMappingList = new ArrayList<PayplatterBusinessContextServiceMappings>();

		formData = payerservices.getBookingDetails(model);
		if (null != formData) {
			logger.info("Form Template ID : " + formData.getFormTemplateId());
			formDetails = payerservices.getFormDetails(formData.getFormTemplateId());
			logger.info("Bean Name ::" + formDetails.getBusiness_context_bean_name());
		}
		if (null != formDetails) {
			logger.info("In first if ::");
			if (formDetails.getBusiness_context_bean_name().equalsIgnoreCase("aBean")) {
				logger.info("Bean name is aBean now we are processing for Appointment Details :::::::::: "
						+ formDetails.getBusiness_context_bean_name());
				filter.put("personnel_id", model.getPersonnelID());
				filter.put("form_instance_id", formDetails.getId());
				filter.put("status", model.getStatus());
				appointment = payerservices.getBookingAppointmentDetails(filter);
				for (PersonnelAppointmentModel personnelAppointmentModel : appointment) {
					IntegerTakenList.add(personnelAppointmentModel.getPersonnel_id());
					listObjectApp.add(personnelAppointmentModel);
				}
				filter.put("personnel_id", IntegerTakenList);
				personnel = payerservices.getPersonnelsDetails(filter);
				for (TransitportPersonnelModel personnels : personnel) {
					logger.info("Personnel :: " + personnels.getFirst_name());
					listObjectPer.add(personnels);
				}

			}

			listObject.add(listObjectApp);
			listObject.add(listObjectPer);
		}
		return listObject;
	}

	// SecureRESTApiWithBasicAuthentication PayplatterServices

	@RequestMapping(value = "/getPayerMenuMerchantWise/", method = RequestMethod.POST, produces = "application/json")
	public HashMap<String, Object> getPayerMenuMerchantWise(@RequestBody MerchantsModel model,
			UriComponentsBuilder ucBuilder) {

		List<PayerMenuModel> menuList = new ArrayList<PayerMenuModel>();
		List<String> menuStringList = new ArrayList<String>();
		List<String> bc_menu_list = new ArrayList<String>();
		HashMap<String, Object> menuMap = new HashMap<>();
		Map<String, Object> mapMenu = null;
		try {
			menuList = payerservices.getPayerMenuMerchantWise(model);
			int i = 0;

			for (i = 0; i < menuList.size(); i++) {
				menuMap.put("MenuName" + i, menuList.get(i).getMenuBean().getMenu_description());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return menuMap;
	}

	// Report According to Business Context

	@RequestMapping(value = "/getBusinessContextBookingReport/", method = RequestMethod.POST, produces = "application/json")
	public List<Object> getBusinessContextReport(@RequestBody PayerModel model, UriComponentsBuilder ucBuilder) {
		MerchantsModel merModel = new MerchantsModel();
		merModel.setId(model.getMerchantID());
		merModel.setMappingID(model.getMapping_id());
		List<Object> listOfBContextDetails = new ArrayList<Object>();
		List<TransitportPersonnelModel> personnel = new ArrayList<TransitportPersonnelModel>();
		List<PersonnelAppointmentModel> appointmentDetails = new ArrayList<PersonnelAppointmentModel>();
		List<VenueAppointmentModel> venuBookingDetails = new ArrayList<VenueAppointmentModel>();
		List<TransitportAssetReservationsModel> reservations = new ArrayList<TransitportAssetReservationsModel>();
		List<SamplePickupModel> samplePickupModel = new ArrayList<SamplePickupModel>();
		PayplatterBusinessContextServiceMappings contextMappingID = new PayplatterBusinessContextServiceMappings();
		List<PayplatterBusinessContextServiceMappings> bContextMappingID = new ArrayList<PayplatterBusinessContextServiceMappings>();
		List<SampleFormModel> formModel = new ArrayList<SampleFormModel>();
		PayplatterBusinessContexts businessContext = new PayplatterBusinessContexts();
		try {
			if (model.getMenuName().equals("Appointment Booking")) {
				businessContext = payerservices.getBusinessContextDetails("Personal Appointment Booking");
				merModel.setContextID(Integer.valueOf(businessContext.getContext_id()));
			} else if (model.getMenuName().equals("Venue Booking")) {

				businessContext = payerservices.getBusinessContextDetails("Venue Booking");
				logger.info("For Business Context Data : "+businessContext.getContext_id());
				merModel.setContextID(Integer.valueOf(businessContext.getContext_id()));
			} else if (model.getMenuName().equals("SamplePickup Booking")) {
				businessContext = payerservices.getBusinessContextDetails("Sample Pickup Request");
				merModel.setContextID(Integer.valueOf(businessContext.getContext_id()));
			}

			contextMappingID = merServices.getBusinessContextBasedOnMerchant(merModel);
			ArrayList<Integer> IntegerTakenList = new ArrayList<>();
			for (PayplatterBusinessContextServiceMappings mapping : bContextMappingID) {
				IntegerTakenList.add(mapping.getMapping_id());
			}
			try {
				if (bContextMappingID != null) {
					formModel = merServices.getformCapturedData(contextMappingID, model);
					for (SampleFormModel form : formModel) {
						logger.info("Form List data :: " + form.getFormId());
						IntegerTakenList.add(form.getFormId());
					}

					if (formModel != null) {
						logger.info("Form Model != null :::::::::::::");
						HashMap<String, Object> mapFilter = new HashMap<String, Object>();
						if (model.getMenuName().equals("Appointment Booking")) {
							mapFilter.put("form_instance_id", IntegerTakenList);
							appointmentDetails = merServices.getAppointmentDetails(mapFilter);

							for (PersonnelAppointmentModel personnelAppointmentModel : appointmentDetails) {
								// IntegerTakenList.add(personnelAppointmentModel.getPersonnel_id());
								// personnelModel=;
								personnelAppointmentModel.setPersonnelData(payerservices
										.getPersonnelsDetailsbyID(personnelAppointmentModel.getPersonnel_id()));
								listOfBContextDetails.add(personnelAppointmentModel);
							}

							/*
							 * filter.put("personnel_id", IntegerTakenList);
							 * personnel =
							 * payerservices.getPersonnelsDetails(filter);
							 */
							for (TransitportPersonnelModel personnels : personnel) {
								// logger.info("Personnel :: " +
								// personnels.getFirst_name());
								// listOfPersonnel.add(personnels);
							}

						} else if (model.getMenuName().equals("Venue Booking")) {
							logger.info("Coding Done :::::::::::");
							// Asset Booking Repto for Slot Based
							if (model.getVenueBookingType().equalsIgnoreCase("SLOT_BASED")) {
								venuBookingDetails = merServices.getVenuBookingDetails(IntegerTakenList);

								for (VenueAppointmentModel venuBookingModel : venuBookingDetails) {
									// IntegerTakenList.add(venuBookingModel.getAsset_id());
									venuBookingModel.setAssetData(payerservices
											.getAssetReservationDetailsByID(venuBookingModel.getAsset_id()));
									listOfBContextDetails.add(venuBookingModel);
								}
							}

							// End

							// Asset Booking Report for Date Range
							if (model.getVenueBookingType().equalsIgnoreCase("DATE_BASED")) {
								reservations = merServices.getVenuReservationsDetails(IntegerTakenList);
								for (TransitportAssetReservationsModel reservation : reservations) {
									reservation.setAsset_data(
											payerservices.getAssetReservationDetailsByID(reservation.getAsset_id()));
									listOfBContextDetails.add(reservation);
								}
							}

							// End
							/*
							 * filter.put("assets_id", IntegerTakenList); assets
							 * = payerservices.getAssetsDetails(filter); for
							 * (TransitportAssetsModel assetsModel : assets) {
							 * logger.info("Personnel :: " +
							 * assetsModel.getAsset_name());
							 * listOfPersonnel.add(assetsModel); }
							 */
						} else if (model.getMenuName().equals("SamplePickup Booking")) {
							samplePickupModel = merServices.getSamplePickupDetails(IntegerTakenList);

							for (SamplePickupModel samplePickup : samplePickupModel) {
								IntegerTakenList.add(samplePickup.getContextDataId());
								listOfBContextDetails.add(samplePickup);
							}

						}

					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			// listObject.add(listOfPersonnel);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return listOfBContextDetails;
	}

	@RequestMapping(value = "/getBusinessContextBookingDetails/", method = RequestMethod.POST, produces = "application/json")
	public List<Object> getBusinessContextBookingDetails(@RequestBody PersonnelAppointmentModel model,
			UriComponentsBuilder ucBuilder) {
		List<Object> listObject = new ArrayList<Object>();
		HashMap<String, Object> filter = new HashMap<>();
		List<SampleFormModel> formModel = new ArrayList<SampleFormModel>();
		formModel = merServices.getFormDataDetails(model);
		listObject.add(formModel);
		return listObject;
	}

	@RequestMapping(value = "/getOrderReportDetails/", method = RequestMethod.POST, produces = "application/json")
	public List<Object> getOrderReportDetails(@RequestBody PayPlatterEcomMerchandiseBookingsBean model,
			UriComponentsBuilder ucBuilder) {
		List<Object> listObject = new ArrayList<Object>();
		// jikj
		List<PayPlatterEcomMerchandiseBookingsBean> orderModel = new ArrayList<PayPlatterEcomMerchandiseBookingsBean>();
		orderModel = merServices.getOrderReportDetails(model);
		listObject.add(orderModel);
		return listObject;
	}

	@RequestMapping(value = "/getOrderReportDetailsByOrderId/", method = RequestMethod.POST, produces = "application/json")
	public PayPlatterEcomMerchandiseBookingsBean getOrderReportDetailsByOrderId(
			@RequestBody PayPlatterEcomMerchandiseBookingsBean model, UriComponentsBuilder ucBuilder) {
		// List<Object> listObject = new ArrayList<Object>();
		PayPlatterEcomMerchandiseBookingsBean orderModel = new PayPlatterEcomMerchandiseBookingsBean();
		orderModel = merServices.getOrderReportDetailsByOrderId(model);
		// listObject.add(orderModel);
		return orderModel;
	}

	@RequestMapping(value = "/updateOrderStatus/", method = RequestMethod.POST, produces = "application/json")
	public PayPlatterEcomMerchandiseBookingsBean updateOrderStatus(
			@RequestBody PayPlatterEcomMerchandiseBookingsBean model, UriComponentsBuilder ucBuilder) {
		// List<Object> listObject = new ArrayList<Object>();
		PayPlatterEcomMerchandiseBookingsBean orderModel = new PayPlatterEcomMerchandiseBookingsBean();
		orderModel = merServices.updateOrderStatus(model);
		// listObject.add(orderModel);
		return orderModel;
	}

	@RequestMapping(value = "/getReportMenuBContextWise/", method = RequestMethod.POST, produces = "application/json")
	public List<Object> getReportMenuBContextWise(@RequestBody MerchantsModel model, UriComponentsBuilder ucBuilder) {
		// List<PayplatterBusinessContexts> businessContextsList = new
		// ArrayList<PayplatterBusinessContexts>();
		HashMap<String, Object> filter = new HashMap<>();

		List<Object> listobject = new ArrayList<Object>();
		List<PayplatterBusinessContextServiceMappings> contextServicesList = new ArrayList<PayplatterBusinessContextServiceMappings>();
		filter.put("merchant_id", model.getId());
		filter.put("service_id", model.getServicesID());
		filter.put("context_id", model.getContextID());
		filter.put("mapping_id", model.getMappingID());

		contextServicesList = payerservices.getContextMappingList(filter);
		if (contextServicesList.size() > 0) {
			for (int i = 0; i < contextServicesList.size(); i++) {
				PayplatterBusinessContextServiceMappings contextServices = contextServicesList.get(i);
				contextServices.setContextdata(payerservices.getContextList(contextServices.getContext_id()));
				// bContext.setServicesMappingData(contextServices);
				listobject.add(contextServices);
			}

		}
		return listobject;
	}

	@RequestMapping(value = "/searchAvability/", method = RequestMethod.POST, produces = "application/json")
	public List<MerchantsModel> searchAvability(@RequestBody SearchKeyModel searchkey, UriComponentsBuilder ucBuilder) {

		List<MerchantsModel> objectList = payerOperServices.getMerchantSearchAvability(searchkey);

		return objectList;
	}

	@RequestMapping(value = "/getIndustryList/", method = RequestMethod.POST, produces = "application/json")
	public List<IndustryModel> getIndustryList(UriComponentsBuilder ucBuilder) {
		List<IndustryModel> industryList = new ArrayList<IndustryModel>();
		industryList = payerservices.getIndustryList();
		return null;
	}

	@RequestMapping(value = "/cancelAssetReservation/", method = RequestMethod.POST, produces = "application/json")
	public String cancelAssetReservation(@RequestBody TransitportAssetsModel model, UriComponentsBuilder ucBuilder) {

		String returnMsg = null;
		if (model.getReservation_id() != null && model.getAvailability_id() != null) {
			returnMsg = payerOperServices.cancelAssetReservation(model);
		} else {
			String statusMsg = "Request Parameter is null!!!";
			String status = "Fail";
			String statusCode = "777";
			returnMsg = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode + "\",\"Status Msg\":\""
					+ statusMsg + "\"}";
		}

		return returnMsg;
	}

	@RequestMapping(value = "/assetReservationReschedule/", method = RequestMethod.POST, produces = "application/json")
	public List<TransitportAssetsModel> assetReservationREschedule(@RequestBody TransitportAssetReservationsModel model,
			UriComponentsBuilder ucBuilder) {
		List<TransitportAssetsModel> list = new ArrayList<TransitportAssetsModel>();
		list = payerOperServices.assetReservationReschedule(model);
		return list;
	}

	@RequestMapping(value = "/saveRescheduleAssetReservation/", method = RequestMethod.POST, produces = "application/json")
	public String saveRescheduleAssetReservation(@RequestBody TransitportAssetsModel model,
			UriComponentsBuilder ucBuilder) {
		String statusMsg = null;
		String status = null;
		String statusCode = null;
		status=payerOperServices.saveRescheduleReservation(model);

		return status;
	}

}
