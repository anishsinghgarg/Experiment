package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "context_sample_pickup")
public class SamplePickupModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer contextDataId;
	private String pickupDate;
	private String pickup_start_time, pickup_end_time;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer form_instance_id;
	private String pickupSampleDescription;
	@ColumnDefault(value = "'OPEN'")
	private String status;
	private String pickContactMobile;
	private String pickupAddress;
	private String pickContactName;

	public Integer getContextDataId() {
		return contextDataId;
	}

	public void setContextDataId(Integer contextDataId) {
		this.contextDataId = contextDataId;
	}

	public String getPickupDate() {
		return pickupDate;
	}

	public void setPickupDate(String pickupDate) {
		this.pickupDate = pickupDate;
	}

	public String getPickup_start_time() {
		return pickup_start_time;
	}

	public void setPickup_start_time(String pickup_start_time) {
		this.pickup_start_time = pickup_start_time;
	}

	public String getPickup_end_time() {
		return pickup_end_time;
	}

	public void setPickup_end_time(String pickup_end_time) {
		this.pickup_end_time = pickup_end_time;
	}

	public Integer getForm_instance_id() {
		return form_instance_id;
	}

	public void setForm_instance_id(Integer form_instance_id) {
		this.form_instance_id = form_instance_id;
	}

	public String getPickupSampleDescription() {
		return pickupSampleDescription;
	}

	public void setPickupSampleDescription(String pickupSampleDescription) {
		this.pickupSampleDescription = pickupSampleDescription;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPickContactMobile() {
		return pickContactMobile;
	}

	public void setPickContactMobile(String pickContactMobile) {
		this.pickContactMobile = pickContactMobile;
	}

	public String getPickupAddress() {
		return pickupAddress;
	}

	public void setPickupAddress(String pickupAddress) {
		this.pickupAddress = pickupAddress;
	}

	public String getPickContactName() {
		return pickContactName;
	}

	public void setPickContactName(String pickContactName) {
		this.pickContactName = pickContactName;
	}

}
