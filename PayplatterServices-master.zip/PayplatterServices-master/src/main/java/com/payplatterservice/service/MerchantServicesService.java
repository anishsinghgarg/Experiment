/**
 * 
 */
package com.payplatterservice.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayPlatterEcomMerchandiseBookingsBean;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PayplatterBusinessContextServiceMappings;
import com.payplatterservice.model.PayplatterBusinessContexts;
import com.payplatterservice.model.PersonnelAppointmentModel;
import com.payplatterservice.model.SampleFormModel;
import com.payplatterservice.model.SamplePickupModel;
import com.payplatterservice.model.ServicesMasterModel;
import com.payplatterservice.model.TransitportAssetReservationsModel;
import com.payplatterservice.model.VenueAppointmentModel;

/**
 * @author Dexpert
 *
 */
public interface MerchantServicesService {

	List<PayplatterBusinessContextServiceMappings> getServicesList(MerchantsModel model);

	ServicesMasterModel getServiceMasterByID(Integer service_id);

	PayplatterBusinessContexts getBusinessContextByID(Integer context_id);

	List<PersonnelAppointmentModel> getAppointmentDetails(ArrayList<Integer> integerTakenList);

	PayplatterBusinessContextServiceMappings getBusinessContextBasedOnMerchant(MerchantsModel merModel);

	List<SampleFormModel> getformCapturedData(PayplatterBusinessContextServiceMappings contextMappingID,
			PayerModel model);

	List<VenueAppointmentModel> getVenuBookingDetails(ArrayList<Integer> integerTakenList);

	List<SamplePickupModel> getSamplePickupDetails(ArrayList<Integer> integerTakenList);

	List<SampleFormModel> getFormDataDetails(PersonnelAppointmentModel model);

	List<PayPlatterEcomMerchandiseBookingsBean> getOrderReportDetails(PayPlatterEcomMerchandiseBookingsBean model);

	PayPlatterEcomMerchandiseBookingsBean getOrderReportDetailsByOrderId(PayPlatterEcomMerchandiseBookingsBean model);

	PayPlatterEcomMerchandiseBookingsBean updateOrderStatus(PayPlatterEcomMerchandiseBookingsBean model);

	List<PersonnelAppointmentModel> getAppointmentDetails(HashMap<String, Object> mapFilter);

	List<TransitportAssetReservationsModel> getVenuReservationsDetails(ArrayList<Integer> integerTakenList);

}
