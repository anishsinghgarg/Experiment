package com.payplatterservice.configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import org.jboss.logging.Logger;

import com.payplatterservice.service.MerchantServicesServiceImpl;


public class ReportDBConnection {

	private static final Logger logger = Logger.getLogger(ReportDBConnection.class);

	public Connection getConnection() {
		Connection con = null;
		// Live Db Details
		String ip = "payplatterdb.ccjji9el8hsw.ap-south-1.rds.amazonaws.com";
		String port = "3306";
		String dbName = "pp_reports";
		String username = "dexpertadmin";
		String password = "Dspl_2015";
		
		// Local/UAT Db Deails
	/*	String ip = "localhost";
		String port = "3306";
		String dbName = "pp_reports";
		String username = "root";
		String password = "Pspl_2018";*/
		
		// Local DB Connection Details
		
		/*String ip = "localhost";
		String port = "3306";
		String dbName = "pp_reports";
		String username = "root";
		String password = "root";
		*/
		String DB_URL = "jdbc:mysql://" + ip + ":" + port + "/" + dbName + "";
		logger.info("DB_URL == " + DB_URL);
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}

		try {
			con = DriverManager.getConnection(DB_URL, username, password);
			logger.info( dbName+" Database Connected :)");
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return con;
	}
	

}
