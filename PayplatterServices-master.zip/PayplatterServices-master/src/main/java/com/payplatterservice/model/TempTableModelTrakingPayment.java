package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;


@Entity
@Table(name = "temp_tp_49")
public class TempTableModelTrakingPayment implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer id;
	private Integer form_instanceId;
	private String transId, ppTransId, pgTransId, transAmount, challanNo, status, transPaymode, updateByJob, firstName,
	lastName, Contact, email, division, trekName, trekRate, noofpax, gst5, totaltax, receiptexcludingtax,
	refundamt, netreceiptforallocation, modeofBooking, totalamt, trekDate;
	
	
	private Date modifiedDate,created_date;
	
	@Transient
	private String pgId_Fk, tempMID_Fk;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getForm_instanceId() {
		return form_instanceId;
	}

	public void setForm_instanceId(Integer form_instanceId) {
		this.form_instanceId = form_instanceId;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getPpTransId() {
		return ppTransId;
	}

	public void setPpTransId(String ppTransId) {
		this.ppTransId = ppTransId;
	}

	public String getPgTransId() {
		return pgTransId;
	}

	public void setPgTransId(String pgTransId) {
		this.pgTransId = pgTransId;
	}

	public String getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(String transAmount) {
		this.transAmount = transAmount;
	}

	public String getChallanNo() {
		return challanNo;
	}

	public void setChallanNo(String challanNo) {
		this.challanNo = challanNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransPaymode() {
		return transPaymode;
	}

	public void setTransPaymode(String transPaymode) {
		this.transPaymode = transPaymode;
	}

	public String getUpdateByJob() {
		return updateByJob;
	}

	public void setUpdateByJob(String updateByJob) {
		this.updateByJob = updateByJob;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContact() {
		return Contact;
	}

	public void setContact(String contact) {
		Contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getTrekName() {
		return trekName;
	}

	public void setTrekName(String trekName) {
		this.trekName = trekName;
	}

	public String getTrekRate() {
		return trekRate;
	}

	public void setTrekRate(String trekRate) {
		this.trekRate = trekRate;
	}

	public String getNoofpax() {
		return noofpax;
	}

	public void setNoofpax(String noofpax) {
		this.noofpax = noofpax;
	}

	public String getGst5() {
		return gst5;
	}

	public void setGst5(String gst5) {
		this.gst5 = gst5;
	}

	public String getTotaltax() {
		return totaltax;
	}

	public void setTotaltax(String totaltax) {
		this.totaltax = totaltax;
	}

	public String getReceiptexcludingtax() {
		return receiptexcludingtax;
	}

	public void setReceiptexcludingtax(String receiptexcludingtax) {
		this.receiptexcludingtax = receiptexcludingtax;
	}

	public String getRefundamt() {
		return refundamt;
	}

	public void setRefundamt(String refundamt) {
		this.refundamt = refundamt;
	}

	public String getNetreceiptforallocation() {
		return netreceiptforallocation;
	}

	public void setNetreceiptforallocation(String netreceiptforallocation) {
		this.netreceiptforallocation = netreceiptforallocation;
	}

	public String getModeofBooking() {
		return modeofBooking;
	}

	public void setModeofBooking(String modeofBooking) {
		this.modeofBooking = modeofBooking;
	}

	public String getTotalamt() {
		return totalamt;
	}

	public void setTotalamt(String totalamt) {
		this.totalamt = totalamt;
	}

	public String getTrekDate() {
		return trekDate;
	}

	public void setTrekDate(String trekDate) {
		this.trekDate = trekDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}


	public String getPgId_Fk() {
		return pgId_Fk;
	}

	public void setPgId_Fk(String pgId_Fk) {
		this.pgId_Fk = pgId_Fk;
	}

	public String getTempMID_Fk() {
		return tempMID_Fk;
	}

	public void setTempMID_Fk(String tempMID_Fk) {
		this.tempMID_Fk = tempMID_Fk;
	}

	
}
