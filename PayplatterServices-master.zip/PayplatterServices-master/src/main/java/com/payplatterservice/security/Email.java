package com.payplatterservice.security;

import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.swing.text.Document;
import javax.swing.text.EditorKit;
import javax.swing.text.html.HTMLEditorKit;
import javax.ws.rs.core.MediaType;

import org.jboss.logging.Logger;
import org.springframework.http.client.ClientHttpRequest;

import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayerModel;
import com.sun.jersey.api.client.*;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.multipart.FormDataMultiPart;



public class Email {
	private static final Logger logger = Logger.getLogger(Email.class);
	
	
	final String appLink = "https://app.payplatter.in/#/app/DirectLogin";
	final String adminMailId ="anupam@dexpertsystems.com";
	//final String IMAGE_PATH = "E://Logos//payplatter.jpg";
	//final String image = "payplatter.jpg";
	final String from = "support@payplatter.in";// "support@payplatter.in";
	String msg = "Thank you for transacting with PlatterPay";
	String msg1 = "Your Transaction details are as follows";
	String payplatterTxnLabel = "payplatter Transaction ID";
	String clientTxnIdLabel = "Client Transaction ID";
	String paymentModeLabel = "Payment Mode";
	String amountLabel = "Amount";
	String dateLabel = "Transaction Date";
	String uinLabel = "Student UIN";
	String clientNameLabel = "Client Name";
	String statusLabel = "Payment Status";
	String challanLabel = "Challan Number";
	String lastData = "<br><h4>for further queries please mailed us on <b>support@dexpertsystems.com</b> or you may visit us at <a href='https://payplatter.in/'>payplatter.in/</a> and <a href='https://payplatter.in/'>Dexpert Systems Pvt. Ltd.</a></h4>";

	String apiKey = "key-473e89a80b5cb8acde3a810c9a18022a";
	String mailgunUrl = "https://api.mailgun.net/v3/app.payplatter.in" + "/messages";
	public ClientResponse sendLogincredtoPayer(String to, String sub, String urlAppLink,
			String payerName, String payerUserName, String payerPassword,
			String merchantName, PayerModel payerModel, MerchantsModel merchantModel) {
		// TODO Auto-generated method stub
		logger.info("In Mail CLassss");
		
	Client client = Client.create();
	payerName = payerName.replaceAll("(?i)null", "");
		merchantName = merchantName.replaceAll("(?i)null", "");
		client.addFilter(new HTTPBasicAuthFilter("api", apiKey));
		WebResource webResource = client.resource(mailgunUrl);
		FormDataMultiPart form = new FormDataMultiPart();
		form.field("from", from);
		form.field("to", to);
		form.field("subject", sub);
		String encryptedUserPass = "&userName=" + payerUserName + "&password=" + payerPassword;
		try {
			encryptedUserPass = Encryption.encrypt("dexpertappencdec", "0000000000000000", encryptedUserPass);
		} catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException
				| InvalidAlgorithmParameterException | NoSuchAlgorithmException | NoSuchPaddingException
				| UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		encryptedUserPass = "?param=" + encryptedUserPass;
		urlAppLink = appLink + encryptedUserPass;
		String reg_no = "<br />";
		
		try {
			reg_no = payerModel.getRegistration_no();
			reg_no = reg_no.replaceAll("(?i)null", "");
			if (reg_no.equals("") || reg_no != null) {
				reg_no = "<br /><p><strong>Member Id: </strong>" + reg_no + "</p>";
			}
		} catch (Exception e) {
			reg_no = "<br />";
			logger.info("Reg Id not Found");
		}
		
		String body = "<p>Dear <strong>" + payerName + "</strong>,</p>" + "<p>M/s  <strong>" + merchantName
				+ " </strong> just added you as as their customer.</p>"
				+ "<p>We just created a beautiful app for you that you can run on your mobile without any installation. This app will be pretty handy for you to transact with M/s  <strong> "
				+ merchantName + " </strong> and will run on your PC too.</p>"
				+ "<p><strong>How to Install Payplatter App :</strong></p>" + "<ul style='list-style-type: circle;'>"
				+ "<li>Click on triple dots (<strong> ...</strong>) , near right top corner of your browser.</li>"
				+ "<li>Click on option <strong>Add to Home Screen</strong>.</li>" + "<li>Wait till processing.</li>"
				+ "<li><strong>PayPlatter App</strong> installed at your<strong> Home Screen.</strong></li>" + "</ul>"
				+ "<p>Please <a href=" + urlAppLink + " target='_blank'>" + "Click Here"
				+ "</a> and sign in with the below credentials</p>" + "<p><br /><strong>UserName: </strong>" + payerUserName
				+ "<br /><strong>Password: </strong>" + payerPassword + "</p>" + reg_no
				+ "<p>Do reach out to us with any queries or feedback.</p>"
				+ "<p>Regards,<br />Team PayPlatter<br />email:info@payplatter.in<br />phone:9987890900</p>";
		logger.info("In Mail CLassssvxxxxxzx");
		form.field("html", body);
		logger.info("In Mail CLassssxcxcxcfrfddfredr");
		
		System.out.println("Mail Sent to welcome payer with creds..to " + to);
		ClientResponse response = webResource.type(MediaType.MULTIPART_FORM_DATA_TYPE).post(ClientResponse.class, form);
		int resp_status = response.getStatus();
		if (resp_status == 200) {
			String txt_body = html2text("<html> " + body + "</html>");
		
		}
		return response;
	}


	public static final String html2text(String html) {
		EditorKit kit = new HTMLEditorKit();
		Document doc = kit.createDefaultDocument();
		doc.putProperty("IgnoreCharsetDirective", Boolean.TRUE);
		try {
			Reader reader = new StringReader(html);
			kit.read(reader, doc, 0);
			return doc.getText(0, doc.getLength());
		} catch (Exception e) {

			return "";
		}
	}

}
