package com.payplatterservice.controller;

import java.io.Serializable;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.payplatterservice.operationservice.PlatterPayOnboarding;
import com.payplatterservice.service.PlatterPayOnBoardingServices;
import com.platterpayservices.model.ClientDetails;
import com.platterpayservices.model.ClientDetailsMapping;
import com.platterpayservices.model.EndpointDataModel;
import com.platterpayservices.model.FeeDataModel;

@RestController
public class PlatterPayOnBoardingActionController implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger logger = Logger.getLogger(PlatterPayOnBoardingActionController.class);
	
	@Autowired
	PlatterPayOnBoardingServices platterPayServices;
	
	@Autowired
	PlatterPayOnboarding platterPayOperation;
	
	@RequestMapping(value="onBoardPlatterPayClient",method=RequestMethod.POST,produces="application/json")
	public String onBoardPlatterPayClient(@RequestBody ClientDetails clientDetails, UriComponentsBuilder ucBuilder){
		ClientDetailsMapping clientMapping=new ClientDetailsMapping();
		
		
		clientDetails=platterPayOperation.generateClientDetails(clientDetails);
		
		clientDetails=platterPayServices.onBoardClient(clientDetails);
		
		if (clientDetails!=null) {
			System.out.println("Return ID : "+clientDetails.getClientId());
			EndpointDataModel ep=platterPayServices.getEPDetails("epName","Instamojo");
			clientMapping=platterPayServices.saveClientMappingDetails(clientDetails,ep);
			System.out.println("Return Mapping ID : "+clientMapping.getMappingId());
			if (clientMapping!=null) {
				FeeDataModel feeDetails=platterPayServices.getFeeDetails("configurationType", "DEFAULT");
				System.out.println("Fee Details :: "+feeDetails.getFeeId());
				if (feeDetails!=null) {
					int count=platterPayServices.saveIntoMappling(feeDetails,clientMapping);
				}
			}
			
		}else{
			
		}
		
		
		return null;
	}
	
	
	@RequestMapping(value="/getFeeDetails/",method=RequestMethod.POST,produces="application/json")
	public FeeDataModel getFeeDetails(@RequestBody FeeDataModel fee, UriComponentsBuilder ucBuilder){
		
		
			fee=platterPayServices.setDefaultFeeConfigurations(fee);
		
		return fee;
	}
	

}
