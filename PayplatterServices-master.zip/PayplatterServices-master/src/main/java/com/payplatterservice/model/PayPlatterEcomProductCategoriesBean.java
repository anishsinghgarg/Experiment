package com.payplatterservice.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;



@Entity
@Table(name = "product_categories")
public class PayPlatterEcomProductCategoriesBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer Id;
	private String prod_name;
	
	@Column(name="prod_code",unique = true)
	private String prod_code;

	@OneToMany(mappedBy = "productCategoriesBean")
	List<PayPlatterEcomProductSubCategoriesBean> productSubCategoriesBean;
	
	
	@OneToMany(mappedBy = "productCategoriesBean")
	List<PayPlatterEcomMerchantProductCategoriesConfBean> merchantProductCategoriesConfBean;
	
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getProd_name() {
		return prod_name;
	}

	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}

	public String getProd_code() {
		return prod_code;
	}

	public void setProd_code(String prod_code) {
		this.prod_code = prod_code;
	}

	public List<PayPlatterEcomProductSubCategoriesBean> getProductSubCategoriesBean() {
		return productSubCategoriesBean;
	}

	public void setProductSubCategoriesBean(List<PayPlatterEcomProductSubCategoriesBean> productSubCategoriesBean) {
		this.productSubCategoriesBean = productSubCategoriesBean;
	}

	public List<PayPlatterEcomMerchantProductCategoriesConfBean> getMerchantProductCategoriesConfBean() {
		return merchantProductCategoriesConfBean;
	}

	public void setMerchantProductCategoriesConfBean(
			List<PayPlatterEcomMerchantProductCategoriesConfBean> merchantProductCategoriesConfBean) {
		this.merchantProductCategoriesConfBean = merchantProductCategoriesConfBean;
	}
	
	
}
