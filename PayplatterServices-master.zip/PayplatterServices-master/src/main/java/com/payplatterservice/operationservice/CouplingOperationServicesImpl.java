package com.payplatterservice.operationservice;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payplatterservice.model.Login;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PaymentProcessorModel;
import com.payplatterservice.security.Encryption;
import com.payplatterservice.security.KeyGenerator;
import com.payplatterservice.service.CouplingProjectService;
import com.payplatterservice.service.LoginService;

@Repository
public class CouplingOperationServicesImpl implements CouplingOperationServices {

	@Autowired
	CouplingProjectService couplingServices;
	@Autowired
	LoginService loginServices;

	private static final Logger logger = Logger.getLogger(CouplingOperationServicesImpl.class);

	@Override
	public String isMerchantExist(MerchantsModel model) {
		Login login = new Login();
		String statusMsg = null;
		String statusCode = null;
		String returnStatus = null;
		String status = null;
		String loginStatus = null;
		boolean isExist = false;
		boolean isMerchantExist = false;
		
		
		Long rowCount=couplingServices.getTotalRowCount();
		
		logger.info("Total Row Count : "+rowCount);
		
		isMerchantExist = couplingServices.isMerchantExistInMerchantMaster(model);
		isExist = couplingServices.isMerchantExist(model);
		logger.info("Checking Retuen Status :: " + isExist);

		if (isExist == false) {
			logger.info("In if Condition Checking Retuen Status :: " + isExist);

			// Development Needed HERE
			if (isMerchantExist == false) {
				// Creating Merchant Code
				String mCode = null;
				try {
					mCode = model.getLegalBusinessName().replaceAll("[^a-zA-Z0-9]", "").toUpperCase().substring(0, 3);
				} catch (Exception ex) {
					// TODO: handle exception

					if (ex instanceof StringIndexOutOfBoundsException) {
						mCode = "DEX";
						logger.info("String_Index_Out_Of_Bound During Generating MCode :: " + ex.getMessage());
						throw ex;
					} else {
						logger.info("Exception During Generating MCode :: " + ex.getMessage());

						mCode = "DEX";
					}

				}

				// PaymentProcessor Bean

				PaymentProcessorModel paymentModel = couplingServices.paymentProcessorDetails(model.getPgId_Fk());
				model.setMcode(mCode);
				model.setPaymentProcessorBean(paymentModel);
				model.setStatus("pending");
				model.setCreatedDate(new Date());
				model.setOmniportSetupFlag("Y");
				model.setOmniportSetupStage(0);
				model.setSms_counter(0);
				model.setIsCommissionSetup("No");
				model.setIsPreferencesSetup("N");
				// Saving Merchant Details
				model = couplingServices.saveMerchantInfoDetails(model);
				if (model != null) {

					// Creating Login Details

					try {
						login = createMerchantLoginDetails(model);
						if (login != null || login.getUserName() != null || login.getPassword() != null) {
							statusMsg = "Merchant Added Success!!!!!";
							status = "SUCCESS";
							statusCode = "0000";

							returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode
									+ "\",\"Status Msg\":\"" + statusMsg + "\",\"Login UserName\":\""
									+ login.getUserName() + "\",\"Login Password\":\"" + login.getPassword()
									+ "\",\"Merchant ID\":\"" + login.getMerchantsBean().getId()
									+ "\",\"Legal Business Name\":\"" + login.getMerchantsBean().getLegalBusinessName()
									+ "\"}";
						} else {
							statusMsg = "Merchant Not Added Success!!!!!";
							status = "FAIL";
							statusCode = "4444";
							
							returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode
									+ "\",\"Status Msg\":\"" + statusMsg + "\",\"Login Error\":\"No Login Details ::\"}";
						}
					} catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException
							| InvalidAlgorithmParameterException | NoSuchAlgorithmException | NoSuchPaddingException
							| UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						statusMsg = "Server Error!!!!!";
						status = "FAIL";
						statusCode = "7777";
						
						returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode
								+ "\",\"Status Msg\":\"" + statusMsg + "\",\"Login Error\":\"No Login Details ::\"}";
						e.printStackTrace();
					}

				} else {
					statusMsg = "Merchant Not Added Success!!!!!";
					status = "FAIL";
					statusCode = "1111";
				}

				returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode + "\",\"Status Msg\":\""
						+ statusMsg + "\"}";
			} else {
				statusMsg = "Merchant NOT Added Email or Contact Already Available in PayPlatter System!!!!!";
				status = "FAIL";
				statusCode = "55555";
				returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode + "\",\"Status Msg\":\""
						+ statusMsg + "\"}";
			}

		} else {
			statusMsg = "Merchant NOT Added Email or Contact Already Available in PayPlatter System!!!!!";
			status = "FAIL";
			statusCode = "3333";
			returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode + "\",\"Status Msg\":\""
					+ statusMsg + "\"}";
		}

		return returnStatus;
	}

	private Login createMerchantLoginDetails(MerchantsModel model) throws InvalidKeyException,
			IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException,
			NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		Login login = new Login();

		login.setFirstName(model.getfName());
		login.setLastName(model.getlName());
		login.setEmailId(model.getEmailId());
		login.setContact_no(model.getContact());
		login.setProfile("MERCHANT");
		login.setCreatedDate(new Date());
		login.setMerchantsBean(model);
		login.setModifiedPassDate(new Date());
		login.setIs_first_login("Y");

		String username = KeyGenerator.usenameLogic(model.getEmailId());
		username = "M".concat(username.toUpperCase().concat(model.getId().toString()));
		login.setUserName(username);

		String password = KeyGenerator.generatePswd(6, 8, 1, 2, 0);
		password = Encryption.encrypt("passwordmuskilba", "1234567898765432", password);
		login.setPassword(password);

		try {
			login = loginServices.createLogin(login);
		} catch (Exception e) {
			// TODO: handle exception
			login = null;
		}

		return login;
	}

}
