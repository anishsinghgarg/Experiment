package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "temp_tp_48")
public class TempTableMISDataEcoTouristCenterModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer id;
	private Integer form_instanceId;
	private String transId, ppTransId, pgTransId, transAmount, challanNo, status, transPaymode, updateByJob, firstName,
			lastName, contact, email, checkInDate, checkOUTDate, noRooms, noofDays, roomPayment, gST0TOLESSTHAN1000,
			gST1000to2499, gST2500to7499, totalamt, refund, modeofBooking, division, ecotourismcentre,
			netReceiptexcludingTax, totalTax,clientRefNumber;

	private Date created_date, modifiedDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getForm_instanceId() {
		return form_instanceId;
	}

	public void setForm_instanceId(Integer form_instanceId) {
		this.form_instanceId = form_instanceId;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getPpTransId() {
		return ppTransId;
	}

	public void setPpTransId(String ppTransId) {
		this.ppTransId = ppTransId;
	}

	public String getPgTransId() {
		return pgTransId;
	}

	public void setPgTransId(String pgTransId) {
		this.pgTransId = pgTransId;
	}

	public String getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(String transAmount) {
		this.transAmount = transAmount;
	}

	public String getChallanNo() {
		return challanNo;
	}

	public void setChallanNo(String challanNo) {
		this.challanNo = challanNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransPaymode() {
		return transPaymode;
	}

	public void setTransPaymode(String transPaymode) {
		this.transPaymode = transPaymode;
	}

	public String getUpdateByJob() {
		return updateByJob;
	}

	public void setUpdateByJob(String updateByJob) {
		this.updateByJob = updateByJob;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	public String getCheckOUTDate() {
		return checkOUTDate;
	}

	public void setCheckOUTDate(String checkOUTDate) {
		this.checkOUTDate = checkOUTDate;
	}

	public String getNoRooms() {
		return noRooms;
	}

	public void setNoRooms(String noRooms) {
		this.noRooms = noRooms;
	}

	public String getNoofDays() {
		return noofDays;
	}

	public void setNoofDays(String noofDays) {
		this.noofDays = noofDays;
	}

	public String getRoomPayment() {
		return roomPayment;
	}

	public void setRoomPayment(String roomPayment) {
		this.roomPayment = roomPayment;
	}

	public String getgST0TOLESSTHAN1000() {
		return gST0TOLESSTHAN1000;
	}

	public void setgST0TOLESSTHAN1000(String gST0TOLESSTHAN1000) {
		this.gST0TOLESSTHAN1000 = gST0TOLESSTHAN1000;
	}

	public String getgST1000to2499() {
		return gST1000to2499;
	}

	public void setgST1000to2499(String gST1000to2499) {
		this.gST1000to2499 = gST1000to2499;
	}

	public String getgST2500to7499() {
		return gST2500to7499;
	}

	public void setgST2500to7499(String gST2500to7499) {
		this.gST2500to7499 = gST2500to7499;
	}

	public String getTotalamt() {
		return totalamt;
	}

	public void setTotalamt(String totalamt) {
		this.totalamt = totalamt;
	}

	public String getRefund() {
		return refund;
	}

	public void setRefund(String refund) {
		this.refund = refund;
	}

	public String getModeofBooking() {
		return modeofBooking;
	}

	public void setModeofBooking(String modeofBooking) {
		this.modeofBooking = modeofBooking;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getEcotourismcentre() {
		return ecotourismcentre;
	}

	public void setEcotourismcentre(String ecotourismcentre) {
		this.ecotourismcentre = ecotourismcentre;
	}

	public String getNetReceiptexcludingTax() {
		return netReceiptexcludingTax;
	}

	public void setNetReceiptexcludingTax(String netReceiptexcludingTax) {
		this.netReceiptexcludingTax = netReceiptexcludingTax;
	}

	public String getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(String totalTax) {
		this.totalTax = totalTax;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getClientRefNumber() {
		return clientRefNumber;
	}

	public void setClientRefNumber(String clientRefNumber) {
		this.clientRefNumber = clientRefNumber;
	}

}
