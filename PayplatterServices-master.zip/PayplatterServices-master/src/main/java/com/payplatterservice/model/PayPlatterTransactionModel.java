package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;


@Entity
@Table(name = "transactions_details")
public class PayPlatterTransactionModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id

	  @GenericGenerator(
	        name = "table",
	        strategy = "enhanced-table",
	        parameters = {
	            @org.hibernate.annotations.Parameter(
	                name = "table_name",
	                value = "sequence_table"
	            )
	    })

	@GeneratedValue(generator = "table", strategy=GenerationType.TABLE)
	private Integer id;
	@Column(name = "ppTransId", unique = true)
	private String ppTransId;
	@Column(name = "transId", unique = true)
	private String transId;
	private String transStatus, transPaymode;
	@Temporal(TemporalType.TIMESTAMP)
	private Date txncloseDate;
	@JsonSerialize(using=ToStringSerializer.class)
	private Double transAmount, actAmount;
	private String address, name, email, contact, refundJob, challanNo;
	private String payer_type;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer operator_id,payment_processor_id;
	@Transient
	private String pgId_Fk, tempMID_Fk;
	private Date dob;


	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "txnCreateDate", nullable = false, columnDefinition = "TIMESTAMP default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP")
	private Date txnCreateDate = new Date();
	private String issuerRefNo, pgTransId, ppRespCode, pgRespCode,  feeName, transCharges,
			unique_identifier_number;
	private String transaction_type, payment_type;

	
	private String payment_context_unique_no;
	private String late_fee;
	private String rebate,comments,extra_form_data;
	@Column(columnDefinition = "varchar(800)")
	private String remark;

	@Column(columnDefinition = "varchar(255) default 'N'")
	private String istxn_bysync;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "payee_merchant_id_fk", referencedColumnName = "id")
	private MerchantsModel merchantsBean;
	
	@Transient
	private String filterflag;
	
	@Transient
	private String fromDate;
	
	@Transient
	private String toDate;
	

	public Integer getId() {
		return id;
	}

	

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPpTransId() {
		return ppTransId;
	}

	public void setPpTransId(String ppTransId) {
		this.ppTransId = ppTransId;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getTransStatus() {
		return transStatus;
	}

	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}

	public String getTransPaymode() {
		return transPaymode;
	}

	public void setTransPaymode(String transPaymode) {
		this.transPaymode = transPaymode;
	}



	public Date getTxncloseDate() {
		return txncloseDate;
	}

	public void setTxncloseDate(Date txncloseDate) {
		this.txncloseDate = txncloseDate;
	}

	public Double getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(Double transAmount) {
		this.transAmount = transAmount;
	}

	public Double getActAmount() {
		return actAmount;
	}

	public void setActAmount(Double actAmount) {
		this.actAmount = actAmount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getRefundJob() {
		return refundJob;
	}

	public void setRefundJob(String refundJob) {
		this.refundJob = refundJob;
	}

	public String getChallanNo() {
		return challanNo;
	}

	public void setChallanNo(String challanNo) {
		this.challanNo = challanNo;
	}

	public String getPayer_type() {
		return payer_type;
	}

	public void setPayer_type(String payer_type) {
		this.payer_type = payer_type;
	}

	public Integer getOperator_id() {
		return operator_id;
	}

	public void setOperator_id(Integer operator_id) {
		this.operator_id = operator_id;
	}

	public String getPgId_Fk() {
		return pgId_Fk;
	}

	public void setPgId_Fk(String pgId_Fk) {
		this.pgId_Fk = pgId_Fk;
	}

	public String getTempMID_Fk() {
		return tempMID_Fk;
	}

	public void setTempMID_Fk(String tempMID_Fk) {
		this.tempMID_Fk = tempMID_Fk;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getTxnCreateDate() {
		return txnCreateDate;
	}

	public void setTxnCreateDate(Date txnCreateDate) {
		this.txnCreateDate = txnCreateDate;
	}

	public String getIssuerRefNo() {
		return issuerRefNo;
	}

	public void setIssuerRefNo(String issuerRefNo) {
		this.issuerRefNo = issuerRefNo;
	}

	public String getPgTransId() {
		return pgTransId;
	}

	public void setPgTransId(String pgTransId) {
		this.pgTransId = pgTransId;
	}

	public String getPpRespCode() {
		return ppRespCode;
	}

	public void setPpRespCode(String ppRespCode) {
		this.ppRespCode = ppRespCode;
	}

	public String getPgRespCode() {
		return pgRespCode;
	}

	public void setPgRespCode(String pgRespCode) {
		this.pgRespCode = pgRespCode;
	}


	public String getFeeName() {
		return feeName;
	}

	public void setFeeName(String feeName) {
		this.feeName = feeName;
	}

	public String getTransCharges() {
		return transCharges;
	}

	public void setTransCharges(String transCharges) {
		this.transCharges = transCharges;
	}

	public String getUnique_identifier_number() {
		return unique_identifier_number;
	}

	public void setUnique_identifier_number(String unique_identifier_number) {
		this.unique_identifier_number = unique_identifier_number;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getPayment_type() {
		return payment_type;
	}

	public void setPayment_type(String payment_type) {
		this.payment_type = payment_type;
	}

	public String getIstxn_bysync() {
		return istxn_bysync;
	}

	public void setIstxn_bysync(String istxn_bysync) {
		this.istxn_bysync = istxn_bysync;
	}

	public MerchantsModel getMerchantsBean() {
		return merchantsBean;
	}

	public void setMerchantsBean(MerchantsModel merchantsBean) {
		this.merchantsBean = merchantsBean;
	}

	public String getFilterflag() {
		return filterflag;
	}

	public void setFilterflag(String filterflag) {
		this.filterflag = filterflag;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getPayment_processor_id() {
		return payment_processor_id;
	}

	public void setPayment_processor_id(Integer payment_processor_id) {
		this.payment_processor_id = payment_processor_id;
	}

	public String getPayment_context_unique_no() {
		return payment_context_unique_no;
	}

	public void setPayment_context_unique_no(String payment_context_unique_no) {
		this.payment_context_unique_no = payment_context_unique_no;
	}

	public String getLate_fee() {
		return late_fee;
	}

	public void setLate_fee(String late_fee) {
		this.late_fee = late_fee;
	}

	public String getRebate() {
		return rebate;
	}

	public void setRebate(String rebate) {
		this.rebate = rebate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}



	public String getExtra_form_data() {
		return extra_form_data;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public void setExtra_form_data(String extra_form_data) {
		this.extra_form_data = extra_form_data;
	}

	
}
