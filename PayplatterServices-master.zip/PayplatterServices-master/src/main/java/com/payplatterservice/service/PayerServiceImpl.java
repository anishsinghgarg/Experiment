package com.payplatterservice.service;

import com.payplatterservice.model.BusinessModel;
import com.payplatterservice.model.CityModel;
import com.payplatterservice.model.FormDetailsModel;
import com.payplatterservice.model.CustomerRequestModel;
import com.payplatterservice.model.IndustryModel;
import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantServicesDetailsBean;
import com.payplatterservice.model.MerchantServicesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.MessageConfigurationModel;
import com.payplatterservice.model.MessageModel;
import com.payplatterservice.model.PayerDocumentModel;
import com.payplatterservice.model.PayerMenuModel;
import com.payplatterservice.model.PayerMerchantModel;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PayplatterBusinessContextServiceMappings;
import com.payplatterservice.model.PayplatterBusinessContexts;
import com.payplatterservice.model.PayplatterCentralInvoicesModel;
import com.payplatterservice.model.PersonnelAppointmentModel;
import com.payplatterservice.model.SampleFormModel;
import com.payplatterservice.model.SearchKeyModel;
import com.payplatterservice.model.ServicesMasterModel;
import com.payplatterservice.model.StateModel;
import com.payplatterservice.model.TransitportAssetReservationsModel;
import com.payplatterservice.model.TransitportAssetAvailabilityModel;
import com.payplatterservice.model.TransitportAssetsModel;
import com.payplatterservice.model.TransitportPersonnelModel;
import com.payplatterservice.model.VenueAppointmentModel;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PayerServiceImpl implements PayerService {

	private static final Logger logger = Logger.getLogger(PayerServiceImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	public PayerServiceImpl() {
	}

	@Override
	public PayerModel getPayerDetailsById(PayerModel model) {
		Session session = sessionFactory.openSession();

		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayerModel> query = builder.createQuery(PayerModel.class);
			Root<PayerModel> root = query.from(PayerModel.class);

			query.select(root).where(builder.equal(root.get("id"), model.getId()));

			Query<PayerModel> q = session.createQuery(query);
			model = q.getResultList().get(0);
			logger.info(" In Payer DAO :: "+model.getId());
			return model;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	public PayplatterCentralInvoicesModel getPayerInvoice(PayplatterCentralInvoicesModel model) {
		Session session = sessionFactory.openSession();
		try {
			return (PayplatterCentralInvoicesModel) session.get(PayplatterCentralInvoicesModel.class,
					model.getInvoice_id());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	public List<PayplatterCentralInvoicesModel> getPayerInvoiceList(PayplatterCentralInvoicesModel model) {
		Session session = sessionFactory.openSession();
		List<PayplatterCentralInvoicesModel> result = new ArrayList<PayplatterCentralInvoicesModel>();

		try {

			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayplatterCentralInvoicesModel> query = builder
					.createQuery(PayplatterCentralInvoicesModel.class);
			Root<PayplatterCentralInvoicesModel> root = query.from(PayplatterCentralInvoicesModel.class);

			if (model.getInvoice_id().intValue() == 0) {

				query.select(root).where(builder.and(builder.equal(root.get("payer_id"), model.getPayer_id())),
						builder.equal(root.get("merchant_id"), model.getMerchant_id()));

			}
			if (model.getInvoice_id().intValue() > 0) {

				Expression<Integer> name = root.get("invoice_id");

				query.select(root).where(builder.and(builder.equal(root.get("payer_id"), model.getPayer_id())),
						builder.equal(root.get("merchant_id"), model.getMerchant_id()),
						builder.lt(name, model.getInvoice_id()));

			}
			query.select(root).orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("invoice_id")) });
			Query<PayplatterCentralInvoicesModel> q = session.createQuery(query).setMaxResults(10);
			result = q.getResultList();
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return result;
		} finally {
			session.clear();
			session.close();
		}
	}

	public List<MerchantsModel> getMerchantList(PayerModel model) {
		Session session = sessionFactory.openSession();
		List<MerchantsModel> result = new ArrayList();

		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayerMerchantModel> query = builder.createQuery(PayerMerchantModel.class);
			Root<PayerMerchantModel> root = query.from(PayerMerchantModel.class);

			query.select(root).where(builder.equal(root.get("payerBean").get("id"), model.getId()));
			Query<PayerMerchantModel> q = session.createQuery(query);
			if (q.getResultList().size() > 0) {
				for (PayerMerchantModel bean : q.getResultList()) {
					result.add(bean.getMerchantsBean());
				}
			}
			logger.info("Result Size ::" + result.size());
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return result;
		} finally {
			session.clear();
			session.close();
		}

	}

	@SuppressWarnings("deprecation")
	public List<MerchantServicesDetailsBean> getServicesList(MerchantsModel model) {
		Session session = sessionFactory.openSession();
		List<MerchantServicesDetailsBean> fresult = new ArrayList<MerchantServicesDetailsBean>();
		List<ServicesMasterModel> result = new ArrayList();
		List<MerchantServicesModel> list = new ArrayList();

		try {
			Integer mid = model.getId();
			String sql = "SELECT bcsm.status as status,bcsm.context_id as context_id,bcsm.form_id as form_id,bcsm.service_id as service_id,bcsm.payment_flow_id as payment_flow_id ,mm.id as mid,msc.description as servicesName,ppm.id as pgid FROM PayplatterBusinessContextServiceMappings bcsm, ServicesMasterModel msc,MerchantsModel mm, PaymentProcessorModel ppm where merchant_id = "
					+ mid
					+ " and bcsm.service_id = msc.id and mm.id = bcsm.merchant_id and ppm.id = mm.paymentProcessorBean.id";
			logger.info("sql is::" + sql);
			Query query = session.createQuery(sql);
			query.setResultTransformer(Transformers.aliasToBean(MerchantServicesDetailsBean.class));
			fresult = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.clear();
			session.close();
		}
		return fresult;
	}

	public CustomerRequestModel saveCustomerConversionData(CustomerRequestModel customerReqModel) {
		Session session = sessionFactory.openSession();
		try {

			session.beginTransaction();
			session.saveOrUpdate(customerReqModel);
			session.getTransaction().commit();

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception While Saving Customer Conversion : " + e.getMessage());
		} finally {
			session.clear();
			session.close();
		}
		return customerReqModel;
	}

	public List<CustomerRequestModel> getCustomerConversion(CustomerRequestModel customerModel, String key) {
		Session session = sessionFactory.openSession();
		List<CustomerRequestModel> list = new ArrayList();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<CustomerRequestModel> query = builder.createQuery(CustomerRequestModel.class);
			Root<CustomerRequestModel> root = query.from(CustomerRequestModel.class);

			if (key.equals("PAYERID")) {
				query.select(root).where(
						builder.and(builder.equal(root.get("payerBean").get("id"), customerModel.getPayerId())),
						builder.equal(root.get("merchant_id"), customerModel.getMerchant_id()));
			}
			if (key.equals("request_id")) {
				query.select(root).where(builder.equal(root.get("request_id"), customerModel.getRequest_id()));
			}
			if (key.equals("requestFlag")) {
				query.select(root).where(builder.equal(root.get("requestFlag"), "NEW"));
			}
			Query<CustomerRequestModel> q = session.createQuery(query);
			return q.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	public List<MessageModel> getMessageList(MessageConfigurationModel model) {
		Session session = sessionFactory.openSession();
		List<MessageConfigurationModel> list = new ArrayList();
		List<MessageModel> result = new ArrayList();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<MessageConfigurationModel> query = builder.createQuery(MessageConfigurationModel.class);
		Root<MessageConfigurationModel> root = query.from(MessageConfigurationModel.class);
		try {

			if (model.getId().intValue() == 0) {
				query.select(root).where(builder.and(builder.equal(root.get("payerId"), model.getPayerId()),
						builder.equal(root.get("createdBy"), model.getCreatedBy())));

			}
			if (model.getId().intValue() > 0) {

				Expression<Integer> name = root.get("id");
				query.select(root).where(builder.and(builder.equal(root.get("payerId"), model.getPayerId()),
						builder.equal(root.get("createdBy"), model.getCreatedBy()), builder.lt(name, model.getId())));

			}
			query.select(root).orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });
			Query<MessageConfigurationModel> q = session.createQuery(query).setMaxResults(10);
			if (q.getResultList().size() > 0) {
				for (MessageConfigurationModel messageConfig : q.getResultList()) {
					result.add(messageConfig.getMessageModel());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.clear();
			session.close();
		}
		return result;
	}

	public MessageModel getMessageDetails(MessageModel model) {
		Session session = sessionFactory.openSession();

		return (MessageModel) session.get(MessageModel.class, model.getMsgId());
	}

	public List<PayerDocumentModel> getPayerMerchantDocuments(PayerDocumentModel model) {
		Session session = sessionFactory.openSession();

		List<PayerDocumentModel> list = new ArrayList();
		try {
			PayerModel payerModel = new PayerModel();
			payerModel.setId(Integer.valueOf(Integer.parseInt(model.getPayerId())));
			model.setPayerBean(payerModel);
			logger.info("Payer ID ::" + model.getPayerBean().getId());
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayerDocumentModel> query = builder.createQuery(PayerDocumentModel.class);
			Root<PayerDocumentModel> root = query.from(PayerDocumentModel.class);
			if (model.getId().intValue() == 0) {
				query.select(root)
						.where(builder.and(builder.equal(root.get("merchant_id"), model.getMerchant_id()),
								builder.equal(root.get("payerBean").get("id"),
										Integer.valueOf(model.getPayerBean().getId().intValue()))));

			}
			if (model.getId().intValue() > 0) {
				Expression<Integer> name = root.get("id");
				/*
				 * Predicate pageinationCriteria = builder.lt(name,
				 * model.getId());
				 * query.select(root).where(pageinationCriteria);
				 */
				query.select(root)
						.where(builder.and(builder.equal(root.get("merchant_id"), model.getMerchant_id()),
								builder.equal(root.get("payerBean").get("id"),
										Integer.valueOf(model.getPayerBean().getId().intValue())),
								builder.lt(name, model.getId())));

			}
			query.select(root).orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });

			Query<PayerDocumentModel> q = session.createQuery(query).setMaxResults(10);
			return q.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public SampleFormModel getBookingDetails(PayerModel model) {
		Session session = sessionFactory.openSession();
		SampleFormModel bean = new SampleFormModel();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<SampleFormModel> query = builder.createQuery(SampleFormModel.class);
			Root<SampleFormModel> root = query.from(SampleFormModel.class);

			query.select(root).where(builder.equal(root.get("payerID"), Integer.valueOf(model.getId())));
			Query<SampleFormModel> q = session.createQuery(query);
			bean = q.getResultList().get(0);
			return bean;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public FormDetailsModel getFormDetails(Integer formTemplateId) {
		Session session = sessionFactory.openSession();
		FormDetailsModel form = new FormDetailsModel();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<FormDetailsModel> query = builder.createQuery(FormDetailsModel.class);
			Root<FormDetailsModel> root = query.from(FormDetailsModel.class);

			logger.info("for Temp ID ::" + formTemplateId);
			query.select(root).where(builder.equal(root.get("id"), formTemplateId));
			Query<FormDetailsModel> q = session.createQuery(query);
			form = q.getSingleResult();
			logger.info(" FOrm " + form.getBusiness_context_bean_name());
			return form;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	public List<PersonnelAppointmentModel> getBookingAppointmentDetails(HashMap<String, Object> filter) {
		Session session = sessionFactory.openSession();
		List<PersonnelAppointmentModel> appmodel = new ArrayList<PersonnelAppointmentModel>();
		Integer filter_int;
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PersonnelAppointmentModel> query = builder.createQuery(PersonnelAppointmentModel.class);
			Root<PersonnelAppointmentModel> root = query.from(PersonnelAppointmentModel.class);
			if (filter != null) {
				if (filter.size() > 0) {
					List<String> keys = new ArrayList<String>(filter.keySet());
					for (int i = 0; i < keys.size(); i++) {
						if (keys.get(i).contentEquals("personnel_id")) {
							filter_int = (Integer) filter.get(keys.get(i));
							logger.info("Filer Int :" + filter_int);
							if (null != filter_int) {
								query.select(root).where(builder.equal(root.get("personnel_id"), filter_int));
							}

						}
						if (keys.get(i).contentEquals("form_instance_id")) {
							filter_int = (Integer) filter.get(keys.get(i));
							logger.info("Filer Int :" + filter_int);
							if (null != filter_int) {
								query.select(root).where(builder.equal(root.get("form_instance_id"), filter_int));
							}

						}
						if (keys.get(i).contentEquals("status")) {
							String status = (String) filter.get(keys.get(i));
							logger.info("Filer Int :" + status);
							if (null != status) {
								if ("ALL".equalsIgnoreCase(status) || null == status) {

								} else {
									query.select(root).where(builder.equal(root.get("status"), status));
								}
							}
						}

					}
				}
			}

			Query<PersonnelAppointmentModel> q = session.createQuery(query);
			appmodel = q.getResultList();
			return appmodel;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public List<TransitportPersonnelModel> getPersonnelsDetails(HashMap<String, Object> filter) {
		Session session = sessionFactory.openSession();
		List<TransitportPersonnelModel> personnels = new ArrayList<TransitportPersonnelModel>();
		ArrayList<Integer> personnelTakenList = new ArrayList<>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<TransitportPersonnelModel> query = builder.createQuery(TransitportPersonnelModel.class);
			Root<TransitportPersonnelModel> root = query.from(TransitportPersonnelModel.class);

			if (filter != null) {
				if (filter.size() > 0) {
					List<String> keys = new ArrayList<String>(filter.keySet());
					for (int i = 0; i < keys.size(); i++) {

						if (keys.get(i).contentEquals("personnel_id")) {
							personnelTakenList = (ArrayList<Integer>) filter.get(keys.get(i));
							logger.info("Filer Int :" + personnelTakenList);
							if (null != personnelTakenList) {
								// query.select(root).where(builder.in(expression));

							}
							// query.select(root).where(builder.equal(root.get("personnel_id"),
							// filter_int));
							//

							In<Integer> inOrgTypeCode = builder.in(root.get("personnel_id"));
							if (personnelTakenList.isEmpty()) {
								inOrgTypeCode.value((Integer) null);
							} else {
								for (Integer orgTypeCode : personnelTakenList) {
									inOrgTypeCode.value(orgTypeCode);
								}
							}
							query.select(root).where(inOrgTypeCode);
						}

					}
				}

			}
			Query<TransitportPersonnelModel> q = session.createQuery(query);
			personnels = q.getResultList();
			return personnels;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	@Override
	public List<PayerMenuModel> getPayerMenuMerchantWise(MerchantsModel model) {
		Session session = sessionFactory.openSession();
		List<PayerMenuModel> menuList = new ArrayList<PayerMenuModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayerMenuModel> query = builder.createQuery(PayerMenuModel.class);
			Root<PayerMenuModel> root = query.from(PayerMenuModel.class);

			query.select(root).where(builder.equal(root.get("merchantsBean").get("id"), model.getId()));
			Query<PayerMenuModel> q = session.createQuery(query);
			menuList = q.getResultList();
			return menuList;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	/*
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Override public List<VenueAppointmentModel>
	 * getAssetDetails(HashMap<String, Object> filter) { Session
	 * session=sessionFactory.openSession(); List<VenueAppointmentModel>
	 * list=new ArrayList<VenueAppointmentModel>(); ArrayList<Integer>
	 * assetTakenList = new ArrayList<>();
	 * 
	 * try { CriteriaBuilder builder=session.getCriteriaBuilder();
	 * CriteriaQuery<VenueAppointmentModel>
	 * query=builder.createQuery(VenueAppointmentModel.class);
	 * Root<VenueAppointmentModel>root=query.from(VenueAppointmentModel.class);
	 * 
	 * if (filter!=null) { if (filter.size()>0) { List<String> keys = new
	 * ArrayList<String>(filter.keySet()); for (int i = 0; i < keys.size(); i++)
	 * { if (keys.get(i).contentEquals("asset_id")) {
	 * assetTakenList=(ArrayList<Integer>) filter.get(keys.get(i)); logger.info(
	 * "Filer Int :" + assetTakenList);
	 * 
	 * In<Integer> inOrgTypeCode = builder.in(root.get("asset_id")); if
	 * (assetTakenList.isEmpty()) { inOrgTypeCode.value((Integer) null); } else
	 * { for (Integer orgTypeCode : assetTakenList) {
	 * inOrgTypeCode.value(orgTypeCode); } }
	 * query.select(root).where(inOrgTypeCode); } }
	 * 
	 * }
	 * 
	 * }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } return null; }
	 */

	@Override
	public List<PayplatterBusinessContextServiceMappings> getContextMappingList(HashMap<String, Object> filter) {
		Session session = sessionFactory.openSession();
		List<PayplatterBusinessContextServiceMappings> list = new ArrayList<PayplatterBusinessContextServiceMappings>();

		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayplatterBusinessContextServiceMappings> query = builder
					.createQuery(PayplatterBusinessContextServiceMappings.class);
			Root<PayplatterBusinessContextServiceMappings> root = query
					.from(PayplatterBusinessContextServiceMappings.class);
			if (filter != null) {
				if (filter.size() > 0) {
					List<String> keys = new ArrayList<String>(filter.keySet());

					for (int i = 0; i < keys.size(); i++) {
						if (keys.get(i).contentEquals("merchant_id") || keys.get(i).contentEquals("context_id")
								|| keys.get(i).contentEquals("service_id") || keys.get(i).contentEquals("mapping_id")) {
							Integer filter_int = (Integer) filter.get(keys.get(i));
							query.select(root).where(builder.equal(root.get(keys.get(i)), filter_int));
						}
					}
				}
			}

			Query<PayplatterBusinessContextServiceMappings> q = session.createQuery(query);
			list = q.getResultList();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	@Override
	public PayplatterBusinessContexts getBusinessContextsData(Integer context_id) {
		Session session = sessionFactory.openSession();
		PayplatterBusinessContexts context = new PayplatterBusinessContexts();
		try {

			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayplatterBusinessContexts> query = builder.createQuery(PayplatterBusinessContexts.class);
			Root<PayplatterBusinessContexts> root = query.from(PayplatterBusinessContexts.class);

			query.select(root).where(builder.equal(root.get("context_id"), context_id));
			Query<PayplatterBusinessContexts> q = session.createQuery(query);
			context = q.getResultList().get(0);
			return context;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public List<TransitportAssetsModel> getAssetsDetails(HashMap<String, Object> filter) {
		Session session = sessionFactory.openSession();
		List<TransitportAssetsModel> assets = new ArrayList<TransitportAssetsModel>();
		ArrayList<Integer> assetTakenList = new ArrayList<>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<TransitportAssetsModel> query = builder.createQuery(TransitportAssetsModel.class);
			Root<TransitportAssetsModel> root = query.from(TransitportAssetsModel.class);

			if (filter != null) {
				;
				if (filter.size() > 0) {
					List<String> keys = new ArrayList<String>(filter.keySet());
					for (int i = 0; i < keys.size(); i++) {

						if (keys.get(i).contentEquals("assets_id")) {
							assetTakenList = (ArrayList<Integer>) filter.get(keys.get(i));
							logger.info("Filer Int :" + assetTakenList);
							if (null != assetTakenList) {
								// query.select(root).where(builder.in(expression));

							}
							// query.select(root).where(builder.equal(root.get("personnel_id"),
							// filter_int));
							//

							In<Integer> inOrgTypeCode = builder.in(root.get("asset_id"));
							if (assetTakenList.isEmpty()) {
								inOrgTypeCode.value((Integer) null);
							} else {
								for (Integer orgTypeCode : assetTakenList) {
									inOrgTypeCode.value(orgTypeCode);
								}
							}
							query.select(root).where(inOrgTypeCode);
						}

					}
				}

			}
			Query<TransitportAssetsModel> q = session.createQuery(query);
			assets = q.getResultList();
			return assets;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	@Override
	public PayplatterBusinessContexts getBusinessContextDetails(String lookupName) {
		Session session = sessionFactory.openSession();
		PayplatterBusinessContexts context = new PayplatterBusinessContexts();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayplatterBusinessContexts> query = builder.createQuery(PayplatterBusinessContexts.class);
			Root<PayplatterBusinessContexts> root = query.from(PayplatterBusinessContexts.class);

			query.select(root).where(builder.equal(root.get("description"), lookupName));
			Query<PayplatterBusinessContexts> q = session.createQuery(query);
			context = q.getResultList().get(0);
			return context;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	@Override
	public PayplatterBusinessContexts getContextList(Integer context_id) {
		Session session = sessionFactory.openSession();
		PayplatterBusinessContexts context = new PayplatterBusinessContexts();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayplatterBusinessContexts> query = builder.createQuery(PayplatterBusinessContexts.class);
			Root<PayplatterBusinessContexts> root = query.from(PayplatterBusinessContexts.class);

			query.select(root).where(builder.and(builder.equal(root.get("context_id"), context_id),
					builder.equal(root.get("bc_category"), "BOOKING")));
			Query<PayplatterBusinessContexts> q = session.createQuery(query);
			context = q.getResultList().get(0);
			return context;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception While Geting Merchant BC List : " + e.getMessage());
			return context;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public PayerModel createPayer(PayerModel model) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(model);
			session.getTransaction().commit();
			return model;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public void addPayerMerchantConfig(PayerMerchantModel payerMerchantModel) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(payerMerchantModel);
			session.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

	@Override
	public PayerModel isUserExist(PayerModel model) {
		Session session = sessionFactory.openSession();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayerModel> query = builder.createQuery(PayerModel.class);
			Root<PayerModel> root = query.from(PayerModel.class);

			query.select(root).where(builder.and(builder.equal(root.get("emailId"), model.getEmailId()),
					builder.equal(root.get("contact"), model.getContact())));

			Query<PayerModel> q = session.createQuery(query);
			model = q.getResultList().get(0);
			return model;

		} catch (IndexOutOfBoundsException ex) {
			ex.getMessage();
			return null;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public List<PayerMerchantModel> getMerchantPayerConfig(MerchantsModel model) {
		Session session = sessionFactory.openSession();
		List<PayerMerchantModel> list = new ArrayList<PayerMerchantModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayerMerchantModel> query = builder.createQuery(PayerMerchantModel.class);
			Root<PayerMerchantModel> root = query.from(PayerMerchantModel.class);

			query.select(root).where(builder.equal(root.get("merchantsBean").get("id"), model.getId()));

			Query<PayerMerchantModel> q = session.createQuery(query);
			list = q.getResultList();

			return list;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public List<IndustryModel> getIndustryList() {
		Session session = sessionFactory.openSession();
		List<IndustryModel> list = new ArrayList<IndustryModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<IndustryModel> query = builder.createQuery(IndustryModel.class);
			Root<IndustryModel> root = query.from(IndustryModel.class);
			query.select(root).where(builder.equal(root.get("isSearchAppearances"), "Y"));

			Query<IndustryModel> q = session.createQuery(query);
			list = q.getResultList();
			return list;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public List<BusinessModel> getBusinessList(IndustryModel model) {
		Session session = sessionFactory.openSession();
		List<BusinessModel> list = new ArrayList<BusinessModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<BusinessModel> query = builder.createQuery(BusinessModel.class);
			Root<BusinessModel> root = query.from(BusinessModel.class);

			query.select(root).where(builder.equal(root.get("industryModel").get("id"), model.getId()));

			Query<BusinessModel> q = session.createQuery(query);
			list = q.getResultList();

			return list;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StateModel> getStates() {
		Session session = sessionFactory.openSession();
		List<StateModel> list = new ArrayList<StateModel>();
		try {
			CriteriaQuery cr = session.getCriteriaBuilder().createQuery(StateModel.class);
			cr.from(StateModel.class);
			list = session.createQuery(cr).getResultList();
			return list;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public List<CityModel> getStatescities(StateModel model) {
		Session session = sessionFactory.openSession();
		List<CityModel> list = new ArrayList<CityModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<CityModel> query = builder.createQuery(CityModel.class);
			Root<CityModel> root = query.from(CityModel.class);

			query.select(root).where(builder.equal(root.get("stateModel").get("id"), model.getId()));

			Query<CityModel> q = session.createQuery(query);
			list = q.getResultList();
			return list;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public List<MerchantsModel> getMerchantSearchAvability(SearchKeyModel searchkey) {
		Session session = sessionFactory.openSession();

		return null;
	}

	@Override
	public TransitportPersonnelModel getPersonnelsDetailsbyID(Integer personnel_id) {
		Session session = sessionFactory.openSession();
		TransitportPersonnelModel model = new TransitportPersonnelModel();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<TransitportPersonnelModel> query = builder.createQuery(TransitportPersonnelModel.class);
			Root<TransitportPersonnelModel> root = query.from(TransitportPersonnelModel.class);

			query.select(root).where(builder.equal(root.get("personnel_id"), personnel_id));
			Query<TransitportPersonnelModel> q = session.createQuery(query);
			model = q.getResultList().get(0);
			return model;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("While Geting Personnel Details Exception : " + e.getMessage());
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public TransitportAssetReservationsModel cancelAssetReservation(TransitportAssetsModel model) {

		return null;
	}

	@Override
	public TransitportAssetReservationsModel getAssetReservationDetailsByID(TransitportAssetsModel model) {
		Session session = sessionFactory.openSession();
		TransitportAssetReservationsModel reservation = new TransitportAssetReservationsModel();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<TransitportAssetReservationsModel> query = builder
					.createQuery(TransitportAssetReservationsModel.class);
			Root<TransitportAssetReservationsModel> root = query.from(TransitportAssetReservationsModel.class);

			query.select(root).where(builder.and(builder.equal(root.get("reservation_id"), model.getReservation_id()),
					builder.equal(root.get("asset_id"), model.getAsset_id())));
			Query<TransitportAssetReservationsModel> q = session.createQuery(query);
			reservation = q.getResultList().get(0);
			return reservation;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception While Geting Reservation Details : " + e.getMessage());
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public TransitportAssetAvailabilityModel updateAssetAvailability(
			TransitportAssetAvailabilityModel tempAvailability) {
		Session session = sessionFactory.openSession();
		try {

			session.beginTransaction();
			session.saveOrUpdate(tempAvailability);
			session.getTransaction().commit();

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception While Updating Availability : " + e.getMessage());
		} finally {
			session.clear();
			session.close();
		}
		return tempAvailability;
	}

	@Override
	public TransitportAssetReservationsModel updateRescheduleReservation(TransitportAssetReservationsModel reservations) {

		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(reservations);
			session.getTransaction().commit();
			return reservations;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception While Rescheduling Reservatiions " + e.getMessage());
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	@Override
	public TransitportAssetsModel getAssetReservationDetailsByID(Integer asset_id) {
		Session session = sessionFactory.openSession();
		TransitportAssetsModel asset = new TransitportAssetsModel();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<TransitportAssetsModel> query = builder.createQuery(TransitportAssetsModel.class);
			Root<TransitportAssetsModel> root = query.from(TransitportAssetsModel.class);

			query.select(root).where(builder.equal(root.get("asset_id"), asset_id));
			Query<TransitportAssetsModel> q = session.createQuery(query);
			asset = q.getResultList().get(0);
			return asset;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception While Geting Reservation Details : " + e.getMessage());
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public TransitportAssetReservationsModel getAssetReservationDetailsByID(TransitportAssetReservationsModel model) {
		Session session = sessionFactory.openSession();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<TransitportAssetReservationsModel> query = builder
					.createQuery(TransitportAssetReservationsModel.class);
			Root<TransitportAssetReservationsModel> root = query.from(TransitportAssetReservationsModel.class);
			query.select(root).where(builder.equal(root.get("reservation_id"), model.getReservation_id()));
			Query<TransitportAssetReservationsModel> q = session.createQuery(query);
			model = q.getResultList().get(0);
			return model;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception While Getting Reservation Details : " + e.getMessage());
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public List<TransitportAssetsModel> getAssetDetailsBasedAssetCategory(String key, Map<String, Integer> filter_map) {
		Session session = sessionFactory.openSession();
		List<TransitportAssetsModel> assetModel = new ArrayList<TransitportAssetsModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<TransitportAssetsModel> query = builder.createQuery(TransitportAssetsModel.class);
			Root<TransitportAssetsModel> root = query.from(TransitportAssetsModel.class);
			if (key.equals("type_and_category")) {
              logger.info("Asset Type & Category :::::::::::::::::: Category ID = "+filter_map.get("category_id")+" & Asset Type ID = "+filter_map.get("asset_type_id"));
				
              
              query.select(root).where(builder.and(builder.equal(root.get("asset_category_id"), filter_map.get("category_id")),
								builder.equal(root.get("assetTypeLookup").get("asset_type_id"),
										filter_map.get("asset_type_id"))));
              
              
			}
			Query<TransitportAssetsModel> q = session.createQuery(query);
			assetModel = q.getResultList();
			return assetModel;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception During Asset Details Based Asset Category : " + e.getMessage());
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public TransitportAssetReservationsModel getReservationDetailsByID(Integer reservation_id) {
		Session session=sessionFactory.openSession();
		TransitportAssetReservationsModel reservaion=new TransitportAssetReservationsModel();
		try {
			CriteriaBuilder builder=session.getCriteriaBuilder();
			CriteriaQuery<TransitportAssetReservationsModel> query=builder.createQuery(TransitportAssetReservationsModel.class);
			Root<TransitportAssetReservationsModel> root=query.from(TransitportAssetReservationsModel.class);
			
			query.select(root).where(builder.equal(root.get("reservation_id"), reservation_id));
			
			Query<TransitportAssetReservationsModel>q=session.createQuery(query);
			reservaion=(TransitportAssetReservationsModel) q.getResultList();
			return reservaion;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public TransitportAssetReservationsModel updateRescheduleAssetReservation(
			TransitportAssetReservationsModel reservationModel) {
		Session session=sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(reservationModel);
			session.getTransaction().commit();
			return reservationModel;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.info("Exception Occur During Updating Reservation Reschedule : "+e.getMessage());
			return null;
		}finally {
			session.close();
		}
		
	}

	@Override
	public List<MerchantConfigPreferencesModel> getMerchantPreferencesList(String key, Integer merchant_id) {
		Session session=sessionFactory.openSession();
		List<MerchantConfigPreferencesModel>list=new ArrayList<MerchantConfigPreferencesModel>();
		try {
			CriteriaBuilder builder=session.getCriteriaBuilder();
			CriteriaQuery<MerchantConfigPreferencesModel> query=builder.createQuery(MerchantConfigPreferencesModel.class);
			Root<MerchantConfigPreferencesModel>root=query.from(MerchantConfigPreferencesModel.class);
			if (key.equalsIgnoreCase("merchant_id")) {
				logger.info("Merchant Id :: "+merchant_id);
				query.select(root).where(builder.equal(root.get("merchant_id"), merchant_id));
			}
			Query<MerchantConfigPreferencesModel>q=session.createQuery(query);
			list=q.getResultList();
			return list;
			
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception Occur During to Merchant Preferences :: "+e.getMessage());
			return list;
		}finally {
			session.close();
		}
	}

	@Override
	public PayerModel updatePayerDetails(PayerModel tempModel) {
		Session session=sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(tempModel);
			session.getTransaction().commit();
			return tempModel;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}finally {
			session.close();
		}
	}



}
