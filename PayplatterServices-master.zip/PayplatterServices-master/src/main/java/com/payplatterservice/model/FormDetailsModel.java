package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "transitport_form_details")
public class FormDetailsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer id;

	

	@Column(unique = true)
	private String formName;
	private Date formDate, formStartDate, formEndDate, formLateEndDate;
	private Integer formOwnerId, validityflag;
	private String status, formOwnerName, saComment,image;
	private String jsEnabled,js_name,life_cycle,landingpage_srcPath,hasInstructions,fileLabel,file_ext,file_actu_name;
	private String form_action, form_payment_type, form_action_class_path;
	@Lob
	@Column(name = "instructions", columnDefinition = "mediumblob")
	private byte[] instructions;
	@Transient
	private String fromDateStr, toDateStr, toLateDateStr;
	
	private Integer isBusinessContext;
	private Integer context_mapping_id;
	private String business_context_bean_name;
	private Integer status_by, payer_type;
	
	private Integer target_actor;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public Date getFormDate() {
		return formDate;
	}

	public void setFormDate(Date formDate) {
		this.formDate = formDate;
	}

	public Date getFormStartDate() {
		return formStartDate;
	}

	public void setFormStartDate(Date formStartDate) {
		this.formStartDate = formStartDate;
	}

	public Date getFormEndDate() {
		return formEndDate;
	}

	public void setFormEndDate(Date formEndDate) {
		this.formEndDate = formEndDate;
	}

	public Date getFormLateEndDate() {
		return formLateEndDate;
	}

	public void setFormLateEndDate(Date formLateEndDate) {
		this.formLateEndDate = formLateEndDate;
	}

	public Integer getFormOwnerId() {
		return formOwnerId;
	}

	public void setFormOwnerId(Integer formOwnerId) {
		this.formOwnerId = formOwnerId;
	}

	public Integer getValidityflag() {
		return validityflag;
	}

	public void setValidityflag(Integer validityflag) {
		this.validityflag = validityflag;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFormOwnerName() {
		return formOwnerName;
	}

	public void setFormOwnerName(String formOwnerName) {
		this.formOwnerName = formOwnerName;
	}

	public String getSaComment() {
		return saComment;
	}

	public void setSaComment(String saComment) {
		this.saComment = saComment;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getJsEnabled() {
		return jsEnabled;
	}

	public void setJsEnabled(String jsEnabled) {
		this.jsEnabled = jsEnabled;
	}

	public String getJs_name() {
		return js_name;
	}

	public void setJs_name(String js_name) {
		this.js_name = js_name;
	}

	public String getLife_cycle() {
		return life_cycle;
	}

	public void setLife_cycle(String life_cycle) {
		this.life_cycle = life_cycle;
	}

	public String getLandingpage_srcPath() {
		return landingpage_srcPath;
	}

	public void setLandingpage_srcPath(String landingpage_srcPath) {
		this.landingpage_srcPath = landingpage_srcPath;
	}

	public String getHasInstructions() {
		return hasInstructions;
	}

	public void setHasInstructions(String hasInstructions) {
		this.hasInstructions = hasInstructions;
	}

	public String getFileLabel() {
		return fileLabel;
	}

	public void setFileLabel(String fileLabel) {
		this.fileLabel = fileLabel;
	}

	public String getFile_ext() {
		return file_ext;
	}

	public void setFile_ext(String file_ext) {
		this.file_ext = file_ext;
	}

	public String getFile_actu_name() {
		return file_actu_name;
	}

	public void setFile_actu_name(String file_actu_name) {
		this.file_actu_name = file_actu_name;
	}

	public String getForm_action() {
		return form_action;
	}

	public void setForm_action(String form_action) {
		this.form_action = form_action;
	}

	public String getForm_payment_type() {
		return form_payment_type;
	}

	public void setForm_payment_type(String form_payment_type) {
		this.form_payment_type = form_payment_type;
	}

	public String getForm_action_class_path() {
		return form_action_class_path;
	}

	public void setForm_action_class_path(String form_action_class_path) {
		this.form_action_class_path = form_action_class_path;
	}

	public byte[] getInstructions() {
		return instructions;
	}

	public void setInstructions(byte[] instructions) {
		this.instructions = instructions;
	}

	public String getFromDateStr() {
		return fromDateStr;
	}

	public void setFromDateStr(String fromDateStr) {
		this.fromDateStr = fromDateStr;
	}

	public String getToDateStr() {
		return toDateStr;
	}

	public void setToDateStr(String toDateStr) {
		this.toDateStr = toDateStr;
	}

	public String getToLateDateStr() {
		return toLateDateStr;
	}

	public void setToLateDateStr(String toLateDateStr) {
		this.toLateDateStr = toLateDateStr;
	}

	public Integer getIsBusinessContext() {
		return isBusinessContext;
	}

	public void setIsBusinessContext(Integer isBusinessContext) {
		this.isBusinessContext = isBusinessContext;
	}

	public Integer getContext_mapping_id() {
		return context_mapping_id;
	}

	public void setContext_mapping_id(Integer context_mapping_id) {
		this.context_mapping_id = context_mapping_id;
	}

	public String getBusiness_context_bean_name() {
		return business_context_bean_name;
	}

	public void setBusiness_context_bean_name(String business_context_bean_name) {
		this.business_context_bean_name = business_context_bean_name;
	}

	public Integer getStatus_by() {
		return status_by;
	}

	public void setStatus_by(Integer status_by) {
		this.status_by = status_by;
	}

	public Integer getPayer_type() {
		return payer_type;
	}

	public void setPayer_type(Integer payer_type) {
		this.payer_type = payer_type;
	}

	public Integer getTarget_actor() {
		return target_actor;
	}

	public void setTarget_actor(Integer target_actor) {
		this.target_actor = target_actor;
	}
	
	
	
}
