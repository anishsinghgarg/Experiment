package com.payplatterservice.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.payplatterservice.model.BusinessModel;
import com.payplatterservice.model.CityModel;
import com.payplatterservice.model.FormDetailsModel;
import com.payplatterservice.model.CustomerRequestModel;
import com.payplatterservice.model.IndustryModel;
import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantServicesDetailsBean;
import com.payplatterservice.model.MerchantServicesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.MessageConfigurationModel;
import com.payplatterservice.model.MessageModel;
import com.payplatterservice.model.PayerDocumentModel;
import com.payplatterservice.model.PayerMenuModel;
import com.payplatterservice.model.PayerMerchantModel;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PayplatterBusinessContextServiceMappings;
import com.payplatterservice.model.PayplatterBusinessContexts;
import com.payplatterservice.model.PayplatterCentralInvoicesModel;
import com.payplatterservice.model.PersonnelAppointmentModel;
import com.payplatterservice.model.SampleFormModel;
import com.payplatterservice.model.SearchKeyModel;
import com.payplatterservice.model.ServicesMasterModel;
import com.payplatterservice.model.StateModel;
import com.payplatterservice.model.TransitportAssetReservationsModel;
import com.payplatterservice.model.TransitportAssetAvailabilityModel;
import com.payplatterservice.model.TransitportAssetsModel;
import com.payplatterservice.model.TransitportPersonnelModel;
import com.payplatterservice.model.VenueAppointmentModel;

public interface PayerService {

	PayerModel getPayerDetailsById(PayerModel model);

	PayplatterCentralInvoicesModel getPayerInvoice(PayplatterCentralInvoicesModel model);

	List<PayplatterCentralInvoicesModel> getPayerInvoiceList(PayplatterCentralInvoicesModel model);

	List<MerchantsModel> getMerchantList(PayerModel model);

	// List<ServicesMasterModel> getServicesList(MerchantsModel model);

	List<MerchantServicesDetailsBean> getServicesList(MerchantsModel model);

	CustomerRequestModel saveCustomerConversionData(CustomerRequestModel customerReqModel);

	List<CustomerRequestModel> getCustomerConversion(CustomerRequestModel customerModel, String key);

	List<MessageModel> getMessageList(MessageConfigurationModel model);

	MessageModel getMessageDetails(MessageModel model);

	List<PayerDocumentModel> getPayerMerchantDocuments(PayerDocumentModel model);

	SampleFormModel getBookingDetails(PayerModel model);

	FormDetailsModel getFormDetails(Integer formTemplateId);

	 List<PersonnelAppointmentModel> getBookingAppointmentDetails(HashMap<String, Object> filter);

	List<TransitportPersonnelModel> getPersonnelsDetails(HashMap<String, Object> filter);

	List<PayerMenuModel> getPayerMenuMerchantWise(MerchantsModel model);

	List<PayplatterBusinessContextServiceMappings> getContextMappingList(HashMap<String, Object> filter);

	PayplatterBusinessContexts getBusinessContextsData(Integer context_id);

	List<TransitportAssetsModel> getAssetsDetails(HashMap<String, Object> filter);

	PayplatterBusinessContexts getBusinessContextDetails(String string);

	PayplatterBusinessContexts getContextList(Integer context_id);

	PayerModel createPayer(PayerModel model);

	void addPayerMerchantConfig(PayerMerchantModel payerMerchantModel);

	PayerModel isUserExist(PayerModel prmodel);

	List<PayerMerchantModel> getMerchantPayerConfig(MerchantsModel model);

	List<IndustryModel> getIndustryList();
	
	List<BusinessModel> getBusinessList(IndustryModel model);
	
	List<StateModel> getStates();
	List<CityModel> getStatescities(StateModel model);

	List<MerchantsModel> getMerchantSearchAvability(SearchKeyModel searchkey);

	TransitportPersonnelModel getPersonnelsDetailsbyID(Integer personnel_id);

	TransitportAssetReservationsModel cancelAssetReservation(TransitportAssetsModel model);

	TransitportAssetReservationsModel getAssetReservationDetailsByID(TransitportAssetsModel model);

	TransitportAssetAvailabilityModel updateAssetAvailability(TransitportAssetAvailabilityModel tempAvailability);

	TransitportAssetReservationsModel updateRescheduleReservation(TransitportAssetReservationsModel reservations);

	TransitportAssetsModel getAssetReservationDetailsByID(Integer asset_id);

	TransitportAssetReservationsModel getAssetReservationDetailsByID(TransitportAssetReservationsModel model);



	List<TransitportAssetsModel> getAssetDetailsBasedAssetCategory(String key, Map<String, Integer> filter_map);

	TransitportAssetReservationsModel getReservationDetailsByID(Integer reservation_id);

	TransitportAssetReservationsModel updateRescheduleAssetReservation(
			TransitportAssetReservationsModel reservationModel);

	List<MerchantConfigPreferencesModel> getMerchantPreferencesList(String string, Integer merchant_id);

	PayerModel updatePayerDetails(PayerModel tempModel);

	

	
}
