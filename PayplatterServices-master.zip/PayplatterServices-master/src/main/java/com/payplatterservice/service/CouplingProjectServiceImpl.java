package com.payplatterservice.service;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PaymentProcessorModel;

@Repository
public class CouplingProjectServiceImpl implements CouplingProjectService {

	private static final Logger logger = Logger.getLogger(CouplingProjectServiceImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public boolean isMerchantExist(MerchantsModel model) {
		Session session = sessionFactory.openSession();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<MerchantsModel> query = builder.createQuery(MerchantsModel.class);
			Root<MerchantsModel> root = query.from(MerchantsModel.class);

			query.select(root).where(builder.and(builder.equal(root.get("emailId"), model.getEmailId())),
					builder.equal(root.get("contact"), model.getContact()));
			Query<MerchantsModel> q = session.createQuery(query);

			if (q.getResultList() != null || q.getResultList().size() > 0) {
				return false;
			}

			else {
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			session.close();
		}
	}

	@Override
	public PaymentProcessorModel paymentProcessorDetails(Integer pgId_Fk) {
		Session session = sessionFactory.openSession();
		PaymentProcessorModel model = new PaymentProcessorModel();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PaymentProcessorModel> query = builder.createQuery(PaymentProcessorModel.class);
			Root<PaymentProcessorModel> root = query.from(PaymentProcessorModel.class);

			query.select(root).where(builder.equal(root.get("id"), pgId_Fk));
			Query<PaymentProcessorModel> q = session.createQuery(query);
			model = q.getResultList().get(0);
			return model;

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception :: " + e.getMessage());
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public MerchantsModel saveMerchantInfoDetails(MerchantsModel model) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.save(model);
			session.getTransaction().commit();

			return model;
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception while Saving Merchant Info Details :: " + e.getMessage());
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public boolean isMerchantExistInMerchantMaster(MerchantsModel model) {
		Session session = sessionFactory.openSession();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<MerchantsModel> query = builder.createQuery(MerchantsModel.class);
			Root<MerchantsModel> root = query.from(MerchantsModel.class);

			query.select(root).where(builder.and(builder.equal(root.get("emailId"), model.getEmailId())),
					builder.equal(root.get("contact"), model.getContact()),
					builder.equal(root.get("legalBusinessName"), model.getLegalBusinessName()));

			Query<MerchantsModel> q = session.createQuery(query);
			if (q.getResultList() != null || q.getResultList().size() > 0) {
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception While Checking Merchant Exist in the Merchant Master Table or Not :: "+e.getMessage());
			return false;
		} finally {
			session.close();
		}
		
		//com/mchange/v2/cfg/MConfig
	}

	@Override
	public Long getTotalRowCount() {
		Session session=sessionFactory.openSession();
		try {
			CriteriaBuilder builder=session.getCriteriaBuilder();
			CriteriaQuery<Long>query=builder.createQuery(Long.class);
			
			query.select(builder.count(query.from(MerchantsModel.class)));
			
			return session.createQuery(query).getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}finally {
			session.close();
		}
	}

}
