package com.payplatterservice.operationservice;

import com.payplatterservice.model.MerchantsModel;

public interface CouplingOperationServices {

	String isMerchantExist(MerchantsModel model);

}
