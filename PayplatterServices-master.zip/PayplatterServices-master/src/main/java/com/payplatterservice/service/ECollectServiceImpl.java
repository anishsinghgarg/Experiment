package com.payplatterservice.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jboss.logging.Logger;
import org.springframework.stereotype.Repository;

import com.payplatterservice.configuration.DBConnection;
import com.payplatterservice.controller.MerchantActionController;
import com.payplatterservice.model.PlatterPayTransactionBean;

@Repository
public class ECollectServiceImpl implements ECollectService {

	private static final Logger logger = Logger.getLogger(ECollectServiceImpl.class);
	@Override
	public PlatterPayTransactionBean txnRequestValidation(String tokenNO, String txnAmount, String mobNo) {
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PlatterPayTransactionBean bean = new PlatterPayTransactionBean();

		try {

			String sql = "SELECT txnDtls.txnId,txnDtls.status,txnDtls.actAmount,txnDtls.payeeAmount,txnDtls.transDate,"
					+ "txnDtls.payeeFirstName,txnDtls.payeeLstName,txnDtls.payeeMob,txnDtls.PGPayMode,"
					+ "txnDtls.payeeEmail,chDtls.challanNo FROM platterpay.challan_detail chDtls LEFT JOIN "
					+ "platterpay.transaction_detail txnDtls ON txnDtls.txnId=chDtls.Transaction_id_fk "
					+ "where chDtls.challanNo='" + tokenNO + "'and "
					+ "txnDtls.actAmount='" + txnAmount + "'";

			logger.info("SQL Query Yes Bank Transaction Verification ::" + sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				bean.setTxnId(rs.getString("txnId"));
				bean.setStatus(rs.getString("status"));
				bean.setActAmount(rs.getDouble("actAmount"));
				bean.setPayeeAmount(rs.getDouble("payeeAmount"));
				bean.setTransDate(rs.getTimestamp("transDate"));
				bean.setPayeeFirstName(rs.getString("payeeFirstName"));
				bean.setPayeeLstName(rs.getString("payeeLstName"));
				bean.setPayeeMob(rs.getString("payeeMob"));
				bean.setPGPayMode(rs.getString("PGPayMode"));
				bean.setPayeeEmail(rs.getString("payeeEmail"));
				bean.setChallanNo(rs.getString("challanNo"));

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return bean;

	}

	@Override
	public String updateTransaction(String chlanNO, String payStatus, String payStatus2, String payode,
			String txnCompliteDate, String bENE_BANK_NAME, String bENE_ACCOUNT_NO, String bENE_ACCOUNT_NO2,
			String bENE_FULL_NAME, String bENE_ACCOUNT_IFSC, String rMTR_FULL_NAME, String rMTR_ACCOUNT_NUMBER,
			String rMTR_BANK_NAME, String rMTR_ACCOUNT_IFSC, String vIRTUAL_ACCOUNT_NO) {

		String msg = null;
		Date   txnComplDate=null;
		PlatterPayTransactionBean bean = null;
		Boolean exist = true;
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}
		try {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
				
				txnCompliteDate = sdf.format(new Date());
				txnComplDate.parse(txnCompliteDate);
			} catch (Exception e) {
				
			}
			String sql = "UPDATE platterpay.challan_detail SET challan_status='" + payStatus + "',challan_status_ws='"
					+ payStatus2 + "',Pay_Mode='" + payode + "',Bank_Name='"
					+ bENE_BANK_NAME + "',Client_Account_Number='" + bENE_ACCOUNT_NO + "',Credit_AccountNo='"
					+ bENE_ACCOUNT_NO + "',beneFiciaryName='" + bENE_FULL_NAME + "',ifscCode='" + bENE_ACCOUNT_IFSC
					+ "',remitter_name='" + rMTR_FULL_NAME + "',remitter_acc_no='" + rMTR_ACCOUNT_NUMBER
					+ "',remitter_bank_name='" + rMTR_BANK_NAME + "',remitter_bank_ifsc='" + rMTR_ACCOUNT_IFSC
					+ "'where challanNo='" + chlanNO + "'";
			logger.info("SQL =" + sql);
			stmt.executeUpdate(sql);
			if (stmt.executeUpdate(sql) <= 0) {
				logger.info("stmt.executeUpdate(sql) <= 0");
				msg = "FAILURE";
				return msg;
			}
			// Rows affected
			else {
				bean = new PlatterPayTransactionBean();
				bean = selectTransnactionID(chlanNO);
				if (bean != null) {
					exist = updateTransactionTable(bean.getTxnId(), payStatus, txnCompliteDate, payode);
				} else {
					msg = "FAILURE";
					return msg;
				}

				logger.info("Boolean Value : " + exist);
				logger.info("stmt.executeUpdate(sql) > 0");
				if (exist) {
					msg = "SUCCESS";
					return msg;
				} else {

					msg = "FAILURE";
					return msg;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			msg = "FAILURE";
			return msg;
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private PlatterPayTransactionBean selectTransnactionID(String chlanNO) throws SQLException {

		PlatterPayTransactionBean bean = null;
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		stmt = con.createStatement();
		String respCode = null;
		try {
			String sql = "SELECT * FROM platterpay.challan_detail where challanNo='" + chlanNO+"'";

			logger.info("SQL Query Get Txn ID ::" + sql);
			rs = stmt.executeQuery(sql);
			bean = new PlatterPayTransactionBean();
			while (rs.next()) {
				bean.setTxnId(rs.getString("Transaction_id_fk"));

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			con.close();

			stmt.close();
		}
		return bean;
	}

	private Boolean updateTransactionTable(String txnID, String payStatus, String txnCompliteDate, String payode)
			throws SQLException {
		Boolean exist = false;

		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		stmt = con.createStatement();
		String respCode = null;
		if ("SUCCESS".equalsIgnoreCase(payStatus)) {
			respCode = "0000";
		} else if ("PENDING".equalsIgnoreCase(payStatus)) {
			respCode = "0001";
		} else {
			respCode = "0003";
		}
		try {
			String sql = "UPDATE platterpay.transaction_detail SET status='" + payStatus + "'," + "PGPayMode='" + payode + "',platterpay_response_code='" + respCode
					+ "' where txnId='" + txnID + "'";
			logger.info("SQL =" + sql);
			stmt.executeUpdate(sql);
			// No rows affected
			if (stmt.executeUpdate(sql) <= 0) {
				logger.info("stmt.executeUpdate(sql) <= 0");
				exist = false;
				return exist;
			}
			// Rows affected
			else {
				logger.info("stmt.executeUpdate(sql) > 0");
				exist = true;
				return exist;
			}

		} catch (Exception e) {
			exist = false;
			e.printStackTrace();
			return exist;
		} finally {
			con.close();

			stmt.close();
		}

	}

}
