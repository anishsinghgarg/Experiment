package com.payplatterservice.model;

public class TempStatusInquiryModel {
	
	private String txnId;
	private String status;
	private String paymentMode;
	private String transCompleteDate;
	private String clientTxnId;
	private String payPlatterRespCode;
	private double payeeAmount;
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getTransCompleteDate() {
		return transCompleteDate;
	}
	public void setTransCompleteDate(String transCompleteDate) {
		this.transCompleteDate = transCompleteDate;
	}
	public String getClientTxnId() {
		return clientTxnId;
	}
	public void setClientTxnId(String clientTxnId) {
		this.clientTxnId = clientTxnId;
	}
	public double getPayeeAmount() {
		return payeeAmount;
	}
	public void setPayeeAmount(double payeeAmount) {
		this.payeeAmount = payeeAmount;
	}
	public String getPayPlatterRespCode() {
		return payPlatterRespCode;
	}
	public void setPayPlatterRespCode(String payPlatterRespCode) {
		this.payPlatterRespCode = payPlatterRespCode;
	}
	
	
}
