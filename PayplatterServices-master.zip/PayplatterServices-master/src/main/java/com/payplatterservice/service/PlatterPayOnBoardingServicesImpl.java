package com.payplatterservice.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.jboss.logging.Logger;
import org.springframework.stereotype.Repository;

import com.payplatterservice.configuration.DBConnection;
import com.platterpayservices.model.ClientDetails;
import com.platterpayservices.model.ClientDetailsMapping;
import com.platterpayservices.model.EndpointDataModel;
import com.platterpayservices.model.FeeDataModel;

@Repository
public class PlatterPayOnBoardingServicesImpl implements PlatterPayOnBoardingServices {

	private static final Logger logger = Logger.getLogger(PlatterPayOnBoardingServicesImpl.class);

	@Override
	public ClientDetails onBoardClient(ClientDetails clientDetails) {
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		// ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			int maxID = getTableMaxPrimID("platterpay.client_data_table", "clientId");
			maxID = maxID + 1;
			clientDetails.setClientId(maxID);
			String sql = "INSERT INTO platterpay.client_data_table VALUES(" + maxID
					+ ",null,'Y','ENCRYPTION',null,null,'" + clientDetails.getClientCode() + "','"
					+ clientDetails.getClientContact() + "','" + clientDetails.getClientEmail() + "','"
					+ clientDetails.getClientIV() + "','" + clientDetails.getClientKey() + "','"
					+ clientDetails.getClientName() + "','" + clientDetails.getClientPass() + "',null,'"
					+ clientDetails.getClientUsername()
					+ "','http://localhost:8080/BizPlatter/response',0,null,null,'N','N','http://localhost:8080/BizPlatter/response')";

			logger.info("Sql Query " + sql);
			int counter = stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			logger.info("Counter value is :::::::::" + counter);
			if (counter == 0) {
				throw new SQLException("Creating user failed, no rows affected.");
			}
			logger.info("Counter value iSSSSs :::::::::" + counter);
			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					logger.info(rs.getInt(1));
				}
				rs.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return clientDetails;
	}

	@Override
	public ClientDetailsMapping saveClientMappingDetails(ClientDetails clientDetails, EndpointDataModel ep) {
		ClientDetailsMapping clientMapping = new ClientDetailsMapping();
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			int maxID = getTableMaxPrimID("platterpay.client_mappings", "mappingId");
			maxID = maxID + 1;
			clientMapping.setMappingId(maxID);
			String sql = "INSERT INTO platterpay.client_mappings values("+maxID+"," + clientDetails.getClientId() + ","
					+ ep.getEpId() + ",null,null,null,null,'" + ep.getEpPass()
					+ "','https://test.instamojo.com/api/1.1/','" + ep.getEpUserName()
					+ "','NO',null,'Y','3','1',null)";
			logger.info("Sql Query " + sql);
			int counter = stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			System.out.println("Counter Value : "+counter);
			if (counter == 0) {
				throw new SQLException("Creating user failed, no rows affected.");
			}
			logger.info("Counter value iSSSSs :::::::::" + counter);
			try (ResultSet rs = stmt.getGeneratedKeys()) {
				if (rs.next()) {
					logger.info(rs.getInt(1));
				}
				rs.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return clientMapping;
	}

	@SuppressWarnings("unused")
	@Override
	public FeeDataModel getFeeDetails(String key, String value) {
		FeeDataModel feeDetails = null;
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			String sql = "SELECT * FROM platterpay.fee_data_table where " + key + "='" + value + "'";
			logger.info("SQL Query Yes Bank Transaction Verification ::" + sql);
			rs = stmt.executeQuery(sql);
			if (rs.getFetchSize() > 0 || rs != null) {
				feeDetails = new FeeDataModel();
				while (rs.next()) {
					feeDetails.setFeeId(rs.getInt("feeId"));
					feeDetails.setFeeType(rs.getString("feeType"));
					feeDetails.setFeeValue(rs.getFloat("feeValue"));
					feeDetails.setIntHandlingType(rs.getString("intHandlingType"));
					feeDetails.setIntHandlingValue(rs.getFloat("intHandlingValue"));
					feeDetails.setMerchantGSTType(rs.getString("merchantGSTType"));
					feeDetails.setMerchantGSTValue(rs.getFloat("merchantGSTValue"));
					feeDetails.setServiceTax(rs.getInt("serviceTax"));
					feeDetails.setServiceTaxType(rs.getString("serviceTaxType"));
					feeDetails.setServiceTaxValue(rs.getFloat("serviceTaxValue"));

				}
			} else {
				setDefaultFeeConfigurations(feeDetails);
			}

		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return feeDetails;
	}

	@Override
	public FeeDataModel setDefaultFeeConfigurations(FeeDataModel fee) {
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			logger.info("Saving Default Fee Details :::::::::::");
			int maxID = getTableMaxPrimID("platterpay.fee_data_table", "feeId");
			maxID = maxID + 1;
			fee.setFeeId(maxID);
			logger.info("Max Value " + maxID);
			String sql = "INSERT INTO platterpay.fee_data_table (`feeId`,`feeType`,`feeValue`,`intHandlingType`,`intHandlingValue`,`serviceTax`,`serviceTaxType`,`serviceTaxValue`,`slabCeiling`,`slabFloor`,`slabNumber`,`merchantGSTType`,`merchantGSTValue`,`configurationType`) "
					+ " VALUES(" + maxID + ",'fixed',0,'fixed',0,null,'fixed',1,'999999',1, 0,'fixed',0,'DEFAULT')";
			logger.info("Sql Query " + sql);
			int counter = stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			logger.info("Counter value is :::::::::" + counter);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return fee;
	}

	public Integer getTableMaxPrimID(String tableName, String column) {
		System.out.println("Validate Key & IV ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;
		Integer maxID = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			String sql = "SELECT max(" + column + ") FROM " + tableName + "";
			logger.info("SQL Query :: " + sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				maxID = rs.getInt("max(" + column + ")");
			}
			logger.info("Max ID " + maxID);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return maxID;

	}

	@Override
	public boolean isValidKeyIV(String key, String value) {
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;
		Integer maxID = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			String sql = "SELECT * FROM platterpay.client_data_table where " + key + "='" + value + "'";
			System.out.println("SQL : " + sql);
			rs = stmt.executeQuery(sql);
			if (rs.getFetchSize() > 0) {
				return true;
			} else {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			return true;
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public EndpointDataModel getEPDetails(String key, String value) {
		EndpointDataModel epDetails = null;
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;
		Integer maxID = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			String sql = "SELECT * FROM platterpay.endpoint_data_table where " + key + "='" + value + "'";
			System.out.println("SQL : " + sql);
			rs = stmt.executeQuery(sql);
			epDetails = new EndpointDataModel();
			while (rs.next()) {
				epDetails.setEpId(rs.getInt("epId"));
				epDetails.setEpName(rs.getString("epName"));
				epDetails.setEpUserName(rs.getString("epUserName"));
				epDetails.setEpPass(rs.getString("epPass"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return epDetails;
	}

	@Override
	public int saveIntoMappling(FeeDataModel feeDetails, ClientDetailsMapping clientMapping) {
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;
		int counter = 0;
		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			String sql = "INSERT INTO platterpay.client_mappings_fee_data_table VALUES(" + clientMapping.getMappingId()
					+ "," + feeDetails.getFeeId() + ")";

			logger.info("Sql Query " + sql);
			counter = stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			logger.info("Counter value is :::::::::" + counter);
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return counter;
	}
}
