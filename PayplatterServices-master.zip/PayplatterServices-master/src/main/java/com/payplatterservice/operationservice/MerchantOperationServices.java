package com.payplatterservice.operationservice;

import java.util.List;

import com.payplatterservice.model.BCObjectKeyModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.ObjectKeyModel;
import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PayerModel;

public interface MerchantOperationServices {

	String createInvoicesForEnrollPayer(ObjectKeyModel objectKey);

	String validateUserExitOrNot(PayerModel model);

	String createInvoicesForGuestPayer(ObjectKeyModel objectKey);

	List<PayerModel> getMerchantPayerList(MerchantsModel model);

	List<Object> getBusinessContextReport(BCObjectKeyModel objectKeyModel);

	
	

}
