package com.payplatterservice.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


/**
 * @author Anish
 *
 */
/**
 * @author Anish
 *
 */
@Entity
@Table(name = "merchant_product_categories_conf")
public class PayPlatterEcomMerchantProductCategoriesConfBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer Id;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "sub_product_cat_Fk", referencedColumnName = "Id")
	private PayPlatterEcomProductSubCategoriesBean productSubCategoriesBean;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "merchantId_Fk", referencedColumnName = "Id")
	private MerchantsModel merchantsBean;


	@OneToMany(mappedBy = "merchantProductCategoriesConfBean")
	List<PayPlatterEcomMerchandiseMasterBean> merchandiseMasterBean;
	
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "product_cat_Fk", referencedColumnName = "Id")
	private PayPlatterEcomProductCategoriesBean productCategoriesBean;
	
	
	
	public Integer getId() {
		return Id;
	}


	public void setId(Integer id) {
		Id = id;
	}


	public PayPlatterEcomProductSubCategoriesBean getProductSubCategoriesBean() {
		return productSubCategoriesBean;
	}


	public void setProductSubCategoriesBean(PayPlatterEcomProductSubCategoriesBean productSubCategoriesBean) {
		this.productSubCategoriesBean = productSubCategoriesBean;
	}


	public MerchantsModel getMerchantsBean() {
		return merchantsBean;
	}


	public void setMerchantsBean(MerchantsModel merchantsBean) {
		this.merchantsBean = merchantsBean;
	}


	public List<PayPlatterEcomMerchandiseMasterBean> getMerchandiseMasterBean() {
		return merchandiseMasterBean;
	}


	public void setMerchandiseMasterBean(List<PayPlatterEcomMerchandiseMasterBean> merchandiseMasterBean) {
		this.merchandiseMasterBean = merchandiseMasterBean;
	}


	public PayPlatterEcomProductCategoriesBean getProductCategoriesBean() {
		return productCategoriesBean;
	}


	public void setProductCategoriesBean(PayPlatterEcomProductCategoriesBean productCategoriesBean) {
		this.productCategoriesBean = productCategoriesBean;
	}


	
	
	
	
	
}
