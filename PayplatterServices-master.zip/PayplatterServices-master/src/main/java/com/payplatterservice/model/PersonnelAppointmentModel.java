package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "context_personal_appointment")
public class PersonnelAppointmentModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer contextDataId;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer personnel_id;
	private String appointmentDate;
	private String start_time, end_time;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer availabilty_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer form_instance_id;
	@ColumnDefault(value = "'OPEN'")
	private String status;
	
	@Transient
	private TransitportPersonnelModel personnelData;

	public Integer getContextDataId() {
		return contextDataId;
	}

	public void setContextDataId(Integer contextDataId) {
		this.contextDataId = contextDataId;
	}

	public Integer getPersonnel_id() {
		return personnel_id;
	}

	public void setPersonnel_id(Integer personnel_id) {
		this.personnel_id = personnel_id;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getEnd_time() {
		return end_time;
	}

	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

	public Integer getAvailabilty_id() {
		return availabilty_id;
	}

	public void setAvailabilty_id(Integer availabilty_id) {
		this.availabilty_id = availabilty_id;
	}

	public Integer getForm_instance_id() {
		return form_instance_id;
	}

	public void setForm_instance_id(Integer form_instance_id) {
		this.form_instance_id = form_instance_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public TransitportPersonnelModel getPersonnelData() {
		return personnelData;
	}

	public void setPersonnelData(TransitportPersonnelModel personnelData) {
		this.personnelData = personnelData;
	}

}
