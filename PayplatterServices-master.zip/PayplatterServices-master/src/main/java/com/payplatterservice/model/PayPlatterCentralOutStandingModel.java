package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "payplatter_central_oustandings")
public class PayPlatterCentralOutStandingModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer outstanding_id;
	private Integer merchant_id;
	private Integer payer_id;
	private Integer service_id;
	private Integer service_data_id;
	private Integer outstanding_history_id;
	private Float amount_total_outstanding;
	private Date date_generated;
	private Date date_due;
	private Date date_due_late;
	public Integer getOutstanding_id() {
		return outstanding_id;
	}
	public void setOutstanding_id(Integer outstanding_id) {
		this.outstanding_id = outstanding_id;
	}
	public Integer getMerchant_id() {
		return merchant_id;
	}
	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}
	public Integer getPayer_id() {
		return payer_id;
	}
	public void setPayer_id(Integer payer_id) {
		this.payer_id = payer_id;
	}
	public Integer getService_id() {
		return service_id;
	}
	public void setService_id(Integer service_id) {
		this.service_id = service_id;
	}
	public Integer getService_data_id() {
		return service_data_id;
	}
	public void setService_data_id(Integer service_data_id) {
		this.service_data_id = service_data_id;
	}
	public Integer getOutstanding_history_id() {
		return outstanding_history_id;
	}
	public void setOutstanding_history_id(Integer outstanding_history_id) {
		this.outstanding_history_id = outstanding_history_id;
	}
	public Float getAmount_total_outstanding() {
		return amount_total_outstanding;
	}
	public void setAmount_total_outstanding(Float amount_total_outstanding) {
		this.amount_total_outstanding = amount_total_outstanding;
	}
	public Date getDate_generated() {
		return date_generated;
	}
	public void setDate_generated(Date date_generated) {
		this.date_generated = date_generated;
	}
	public Date getDate_due() {
		return date_due;
	}
	public void setDate_due(Date date_due) {
		this.date_due = date_due;
	}
	public Date getDate_due_late() {
		return date_due_late;
	}
	public void setDate_due_late(Date date_due_late) {
		this.date_due_late = date_due_late;
	}
	
	
}
