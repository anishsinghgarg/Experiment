package com.spring.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.model.User;

@Controller
@RequestMapping("user")
public class UserController {
	private static Logger log = Logger.getLogger(UserController.class);

	@RequestMapping(value = "/userRequest", method = RequestMethod.POST)
	public String user(@Validated User user, Model model) {
		log.info("User Page Requested ::" + user.getUserName());
		model.addAttribute("userName", user.getUserName());
		return "user";
	}
}
