package com.payplatterservice.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.CriteriaBuilder.In;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantServicesDetailsBean;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayPlatterCentralOutStandingModel;
import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PayerParameterModel;
import com.payplatterservice.model.PayplatterCentralInvoicesModel;
import com.payplatterservice.model.PersonnelAppointmentModel;
import com.payplatterservice.model.SearchKeyModel;
import com.payplatterservice.model.TransitportPersonnelAvailabilityModel;
import com.payplatterservice.model.TransitportPersonnelModel;
import com.payplatterservice.model.VenueAppointmentModel;
import com.payplatterservice.operationservice.PayerOperationServicesImpl;

@Repository
public class MerchantServiceImpl implements MerchantService {
	private static final Logger logger = Logger.getLogger(MerchantServiceImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public MerchantsModel getMerchantDetailsByID(MerchantsModel model) {
		Session session = sessionFactory.openSession();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<MerchantsModel> query = builder.createQuery(MerchantsModel.class);
			Root<MerchantsModel> root = query.from(MerchantsModel.class);

			query.select(root).where(builder.equal(root.get("id"), model.getId()));
			Query<MerchantsModel> q = session.createQuery(query);
			model = q.getResultList().get(0);
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public PayerParameterModel createInvoicesForPayer(PayerParameterModel payerPramModel) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(payerPramModel);
			session.getTransaction().commit();
			return payerPramModel;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public PayPlatterCentralOutStandingModel getTotalOutstandingDetailsByPayerIDMerchantId(PayerModel prModel,
			MerchantsModel merModel) {
		Session session = sessionFactory.openSession();
		PayPlatterCentralOutStandingModel model = new PayPlatterCentralOutStandingModel();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayPlatterCentralOutStandingModel> query = builder
					.createQuery(PayPlatterCentralOutStandingModel.class);
			Root<PayPlatterCentralOutStandingModel> root = query.from(PayPlatterCentralOutStandingModel.class);

			query.select(root).where(builder.and(builder.equal(root.get(""), prModel.getId())),
					builder.equal(root.get(""), merModel.getId()));

			Query<PayPlatterCentralOutStandingModel> q = session.createQuery(query);
			model = q.getResultList().get(0);
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public Integer getlastInvoiceNoClient() {
		Session session = sessionFactory.openSession();
		Integer invoiceNo;
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<Integer> query = builder.createQuery(Integer.class);
			Root<PayplatterCentralInvoicesModel> root = query.from(PayplatterCentralInvoicesModel.class);
			query.select(builder.max(root.get("invoice_no")));

		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	@Override
	public PayplatterCentralInvoicesModel createInvoiceInCentralInvoicesTable(
			PayplatterCentralInvoicesModel centralInvoices) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(centralInvoices);
			session.getTransaction().commit();
			return centralInvoices;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public PayerParameterModel updateInvoiceRecord(PayerParameterModel payerPramModel) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(payerPramModel);
			session.getTransaction().commit();
			return payerPramModel;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public List<MerchantConfigPreferencesModel> getAllPreferencesBasedOnMerchant(String key, String value) {
		Session session = sessionFactory.openSession();

		List<MerchantConfigPreferencesModel> configModel = new ArrayList<MerchantConfigPreferencesModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<MerchantConfigPreferencesModel> query = builder
					.createQuery(MerchantConfigPreferencesModel.class);
			Root<MerchantConfigPreferencesModel> root = query.from(MerchantConfigPreferencesModel.class);

			query.select(root).where(builder.equal(root.get(key), Integer.parseInt(value)));
			Query<MerchantConfigPreferencesModel> q = session.createQuery(query);
			configModel = (List<MerchantConfigPreferencesModel>) q.getResultList();
			return configModel;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public List<Object[]> getMerchantTransactionList(MerchantsModel model) {
		Session session = sessionFactory.openSession();
		List<PayPlatterTransactionModel> listTxn = new ArrayList<PayPlatterTransactionModel>();
		List<Object[]> listObj = new ArrayList<Object[]>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayPlatterTransactionModel> query = builder.createQuery(PayPlatterTransactionModel.class);
			// CriteriaQuery<Object[]> query =
			// builder.createQuery(Object[].class);
			Root<PayPlatterTransactionModel> root = query.from(PayPlatterTransactionModel.class);
			// query.select(root).where(builder.equal(root.get("merchantsBean").get("id"),
			// model.getId()));

			query.multiselect(root.get("transId"), root.get("transStatus"))
					.where(builder.equal(root.get("merchantsBean").get("id"), model.getId()));
			Query<PayPlatterTransactionModel> q = session.createQuery(query);
			/* Query<Object[]> q = session.createQuery(query); */
			listTxn = q.getResultList();
			System.out.println("Txn List Size ::: " + listTxn.size());
			return null;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public List<TransitportPersonnelModel> getMerchantPersonnelList(Integer merchantID) {
		Session session = sessionFactory.openSession();
		List<TransitportPersonnelModel> list = new ArrayList<TransitportPersonnelModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<TransitportPersonnelModel> query = builder.createQuery(TransitportPersonnelModel.class);
			Root<TransitportPersonnelModel> root = query.from(TransitportPersonnelModel.class);

			query.select(root).where(builder.equal(root.get("merchant_id"), merchantID));
			Query<TransitportPersonnelModel> q = session.createQuery(query);
			list = q.getResultList();

			return list;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public PersonnelAppointmentModel getMerchantAppointmentDetails(Integer personnel_id) {
		Session session = sessionFactory.openSession();
		PersonnelAppointmentModel availability = new PersonnelAppointmentModel();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PersonnelAppointmentModel> query = builder.createQuery(PersonnelAppointmentModel.class);
			Root<PersonnelAppointmentModel> root = query.from(PersonnelAppointmentModel.class);

			query.select(root).where(builder.equal(root.get("personnel_id"), personnel_id));
			Query<PersonnelAppointmentModel> q = session.createQuery(query);
			availability = q.getResultList().get(0);

			return availability;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@Override
	public PersonnelAppointmentModel getMerchantAppointmentDetails(ArrayList<Integer> tokenId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MerchantConfigPreferencesModel> getSearchApperancesPreferences(String key, String value) {
		Session session = sessionFactory.openSession();
		List<MerchantConfigPreferencesModel> list = new ArrayList<MerchantConfigPreferencesModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<MerchantConfigPreferencesModel> query = builder
					.createQuery(MerchantConfigPreferencesModel.class);
			Root<MerchantConfigPreferencesModel> root = query.from(MerchantConfigPreferencesModel.class);

			// query.select(root).where(builder.equal(root.get("lookupPramMOdel").get("id"),
			// value));

			query.select(root).where(builder.and(builder.equal(root.get("lookupPramMOdel").get("id"), 6)),
					builder.equal(root.get("parameter_value"), "Y"));

			Query<MerchantConfigPreferencesModel> q = session.createQuery(query);
			list = q.getResultList();

			return list;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public List<MerchantsModel> getMerchantListBasedOnSearch(String key, Integer setIndID) {
		Session session = sessionFactory.openSession();
		List<MerchantsModel> list = new ArrayList<MerchantsModel>();
		try {
			String sql = "select mm.id as id,mm.Add1 as Add1,mm.Add2 as Add2,mm.Contact as Contact,mm.Business_Name as Business_Name,mm.LegalBusinessName as LegalBusinessName,mm.FName as FName,mm.LName as LName,mm.EmailId as EmailId from MerchantsModel mm, MerchantConfigPreferencesModel mcp where mm.id = mcp.merchant_id and mm.ind_id='"
					+ setIndID + "' and mcp.parameter_value='Y' and mcp.lookupPramMOdel.id='6'";
			logger.info("sql is::" + sql);
			Query query = session.createQuery(sql);
			query.setResultTransformer(Transformers.aliasToBean(MerchantsModel.class));
			list = query.list();
logger.info("Details :: "+list.get(0).getId());
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

}
