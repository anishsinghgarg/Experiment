package com.payplatterservice.service;

import java.util.HashMap;
import java.util.List;

import com.payplatterservice.model.Login;
import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayerModel;

public interface LoginService {

	Login validateLigin(Login login);
	PayerModel getUserProfile(PayerModel payer);
	MerchantsModel getMerchantProfile(MerchantsModel merchant);
	Login createLogin(Login login);
	List<PayerModel> getSearchedPayer(PayerModel model);
	List<MerchantConfigPreferencesModel> merchantPreferencesList(MerchantsModel merchantsBean);
}
