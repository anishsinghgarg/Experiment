package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "merchant_payer_docs")
public class PayerDocumentModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer id;
	@Transient
	private String payerId;
	private String uploade_document_path, shared_document_path;
	private String uploade_document_type_description, shared_document_description;
	private Date shared_upload_date, upload_upload_date;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer merchant_id;

	/*@Lob
	@Column(name = "uploaded_document", columnDefinition = "mediumblob")
	private byte[] uploaded_document;*/

	
	
	@ManyToOne(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "payerId_Fk", referencedColumnName = "id")
	private PayerModel payerBean;
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "did_Fk", referencedColumnName = "document_type_id")
	private DocumentTypeModel documentTypeMOdel;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUploade_document_path() {
		return uploade_document_path;
	}

	public void setUploade_document_path(String uploade_document_path) {
		this.uploade_document_path = uploade_document_path;
	}

	public String getShared_document_path() {
		return shared_document_path;
	}

	public void setShared_document_path(String shared_document_path) {
		this.shared_document_path = shared_document_path;
	}

	public String getUploade_document_type_description() {
		return uploade_document_type_description;
	}

	public void setUploade_document_type_description(String uploade_document_type_description) {
		this.uploade_document_type_description = uploade_document_type_description;
	}

	public String getShared_document_description() {
		return shared_document_description;
	}

	public void setShared_document_description(String shared_document_description) {
		this.shared_document_description = shared_document_description;
	}

	public Date getShared_upload_date() {
		return shared_upload_date;
	}

	public void setShared_upload_date(Date shared_upload_date) {
		this.shared_upload_date = shared_upload_date;
	}

	public Date getUpload_upload_date() {
		return upload_upload_date;
	}

	public void setUpload_upload_date(Date upload_upload_date) {
		this.upload_upload_date = upload_upload_date;
	}

	public Integer getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}
/*
	public byte[] getUploaded_document() {
		return uploaded_document;
	}

	public void setUploaded_document(byte[] uploaded_document) {
		this.uploaded_document = uploaded_document;
	}*/

	
	public PayerModel getPayerBean() {
		return payerBean;
	}

	public void setPayerBean(PayerModel payerBean) {
		this.payerBean = payerBean;
	}

	public DocumentTypeModel getDocumentTypeMOdel() {
		return documentTypeMOdel;
	}

	public void setDocumentTypeMOdel(DocumentTypeModel documentTypeMOdel) {
		this.documentTypeMOdel = documentTypeMOdel;
	}

	public String getPayerId() {
		return payerId;
	}

	public void setPayerId(String payerId) {
		this.payerId = payerId;
	}
	
	
	
	
}
