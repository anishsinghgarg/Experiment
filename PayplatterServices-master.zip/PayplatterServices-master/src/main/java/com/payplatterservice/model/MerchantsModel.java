package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "merchants_master")
public class MerchantsModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer id;
	private String fName;
	private String lName;
	private String business_Name;
	private String legalBusinessName;
	private String emailId;
	private String contact;
	private String add1;
	private String add2;
	private String city;
	private String state;
	private String country;
	private String zip, have_website, activation_link_key, aadhar, PAN;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer ind_id, seg_id, plan_id;
	private String omniportSetupFlag;
	private Integer omniportSetupStage;
	private String status, remark;
	private Date createdDate;

	@Column(nullable = false, columnDefinition = "VARCHAR(10) default 'No'")
	private String isCommissionSetup, isPreferencesSetup;
	
	@JsonSerialize(using=ToStringSerializer.class)
	@Column(nullable = true, columnDefinition = "INT(11) default '0'")
	private Integer sms_counter;

	@Column(name = "mcode", unique = true)
	private String mcode;

	@Transient
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer servicesID;

	@Transient
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer contextID;

	@Transient
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer mappingID;

	@Transient
	private String invoiceType;

	@Transient
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer payerID;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "pgId_Fk", referencedColumnName = "id")
	private PaymentProcessorModel paymentProcessorBean;
	
	@Transient
	private Integer pgId_Fk;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getBusiness_Name() {
		return business_Name;
	}

	public void setBusiness_Name(String business_Name) {
		this.business_Name = business_Name;
	}

	public String getLegalBusinessName() {
		return legalBusinessName;
	}

	public void setLegalBusinessName(String legalBusinessName) {
		this.legalBusinessName = legalBusinessName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getAdd1() {
		return add1;
	}

	public void setAdd1(String add1) {
		this.add1 = add1;
	}

	public String getAdd2() {
		return add2;
	}

	public void setAdd2(String add2) {
		this.add2 = add2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getHave_website() {
		return have_website;
	}

	public void setHave_website(String have_website) {
		this.have_website = have_website;
	}

	public String getActivation_link_key() {
		return activation_link_key;
	}

	public void setActivation_link_key(String activation_link_key) {
		this.activation_link_key = activation_link_key;
	}

	public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public String getPAN() {
		return PAN;
	}

	public void setPAN(String pAN) {
		PAN = pAN;
	}

	public Integer getInd_id() {
		return ind_id;
	}

	public void setInd_id(Integer ind_id) {
		this.ind_id = ind_id;
	}

	public Integer getSeg_id() {
		return seg_id;
	}

	public void setSeg_id(Integer seg_id) {
		this.seg_id = seg_id;
	}

	public Integer getPlan_id() {
		return plan_id;
	}

	public void setPlan_id(Integer plan_id) {
		this.plan_id = plan_id;
	}

	public String getOmniportSetupFlag() {
		return omniportSetupFlag;
	}

	public void setOmniportSetupFlag(String omniportSetupFlag) {
		this.omniportSetupFlag = omniportSetupFlag;
	}

	public Integer getOmniportSetupStage() {
		return omniportSetupStage;
	}

	public void setOmniportSetupStage(Integer omniportSetupStage) {
		this.omniportSetupStage = omniportSetupStage;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getIsCommissionSetup() {
		return isCommissionSetup;
	}

	public void setIsCommissionSetup(String isCommissionSetup) {
		this.isCommissionSetup = isCommissionSetup;
	}

	public String getIsPreferencesSetup() {
		return isPreferencesSetup;
	}

	public void setIsPreferencesSetup(String isPreferencesSetup) {
		this.isPreferencesSetup = isPreferencesSetup;
	}

	public String getMcode() {
		return mcode;
	}

	public void setMcode(String mcode) {
		this.mcode = mcode;
	}

	public Integer getServicesID() {
		return servicesID;
	}

	public void setServicesID(Integer servicesID) {
		this.servicesID = servicesID;
	}

	public Integer getContextID() {
		return contextID;
	}

	public void setContextID(Integer contextID) {
		this.contextID = contextID;
	}

	public Integer getMappingID() {
		return mappingID;
	}

	public void setMappingID(Integer mappingID) {
		this.mappingID = mappingID;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public Integer getPayerID() {
		return payerID;
	}

	public void setPayerID(Integer payerID) {
		this.payerID = payerID;
	}

	public PaymentProcessorModel getPaymentProcessorBean() {
		return paymentProcessorBean;
	}

	public void setPaymentProcessorBean(PaymentProcessorModel paymentProcessorBean) {
		this.paymentProcessorBean = paymentProcessorBean;
	}

	public Integer getPgId_Fk() {
		return pgId_Fk;
	}

	public void setPgId_Fk(Integer pgId_Fk) {
		this.pgId_Fk = pgId_Fk;
	}

	public Integer getSms_counter() {
		return sms_counter;
	}

	public void setSms_counter(Integer sms_counter) {
		this.sms_counter = sms_counter;
	}

	
}
