package com.payplatterservice.model;

import java.io.Serializable;

public class ECollectModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String inquiryRequest;
	private String notifyRequest;
	public String getInquiryRequest() {
		return inquiryRequest;
	}
	public void setInquiryRequest(String inquiryRequest) {
		this.inquiryRequest = inquiryRequest;
	}
	public String getNotifyRequest() {
		return notifyRequest;
	}
	public void setNotifyRequest(String notifyRequest) {
		this.notifyRequest = notifyRequest;
	}
	
	
	
}
