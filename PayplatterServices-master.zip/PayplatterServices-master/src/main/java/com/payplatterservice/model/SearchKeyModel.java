package com.payplatterservice.model;

import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

public class SearchKeyModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer merchantID;
	private String searchKey;
	private String state;
	private String city;
	private String location;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer indID;
	
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer segmentID;
	
	public Integer getMerchantID() {
		return merchantID;
	}
	public void setMerchantID(Integer merchantID) {
		this.merchantID = merchantID;
	}
	public String getSearchKey() {
		return searchKey;
	}
	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Integer getSegmentID() {
		return segmentID;
	}
	public void setSegmentID(Integer segmentID) {
		this.segmentID = segmentID;
	}
	public Integer getIndID() {
		return indID;
	}
	public void setIndID(Integer indID) {
		this.indID = indID;
	}
	
	
}
