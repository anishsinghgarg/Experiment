package com.platterpayservices.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

public class FeeDataModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer feeId;
	private String feeType, serviceTaxType, intHandlingType, merchantGSTType;
	private Integer serviceTax, slabNumber;
	private Float feeValue, serviceTaxValue, intHandlingValue, slabFloor, slabCeiling, merchantGSTValue;
	@Column(name="configurationType", columnDefinition = "varchar(15) default 'SPECIFIC'")
	private String configurationType;
	public Integer getFeeId() {
		return feeId;
	}
	public void setFeeId(Integer feeId) {
		this.feeId = feeId;
	}
	public String getFeeType() {
		return feeType;
	}
	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}
	public String getServiceTaxType() {
		return serviceTaxType;
	}
	public void setServiceTaxType(String serviceTaxType) {
		this.serviceTaxType = serviceTaxType;
	}
	public String getIntHandlingType() {
		return intHandlingType;
	}
	public void setIntHandlingType(String intHandlingType) {
		this.intHandlingType = intHandlingType;
	}
	public String getMerchantGSTType() {
		return merchantGSTType;
	}
	public void setMerchantGSTType(String merchantGSTType) {
		this.merchantGSTType = merchantGSTType;
	}
	public Integer getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(Integer serviceTax) {
		this.serviceTax = serviceTax;
	}
	public Integer getSlabNumber() {
		return slabNumber;
	}
	public void setSlabNumber(Integer slabNumber) {
		this.slabNumber = slabNumber;
	}
	public Float getFeeValue() {
		return feeValue;
	}
	public void setFeeValue(Float feeValue) {
		this.feeValue = feeValue;
	}
	public Float getServiceTaxValue() {
		return serviceTaxValue;
	}
	public void setServiceTaxValue(Float serviceTaxValue) {
		this.serviceTaxValue = serviceTaxValue;
	}
	public Float getIntHandlingValue() {
		return intHandlingValue;
	}
	public void setIntHandlingValue(Float intHandlingValue) {
		this.intHandlingValue = intHandlingValue;
	}
	public Float getSlabFloor() {
		return slabFloor;
	}
	public void setSlabFloor(Float slabFloor) {
		this.slabFloor = slabFloor;
	}
	public Float getSlabCeiling() {
		return slabCeiling;
	}
	public void setSlabCeiling(Float slabCeiling) {
		this.slabCeiling = slabCeiling;
	}
	public Float getMerchantGSTValue() {
		return merchantGSTValue;
	}
	public void setMerchantGSTValue(Float merchantGSTValue) {
		this.merchantGSTValue = merchantGSTValue;
	}
	public String getConfigurationType() {
		return configurationType;
	}
	public void setConfigurationType(String configurationType) {
		this.configurationType = configurationType;
	}

	
}
