package com.payplatterservice.operationservice;

import java.util.List;

import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.SearchKeyModel;
import com.payplatterservice.model.TransitportAssetReservationsModel;
import com.payplatterservice.model.TransitportAssetsModel;

public interface PayerOperationServices {

	List<MerchantsModel> getMerchantSearchAvability(SearchKeyModel searchkey);

	String cancelAssetReservation(TransitportAssetsModel model);

	List<TransitportAssetsModel> assetReservationReschedule(TransitportAssetReservationsModel model);

	String saveRescheduleReservation(TransitportAssetsModel model);

}
