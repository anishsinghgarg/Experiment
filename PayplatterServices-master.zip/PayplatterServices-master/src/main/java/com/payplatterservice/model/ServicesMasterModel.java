package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "master_services_config")
public class ServicesMasterModel implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")	
	@GeneratedValue(generator = "g1")
	@Id@JsonSerialize(using=ToStringSerializer.class)
	private Integer id;
	private String description;
	
	/*@ManyToOne(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "indusId_Fk", referencedColumnName = "Id")
	private IndustryModel industryModel;
	
	@ManyToOne(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "busiId_Fk", referencedColumnName = "Id")
	private BusinessModel businessModel;
	
	@ManyToOne(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "productId_Fk", referencedColumnName = "Id")
	private ProductsModel productsModel;*/



	public String getDescription() {
		return description;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/*public IndustryModel getIndustryModel() {
		return industryModel;
	}

	public void setIndustryModel(IndustryModel industryModel) {
		this.industryModel = industryModel;
	}

	public BusinessModel getBusinessModel() {
		return businessModel;
	}

	public void setBusinessModel(BusinessModel businessModel) {
		this.businessModel = businessModel;
	}

	public ProductsModel getProductsModel() {
		return productsModel;
	}

	public void setProductsModel(ProductsModel productsModel) {
		this.productsModel = productsModel;
	}*/
	
	

}
