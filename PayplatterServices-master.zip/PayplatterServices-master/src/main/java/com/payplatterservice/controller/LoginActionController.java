package com.payplatterservice.controller;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.payplatterservice.model.Login;
import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.security.Encryption;
import com.payplatterservice.service.LoginService;
import com.payplatterservice.service.UserService;

@RestController
public class LoginActionController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(LoginActionController.class);
	@Autowired
	UserService userService; // Service which will do all data
								// retrieval/manipulation work

	@Autowired
	LoginService loginservices;

	@SuppressWarnings({ "unused", "static-access" })
	@RequestMapping(value = "/validateLogin/", method = RequestMethod.POST)
	public String validateLogin(@RequestBody Login loginV, UriComponentsBuilder ucBuilder)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		Login login = new Login();
		Encryption encCode = new Encryption();
		String userName = null;
		String password = null;
		String statusmsg = null;
		String statusCode = null;
		Integer userID = null;
		String emailID = null;
		String name = null;
		String businessNmae=null;
		logger.info("UserName is =" + loginV.getUserName());
		if (loginV.getPassword().equals("Need to Decrypt with " + loginV.getUserName().trim())) {
			logger.info("Direct Login App UserName=" + loginV.getUserName().trim() + "|| and the password is ="
					+ loginV.getPassword());
			String param = null;
			param = encCode.decrypt("dexpertappencdec", "0000000000000000", loginV.getUserName() + "=");
			Map<String, String> querypair = new LinkedHashMap<String, String>();
			try {
				querypair = encCode.splitQuery(param);
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}

			loginV.setUserName(querypair.get("userName"));
			loginV.setPassword(querypair.get("password"));

			logger.info(" New User Name is =" + loginV.getUserName());
			logger.info(" New Pass is =" + loginV.getPassword());
			password = encCode.encrypt("passwordmuskilba", "1234567898765432", loginV.getPassword());
			loginV.setPassword(password);
		} else {
			password = encCode.encrypt("passwordmuskilba", "1234567898765432", loginV.getPassword());

			loginV.setPassword(password);
		}
		try {
			if (loginV != null) {
				String profile = login.getProfile();
				login = loginservices.validateLigin(loginV);

				statusmsg = "Login Successfully Done!!!!!!";
				statusCode = "0000";
				String deviceId = "";
				if (login.getProfile() != null) {
					if ("MERCHANT".equalsIgnoreCase(login.getProfile())) {
						userID = login.getMerchantsBean().getId();
						name = login.getMerchantsBean().getLegalBusinessName();
						emailID = login.getMerchantsBean().getEmailId();
						businessNmae=login.getMerchantsBean().getBusiness_Name();
						List<MerchantConfigPreferencesModel> configPreferences = new ArrayList<MerchantConfigPreferencesModel>();
						HashMap<String, String> pref_map = new HashMap<>();

						try {
							configPreferences = loginservices.merchantPreferencesList(login.getMerchantsBean());
							for (MerchantConfigPreferencesModel merchantConfigPreferencesModel : configPreferences) {

								pref_map.put(merchantConfigPreferencesModel.getLookupPramMOdel().getParameter_name(),
										merchantConfigPreferencesModel.getParameter_value());

							}

							if (pref_map.get("MERCHANT_APP_WELCOME").equals("Y")) {
								statusmsg = "Login Successfully Done!!!!!!";
								statusCode = "0000";
								return "{\"status\":\"success\",\"LoginMSG\":\"" + statusmsg + "\",\"UserProfile\":\""
										+ login.getProfile() + "\",\"StatusCode\":\"" + statusCode + "\",\"userID\":\""
										+ userID + "\",\"UserName\":\"" + name + "\",\"BusinessName\":\"" + businessNmae + "\",\"emailId\":\"" + emailID
										+ "\",\"contactNo\":\"" + login.getContact_no() + "\"}";
							} else {
								statusmsg = "UserName and Password doesn't match";
								statusCode = "777777777";
								return "{\"status\":\"Fail\",\"LoginMSG\":\"" + statusmsg + "\",\"UserProfile\":\""
										+ login.getProfile() + "\",\"StatusCode\":\"" + statusCode + "\",\"userID\":\""
										+ userID + "\",\"UserName\":\"" + name + "\",\"emailId\":\"" + emailID
										+ "\",\"contactNo\":\"" + login.getContact_no() + "\",\"PayerDeviceID\":\""
										+ deviceId + "\"}";
							}
						} catch (Exception e) {
							// TODO: handle exception
						}
					} else if ("Payer".equalsIgnoreCase(login.getProfile())) {
						statusCode = "0000";
						userID = login.getPayerBean().getId();
						emailID = login.getPayerBean().getEmailId();
						name = login.getFirstName() + " " + login.getLastName();
						deviceId = login.getPayerBean().getPayerDevice_ID();
					} else {
						userID = login.getLoginId();
						emailID = login.getEmailId();
					}
					return "{\"status\":\"success\",\"LoginMSG\":\"" + statusmsg + "\",\"UserProfile\":\""
							+ login.getProfile() + "\",\"StatusCode\":\"" + statusCode + "\",\"userID\":\"" + userID
							+ "\",\"UserName\":\"" + name + "\",\"BusinessName\":\"" + businessNmae + "\",\"emailId\":\"" + emailID + "\",\"contactNo\":\""
							+ login.getContact_no() + "\",\"PayerDeviceID\":\"" + deviceId + "\"}";
				} else {
					statusmsg = "UserName and Password doesn't match";
					statusCode = "0001";
					return "{\"status\":\"Fail\",\"LoginMSG\":\"" + statusmsg + "\",\"UserProfile\":\""
							+ login.getProfile() + "\",\"StatusCode\":\"" + statusCode + "\",\"userID\":\"" + userID
							+ "\",\"UserName\":\"" + name + "\",\"emailId\":\"" + emailID + "\",\"contactNo\":\""
							+ login.getContact_no() + "\"}";
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@RequestMapping(value = "/getPayerProfile/", method = RequestMethod.POST, produces = "application/json")
	public String getPayerProfile(@RequestBody PayerModel payer, UriComponentsBuilder ucBuilder) {
		PayerModel model = new PayerModel();
		try {

			model = loginservices.getUserProfile(payer);
			if (model != null) {
				return "{\"Name\":\"" + model.getFirstName() + " " + model.getLastName() + "\",\"ContactNumber\":\""
						+ model.getContact() + "\",\"EmailID\":\"" + model.getEmailId() + "\",\"Address\":\""
						+ model.getAdd1() + "\",\"City\":\"" + model.getCity() + "\",\"State\":\"" + model.getState()
						+ " \",\"Status\":\"" + model.getStatus() + "\"}";
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@RequestMapping(value = "/searchPayer/", method = RequestMethod.POST, produces = "application/json")
	public List<PayerModel> searchPayer(@RequestBody PayerModel model, UriComponentsBuilder ucBuilder) {
		List<PayerModel> list = new ArrayList<PayerModel>();
		try {
			list = loginservices.getSearchedPayer(model);
		} catch (Exception e) {
			// TODO: handle exception
		}

		return list;
	}

	@RequestMapping(value = "/getMerchantProfile/", method = RequestMethod.POST, produces = "application/json")
	public MerchantsModel getMerchantProfile(@RequestBody MerchantsModel merchant, UriComponentsBuilder ucBuilder) {
		MerchantsModel model = new MerchantsModel();
		try {
			model = loginservices.getMerchantProfile(merchant);
			if (model != null) {
				return model;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
