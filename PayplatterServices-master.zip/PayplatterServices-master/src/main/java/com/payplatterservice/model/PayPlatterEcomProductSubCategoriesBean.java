package com.payplatterservice.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "product_subcategories")
public class PayPlatterEcomProductSubCategoriesBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer Id;
	private String sub_prod_name;
	
	@Column(name="sub_prod_code",unique = true)
	private String sub_prod_code;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "product_cat_Fk", referencedColumnName = "Id")
	private PayPlatterEcomProductCategoriesBean productCategoriesBean;
	
	
	@OneToMany(mappedBy = "productSubCategoriesBean")
	List<PayPlatterEcomMerchantProductCategoriesConfBean> merchantProductCategoriesConfBean;


	public Integer getId() {
		return Id;
	}


	public void setId(Integer id) {
		Id = id;
	}


	public String getSub_prod_name() {
		return sub_prod_name;
	}


	public void setSub_prod_name(String sub_prod_name) {
		this.sub_prod_name = sub_prod_name;
	}


	public String getSub_prod_code() {
		return sub_prod_code;
	}


	public void setSub_prod_code(String sub_prod_code) {
		this.sub_prod_code = sub_prod_code;
	}


	public PayPlatterEcomProductCategoriesBean getProductCategoriesBean() {
		return productCategoriesBean;
	}


	public void setProductCategoriesBean(PayPlatterEcomProductCategoriesBean productCategoriesBean) {
		this.productCategoriesBean = productCategoriesBean;
	}


	public List<PayPlatterEcomMerchantProductCategoriesConfBean> getMerchantProductCategoriesConfBean() {
		return merchantProductCategoriesConfBean;
	}


	public void setMerchantProductCategoriesConfBean(
			List<PayPlatterEcomMerchantProductCategoriesConfBean> merchantProductCategoriesConfBean) {
		this.merchantProductCategoriesConfBean = merchantProductCategoriesConfBean;
	}
	
	
}
