package com.payplatterservice.security;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;

import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.service.MerchantService;
import com.payplatterservice.service.PlatterPayOnBoardingServices;
import com.payplatterservice.service.TransactionsService;
import com.platterpayservices.model.ClientDetails;

public class KeyGenerator {

	@Autowired
	MerchantService merchantServices;

	@Autowired
	TransactionsService txnServices;
	
	@Autowired
	PlatterPayOnBoardingServices platterPayOnboarding;

	public String anotherLinkKey() {
		String key = null;
		try {

			SecureRandom prng = SecureRandom.getInstance("SHA1PRNG");
			String randomNum = new Integer(prng.nextInt()).toString();
			MessageDigest sha = MessageDigest.getInstance("SHA-1");
			byte[] result = sha.digest(randomNum.getBytes());
			System.out.println("Random number: " + randomNum);
			System.out.println("Message digest: " + hexEncode(result));
			key = "PP" + randomNum;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return key;

	}

	static private String hexEncode(byte[] aInput) {
		StringBuilder result = new StringBuilder();
		char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
		for (int idx = 0; idx < aInput.length; ++idx) {
			byte b = aInput[idx];
			result.append(digits[(b & 0xf0) >> 4]);
			result.append(digits[b & 0x0f]);
		}
		return result.toString();
	}

	public String createInvoiceId(MerchantsModel merchantsBean) throws ParseException {

		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyhhmmssSS");
		String format = sdf.format(dt);
		String tranxId = null;
		String initialVal = null;
		String lastVal = null;
		try {
			UUID uidPre = UUID.randomUUID();
			UUID uidSuff = UUID.randomUUID();
			String valuePre = String.valueOf(uidPre.getMostSignificantBits());
			String valueSuff = String.valueOf(uidSuff.getMostSignificantBits());

			initialVal = valuePre.substring(4, 8);
			lastVal = valueSuff.substring(9, 14);
			tranxId = format;

			Integer invoiceNo = merchantServices.getlastInvoiceNoClient();
			if (invoiceNo < Integer.MAX_VALUE) {
				tranxId = merchantsBean.getMcode().concat(format.concat(invoiceNo.toString()));
				return tranxId;
			} else {
				BigInteger txnIdBigInt = new BigInteger(tranxId);
				txnIdBigInt = txnIdBigInt.add(BigInteger.ONE);
				tranxId = merchantsBean.getMcode().concat(format.concat(initialVal));
				return txnIdBigInt.toString();
			}

		} catch (Exception e) {
			UUID uidPre = UUID.randomUUID();
			UUID uidSuff = UUID.randomUUID();
			String valuePre = String.valueOf(uidPre.getMostSignificantBits());
			String valueSuff = String.valueOf(uidSuff.getMostSignificantBits());
			initialVal = valuePre.substring(8, 12);
			lastVal = valueSuff.substring(4, 8);
			tranxId = initialVal.concat(format.concat(lastVal));
			tranxId = "INV".concat(merchantsBean.getMcode().concat(tranxId));
			return tranxId;

		}

	}

	public static String usenameLogic(String userName) {
		String finalString = null;
		String dexpert = "PAYPLATTER";
		try {
			userName = userName.replaceAll("[^\\p{Alpha}\\p{Digit}]+", "");
			finalString = StringUtils.substring(userName, 0, 5);
			if (userName.length() < 1) {
				finalString = dexpert;
				finalString = StringUtils.substring(finalString, 0, 5);
				return finalString;
			}
			System.out.println("finalString ::" + finalString);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception :: Because Usename Langth Less then 5" + userName.length());
			Integer userNameLength = userName.length();
			Integer dexpertLength = dexpert.length();
			userNameLength = dexpertLength - userNameLength;
			try {
				finalString = dexpert.substring(0, userNameLength);
				finalString = finalString.concat(userName);
			} catch (Exception e2) {
				System.out.println("Exception :: While Dexpert Username Combine ");
				e.printStackTrace();
			}
		}
		return finalString;
	}

	private static final String ALPHA_CAPS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final String ALPHA = "abcdefghijklmnopqrstuvwxyz";
	private static final String NUM = "0123456789";
	private static final String SPL_CHARS = "!@#$%&*_=+/";

	public static String generatePswd(int minLen, int maxLen, int noOfCAPSAlpha, int noOfDigits, int noOfSplChars) {
		if (minLen > maxLen)
			throw new IllegalArgumentException("Min. Length > Max. Length!");
		if ((noOfCAPSAlpha + noOfDigits + noOfSplChars) > minLen)
			throw new IllegalArgumentException(
					"Min. Length should be atleast sum of (CAPS, DIGITS, SPL CHARS) Length!");
		Random rnd = new Random();
		int len = rnd.nextInt(maxLen - minLen + 1) + minLen;
		char[] pswd = new char[len];
		int index = 0;
		for (int i = 0; i < noOfCAPSAlpha; i++) {
			index = getNextIndex(rnd, len, pswd);
			pswd[index] = ALPHA_CAPS.charAt(rnd.nextInt(ALPHA_CAPS.length()));
		}
		for (int i = 0; i < noOfDigits; i++) {
			index = getNextIndex(rnd, len, pswd);
			pswd[index] = NUM.charAt(rnd.nextInt(NUM.length()));
		}
		for (int i = 0; i < noOfSplChars; i++) {
			index = getNextIndex(rnd, len, pswd);
			pswd[index] = SPL_CHARS.charAt(rnd.nextInt(SPL_CHARS.length()));
		}
		for (int i = 0; i < len; i++) {
			if (pswd[i] == 0) {
				pswd[i] = ALPHA.charAt(rnd.nextInt(ALPHA.length()));
			}
		}
		String pass = pswd.toString();
		return pass;
	}

	private static int getNextIndex(Random rnd, int len, char[] pswd) {
		int index = rnd.nextInt(len);
		while (pswd[index = rnd.nextInt(len)] != 0)
			;
		return index;
	}

	public String createsTransxId(String prodId) throws ParseException {

		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyhhmmssSS");
		String format = sdf.format(dt);
		// System.out.println("date " + format);
		Long nanoTime = System.nanoTime();
		System.out.println("nano sec lngth :: " + nanoTime.toString().length());
		String tranxId = null;
		String initialVal = null;
		String lastVal = null;
		try {
			UUID uidPre = UUID.randomUUID();
			UUID uidSuff = UUID.randomUUID();
			String valuePre = String.valueOf(uidPre.getMostSignificantBits());
			String valueSuff = String.valueOf(uidSuff.getMostSignificantBits());

			initialVal = valuePre.substring(4, 9);
			lastVal = valueSuff.substring(9, 14);

			// tranxId = initialVal.concat(format.concat(lastVal));

			tranxId = format;

			List<String> txnList = txnServices.getOldTxnList(tranxId);

			System.out.println("old txn List Size is ::" + txnList.size());
			if (txnList.isEmpty()) {
				System.out.println("if txId ::" + tranxId);
				System.out.println("txn Id length is ::" + tranxId.length());
				tranxId = prodId + tranxId;
				return tranxId;

			} else {
				BigInteger txnIdBigInt = new BigInteger(tranxId);

				txnIdBigInt = txnIdBigInt.add(BigInteger.ONE);

				System.out.println("else txId ::" + txnIdBigInt);
				System.out.println("txn Id length is ::" + txnIdBigInt.toString().length());
				tranxId = "LP" + tranxId;
				return txnIdBigInt.toString();
			}

		} catch (Exception e) {
			UUID uidPre = UUID.randomUUID();
			UUID uidSuff = UUID.randomUUID();
			String valuePre = String.valueOf(uidPre.getMostSignificantBits());
			String valueSuff = String.valueOf(uidSuff.getMostSignificantBits());
			initialVal = valuePre.substring(9, 14);
			lastVal = valueSuff.substring(4, 9);
			tranxId = initialVal.concat(format.concat(lastVal));
			System.out.println("Last : " + tranxId);
			/*
			 * List<String> txnList = txnServices.getOldTxnList(tranxId); if
			 * (txnList.isEmpty()) { System.out.println("catch if txId ::" +
			 * tranxId); System.out.println("txn Id length is ::" +
			 * tranxId.length()); tranxId = prodId + tranxId; return tranxId;
			 * 
			 * } else {
			 */

			BigInteger txnIdBigInt = new BigInteger(tranxId);

			txnIdBigInt = txnIdBigInt.add(BigInteger.ONE);

			System.out.println("catch else txId ::" + txnIdBigInt);
			System.out.println("txn Id length is ::" + txnIdBigInt.toString().length());
			tranxId = prodId + tranxId;
			return txnIdBigInt.toString();
			// }
		}

	}
	
	public ClientDetails GenerateLoginCreds(ClientDetails client) {
		String username = client.getClientEmail().split("@")[0];
		String pass = "";
		String code = client.getClientCode();
		String id = "-99";
		StringBuilder usrn = new StringBuilder();
		StringBuilder ps = new StringBuilder();
		ps.append(code);
		ps.append("_");
		ps.append("SP");
		ps.append(id);
		pass = ps.toString();
		usrn.append(username);
		usrn.append("_");
		usrn.append(id);
		username = usrn.toString();
		client.setClientUsername(username);
		;
		client.setClientPass(pass);
		return client;
	}
	
	public ClientDetails GenerateKey(ClientDetails client) {
		char[] VALID_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456879".toCharArray();
		int numChars = 16;
		SecureRandom srand = new SecureRandom();
		Random rand = new Random();
		boolean loopFlag = true;
		try {
			while (loopFlag) {
				char[] buff = new char[numChars];

				for (int i = 0; i < numChars; ++i) {
					// reseed rand once you've used up all available entropy
					// bits
					if ((i % 10) == 0) {
						rand.setSeed(srand.nextLong()); // 64 bits of random!
					}
					buff[i] = VALID_CHARACTERS[rand.nextInt(VALID_CHARACTERS.length)];
				}
				String keyStr = new String(buff);
				System.out.println("Key :: "+keyStr);
				//loopFlag=platterPayOnboarding.isValidKeyIV("clientKey",keyStr);
				/*if (loopFlag==true) {
					loopFlag = false;
					client.setClientKey(keyStr);
				}*/
				loopFlag = false;
				client.setClientKey(keyStr);
			}
			return client;
		} catch(Exception e){
		e.printStackTrace();
		return client;
		}finally {
		}

		}
	
	public ClientDetails GenerateIV(ClientDetails client) {
		char[] VALID_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456879".toCharArray();
		int numChars = 16;
		SecureRandom srand = new SecureRandom();
		Random rand = new Random();
		boolean loopFlag = true;
		try {
			while (loopFlag) {
				char[] buff = new char[numChars];

				for (int i = 0; i < numChars; ++i) {
					if ((i % 10) == 0) {
						rand.setSeed(srand.nextLong());
					}
					buff[i] = VALID_CHARACTERS[rand.nextInt(VALID_CHARACTERS.length)];
				}
				String keyStr = new String(buff);
				/*if (platterPayOnboarding.isValidKeyIV("clientIV",keyStr)) {
					loopFlag = false;
					client.setClientIV(keyStr);
				}*/
				loopFlag = false;
				client.setClientIV(keyStr);
			}
			return client;
		} finally {

		}
	}
	
}
