package com.payplatterservice.controller;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.payplatterservice.model.BCObjectKeyModel;
import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.ObjectKeyModel;
import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.operationservice.MerchantOperationServices;
import com.payplatterservice.service.MerchantService;

@RestController
public class MerchantActionController implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(MerchantActionController.class);
	@Autowired
	MerchantOperationServices merchantOperServices;

	@Autowired
	MerchantService merchantServices;

	@RequestMapping(value = "/createInvoices/", method = RequestMethod.POST, produces = "application/json")
	public String createInvoices(@RequestBody ObjectKeyModel objectKey, UriComponentsBuilder ucBuilder) {

		String statusmsg = null;
		String statusCode = null;
		String respMsg = null;

		if (objectKey.getMerchantID() != null && objectKey.getInvoiceType() != null
				&& objectKey.getBaseAmount() != null && objectKey.getPayment_name() != null
				&& objectKey.getServiceID() != null) {

			if (objectKey.getInvoiceType().equalsIgnoreCase("Enroll")) {

				respMsg = merchantOperServices.createInvoicesForEnrollPayer(objectKey);
				return respMsg;

			} else if (objectKey.getInvoiceType().equalsIgnoreCase("Guest")) {

				respMsg = merchantOperServices.createInvoicesForGuestPayer(objectKey);
				return respMsg;
			} else {

				statusCode = "0001";
				statusmsg = "This invoice type does not exit in our system!!!!";
				respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
				return respMsg;
			}
		} else {
			statusCode = "3333";
			statusmsg = "You Passed some mandatory Parameter  NULL/BLANCK. SO, Not able to Process for it!!!!";
			respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
			return respMsg;
		}

	}

	@RequestMapping(value = "/createPayer/", method = RequestMethod.POST, produces = "application/json")
	public String createPayer(@RequestBody PayerModel model, UriComponentsBuilder ucBuilder) {

		String respMsg = null;
		respMsg = merchantOperServices.validateUserExitOrNot(model);
		return respMsg;
	}

	@RequestMapping(value = "/getMerchantPayes/", method = RequestMethod.POST, produces = "application/json")
	public List<PayerModel> getMerchantPayes(@RequestBody MerchantsModel model, UriComponentsBuilder ucBuilder) {
		List<PayerModel> payerList = new ArrayList<PayerModel>();
		System.out.println("Merchant Model :::: " + model.getId());
		if (model.getId() != null) {
			payerList = merchantOperServices.getMerchantPayerList(model);
		}
		logger.info("Payer List Size ::: " + payerList.size());
		return payerList;
	}

	@RequestMapping(value = "/getMerchantTransaction/", method = RequestMethod.POST, produces = "application/json")
	public List<PayPlatterTransactionModel> getMerchantTransaction(@RequestBody MerchantsModel model,
			UriComponentsBuilder ucBuilder) {
		List<Object[]> listObject=new ArrayList<Object[]>();
		try {
			List<PayPlatterTransactionModel> txnModel = new ArrayList<PayPlatterTransactionModel>();
			long startTime = System.currentTimeMillis();

			if (model != null) {
				listObject = merchantServices.getMerchantTransactionList(model);
				

			} else {
				logger.info("Request Nerchant Model is Null!!!!!!!!");

			}

			long stopTime = System.currentTimeMillis();
			NumberFormat formatter = new DecimalFormat("#0.00000");
			System.out.print("Execution time is " + formatter.format((stopTime - startTime) / 1000d)
					+ " seconds taken to get Data from DB data size is : " + txnModel.size());
			@SuppressWarnings("unchecked")
			Collection<? extends PayPlatterTransactionModel> list = new ArrayList(Arrays.asList(listObject));
			txnModel.addAll(list);
			return txnModel;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}
	
	
	@RequestMapping(value="/merchantBusinessContext/",method=RequestMethod.POST,produces="application/json")
	public List<Object>merchantBusinessContext(@RequestBody BCObjectKeyModel objectKeyModel,UriComponentsBuilder ucBuilder){
		
		List<Object> listObject=new ArrayList<Object>();
		listObject=merchantOperServices.getBusinessContextReport(objectKeyModel);
		
		return listObject;
	}
}
