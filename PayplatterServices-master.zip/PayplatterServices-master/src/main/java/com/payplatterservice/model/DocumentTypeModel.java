package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "lookup_document_types")
public class DocumentTypeModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer document_type_id;
	private String document_type_description,document_type,doc_perp;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer pg_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer merchant_id;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP")
	private Date created_date=new Date();

	public Integer getDocument_type_id() {
		return document_type_id;
	}

	public void setDocument_type_id(Integer document_type_id) {
		this.document_type_id = document_type_id;
	}

	public String getDocument_type_description() {
		return document_type_description;
	}

	public void setDocument_type_description(String document_type_description) {
		this.document_type_description = document_type_description;
	}

	public String getDocument_type() {
		return document_type;
	}

	public void setDocument_type(String document_type) {
		this.document_type = document_type;
	}

	public String getDoc_perp() {
		return doc_perp;
	}

	public void setDoc_perp(String doc_perp) {
		this.doc_perp = doc_perp;
	}

	public Integer getPg_id() {
		return pg_id;
	}

	public void setPg_id(Integer pg_id) {
		this.pg_id = pg_id;
	}

	public Integer getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	
	
}
