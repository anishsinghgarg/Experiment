package com.yash.training.aws;

import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;

public class S3ListBucket {
    public static void main(String[] args) {
        AmazonS3 amazonS3 = AmazonS3ClientBuilder.standard()
                .withRegion(Regions.US_WEST_2)
                .withCredentials(new InstanceProfileCredentialsProvider(false))
                .build();

        for (Bucket bucket : amazonS3.listBuckets()) {
            System.out.println(bucket.getName());
        }

    }

}
