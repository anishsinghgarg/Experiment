package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

public class PlatterPayTransactionBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String txnId;
	private String paymentMode, payeeFirstName, payeeMidName, payeeLstName, payeeMob, payeeEmail, status,
	bankTxnId, PGTxnId, authCode, PGResponseCode, clientName, PGName, uitApplicationId, applicationReturnPath,
	regNumber, studentUIN, PGPayMode, applicationFailurePath, payPlatterRespCode, studentPayCycle, qCCID, qCBId;
	
	private Double payeeAmount, serviceCharge, convifee, IntHandCharges, actAmount, PGReturnAmount;
	private Date transDate;
	private String transCompleteDate;
	private String alertFlag,clientRequestIP,resMsg;
	private Integer clientId, mappingId;
	private String changed_on_followup;
	private String refund_message, refund_status_code, refundDate,programID,challanNo;

	private Integer enquiryCounter;

	private Date enquiryDate;

	private String saveFlag;
	private String clientTxnId;
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getPayeeFirstName() {
		return payeeFirstName;
	}
	public void setPayeeFirstName(String payeeFirstName) {
		this.payeeFirstName = payeeFirstName;
	}
	public String getPayeeMidName() {
		return payeeMidName;
	}
	public void setPayeeMidName(String payeeMidName) {
		this.payeeMidName = payeeMidName;
	}
	public String getPayeeLstName() {
		return payeeLstName;
	}
	public void setPayeeLstName(String payeeLstName) {
		this.payeeLstName = payeeLstName;
	}
	public String getPayeeMob() {
		return payeeMob;
	}
	public void setPayeeMob(String payeeMob) {
		this.payeeMob = payeeMob;
	}
	public String getPayeeEmail() {
		return payeeEmail;
	}
	public void setPayeeEmail(String payeeEmail) {
		this.payeeEmail = payeeEmail;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBankTxnId() {
		return bankTxnId;
	}
	public void setBankTxnId(String bankTxnId) {
		this.bankTxnId = bankTxnId;
	}
	public String getPGTxnId() {
		return PGTxnId;
	}
	public void setPGTxnId(String pGTxnId) {
		PGTxnId = pGTxnId;
	}
	public String getAuthCode() {
		return authCode;
	}
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}
	public String getPGResponseCode() {
		return PGResponseCode;
	}
	public void setPGResponseCode(String pGResponseCode) {
		PGResponseCode = pGResponseCode;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getPGName() {
		return PGName;
	}
	public void setPGName(String pGName) {
		PGName = pGName;
	}
	public String getUitApplicationId() {
		return uitApplicationId;
	}
	public void setUitApplicationId(String uitApplicationId) {
		this.uitApplicationId = uitApplicationId;
	}
	public String getApplicationReturnPath() {
		return applicationReturnPath;
	}
	public void setApplicationReturnPath(String applicationReturnPath) {
		this.applicationReturnPath = applicationReturnPath;
	}
	public String getRegNumber() {
		return regNumber;
	}
	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}
	public String getStudentUIN() {
		return studentUIN;
	}
	public void setStudentUIN(String studentUIN) {
		this.studentUIN = studentUIN;
	}
	public String getPGPayMode() {
		return PGPayMode;
	}
	public void setPGPayMode(String pGPayMode) {
		PGPayMode = pGPayMode;
	}
	public String getApplicationFailurePath() {
		return applicationFailurePath;
	}
	public void setApplicationFailurePath(String applicationFailurePath) {
		this.applicationFailurePath = applicationFailurePath;
	}
	public String getPayPlatterRespCode() {
		return payPlatterRespCode;
	}
	public void setPayPlatterRespCode(String payPlatterRespCode) {
		this.payPlatterRespCode = payPlatterRespCode;
	}
	public String getStudentPayCycle() {
		return studentPayCycle;
	}
	public void setStudentPayCycle(String studentPayCycle) {
		this.studentPayCycle = studentPayCycle;
	}
	public String getqCCID() {
		return qCCID;
	}
	public void setqCCID(String qCCID) {
		this.qCCID = qCCID;
	}
	public String getqCBId() {
		return qCBId;
	}
	public void setqCBId(String qCBId) {
		this.qCBId = qCBId;
	}
	public Double getPayeeAmount() {
		return payeeAmount;
	}
	public void setPayeeAmount(Double payeeAmount) {
		this.payeeAmount = payeeAmount;
	}
	public Double getServiceCharge() {
		return serviceCharge;
	}
	public void setServiceCharge(Double serviceCharge) {
		this.serviceCharge = serviceCharge;
	}
	public Double getConvifee() {
		return convifee;
	}
	public void setConvifee(Double convifee) {
		this.convifee = convifee;
	}
	public Double getIntHandCharges() {
		return IntHandCharges;
	}
	public void setIntHandCharges(Double intHandCharges) {
		IntHandCharges = intHandCharges;
	}
	public Double getActAmount() {
		return actAmount;
	}
	public void setActAmount(Double actAmount) {
		this.actAmount = actAmount;
	}
	public Double getPGReturnAmount() {
		return PGReturnAmount;
	}
	public void setPGReturnAmount(Double pGReturnAmount) {
		PGReturnAmount = pGReturnAmount;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	
	public String getTransCompleteDate() {
		return transCompleteDate;
	}
	public void setTransCompleteDate(String transCompleteDate) {
		this.transCompleteDate = transCompleteDate;
	}
	public String getAlertFlag() {
		return alertFlag;
	}
	public void setAlertFlag(String alertFlag) {
		this.alertFlag = alertFlag;
	}
	public String getClientRequestIP() {
		return clientRequestIP;
	}
	public void setClientRequestIP(String clientRequestIP) {
		this.clientRequestIP = clientRequestIP;
	}
	public String getResMsg() {
		return resMsg;
	}
	public void setResMsg(String resMsg) {
		this.resMsg = resMsg;
	}
	public Integer getClientId() {
		return clientId;
	}
	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}
	public Integer getMappingId() {
		return mappingId;
	}
	public void setMappingId(Integer mappingId) {
		this.mappingId = mappingId;
	}
	public String getChanged_on_followup() {
		return changed_on_followup;
	}
	public void setChanged_on_followup(String changed_on_followup) {
		this.changed_on_followup = changed_on_followup;
	}
	public String getRefund_message() {
		return refund_message;
	}
	public void setRefund_message(String refund_message) {
		this.refund_message = refund_message;
	}
	public String getRefund_status_code() {
		return refund_status_code;
	}
	public void setRefund_status_code(String refund_status_code) {
		this.refund_status_code = refund_status_code;
	}
	public String getRefundDate() {
		return refundDate;
	}
	public void setRefundDate(String refundDate) {
		this.refundDate = refundDate;
	}
	public String getProgramID() {
		return programID;
	}
	public void setProgramID(String programID) {
		this.programID = programID;
	}
	public String getChallanNo() {
		return challanNo;
	}
	public void setChallanNo(String challanNo) {
		this.challanNo = challanNo;
	}
	public Integer getEnquiryCounter() {
		return enquiryCounter;
	}
	public void setEnquiryCounter(Integer enquiryCounter) {
		this.enquiryCounter = enquiryCounter;
	}
	public Date getEnquiryDate() {
		return enquiryDate;
	}
	public void setEnquiryDate(Date enquiryDate) {
		this.enquiryDate = enquiryDate;
	}
	public String getSaveFlag() {
		return saveFlag;
	}
	public void setSaveFlag(String saveFlag) {
		this.saveFlag = saveFlag;
	}
	public String getClientTxnId() {
		return clientTxnId;
	}
	public void setClientTxnId(String clientTxnId) {
		this.clientTxnId = clientTxnId;
	}
	
	
	
}
