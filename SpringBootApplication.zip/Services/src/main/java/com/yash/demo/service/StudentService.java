package com.yash.demo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.yash.demo.model.Course;
import com.yash.demo.model.Student;

@Component
public class StudentService {
	private static List<Student> students = new ArrayList<>();

	static {
		// Initialize Data
		Course course1 = new Course();
		course1.setId("Course1");
		course1.setName("Spring");
		course1.setDescription("10 Steps");
		course1.setSteps(Arrays.asList("Learn Maven", "Import Project", "First Example", "Second Example"));

		Course course2 = new Course();
		course2.setId("Course2");
		course2.setName("Spring MVC");
		course2.setDescription("10 Examples");
		course2.setSteps(Arrays.asList("Learn Maven", "Import Project", "First Example", "Second Example"));

		Student ranga = new Student();
		ranga.setId("Student1");
		ranga.setName("Ranga Karanam");
		ranga.setDescription("Hiker, Programmer and Architect");
		ranga.setCourses(new ArrayList<>(Arrays.asList(course1, course2)));

		students.add(ranga);
	}

	public Student retrieveStudent(String studentId) {
		for (Student student : students) {
			if (student.getId().equals(studentId)) {
				return student;
			}
		}
		return null;
	}

	public List<Course> retrieveCourses(String studentId) {
		Student student = retrieveStudent(studentId);

		if (student == null) {
			return null;
		}

		return student.getCourses();
	}
}
