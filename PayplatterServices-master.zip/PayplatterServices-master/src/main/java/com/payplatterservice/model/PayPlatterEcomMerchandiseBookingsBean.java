package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PayPlatterEcomInventoryBean;;

@Entity
@Table(name = "merchandise_bookings")
public class PayPlatterEcomMerchandiseBookingsBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer booking_id;
	private String delivery_method, delivery_type, refund_status, delivery_schedule, shipping_address, delivery_status;
	private Date expected_delivery_date, actual_deivery_date, shipping_date;
	private Double base_price, pp_commission_amount, discount;
	private Integer shipping_charges;
	private Integer no_item_taken, merchant_id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP default CURRENT_TIMESTAMP")
	private Date created_date = new Date();

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "payerId_Fk", referencedColumnName = "Id")
	private PayerModel payerBean;

	/*
	 * @ManyToOne(cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "merchandise_product_id_fk", referencedColumnName =
	 * "Id") private MerchandiseMasterBean merchandiseMasterBean;
	 */

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "inverntory_id_fk", referencedColumnName = "inventory_id")
	private PayPlatterEcomInventoryBean inventoryBean;
	
	
	@Transient
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer payerId;

	public Integer getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(Integer booking_id) {
		this.booking_id = booking_id;
	}

	public String getDelivery_method() {
		return delivery_method;
	}

	public void setDelivery_method(String delivery_method) {
		this.delivery_method = delivery_method;
	}

	public String getDelivery_type() {
		return delivery_type;
	}

	public void setDelivery_type(String delivery_type) {
		this.delivery_type = delivery_type;
	}

	public String getRefund_status() {
		return refund_status;
	}

	public void setRefund_status(String refund_status) {
		this.refund_status = refund_status;
	}

	public Date getExpected_delivery_date() {
		return expected_delivery_date;
	}

	public void setExpected_delivery_date(Date expected_delivery_date) {
		this.expected_delivery_date = expected_delivery_date;
	}

	public Date getActual_deivery_date() {
		return actual_deivery_date;
	}

	public void setActual_deivery_date(Date actual_deivery_date) {
		this.actual_deivery_date = actual_deivery_date;
	}

	public Double getBase_price() {
		return base_price;
	}

	public void setBase_price(Double base_price) {
		this.base_price = base_price;
	}

	public Double getPp_commission_amount() {
		return pp_commission_amount;
	}

	public void setPp_commission_amount(Double pp_commission_amount) {
		this.pp_commission_amount = pp_commission_amount;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}


	public Integer getShipping_charges() {
		return shipping_charges;
	}

	public void setShipping_charges(Integer shipping_charges) {
		this.shipping_charges = shipping_charges;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}



	public PayerModel getPayerBean() {
		return payerBean;
	}

	public void setPayerBean(PayerModel payerBean) {
		this.payerBean = payerBean;
	}

	public String getShipping_address() {
		return shipping_address;
	}

	public void setShipping_address(String shipping_address) {
		this.shipping_address = shipping_address;
	}

	public String getDelivery_schedule() {
		return delivery_schedule;
	}

	public void setDelivery_schedule(String delivery_schedule) {
		this.delivery_schedule = delivery_schedule;
	}

	public Integer getNo_item_taken() {
		return no_item_taken;
	}

	public void setNo_item_taken(Integer no_item_taken) {
		this.no_item_taken = no_item_taken;
	}

	public Integer getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}



	public PayPlatterEcomInventoryBean getInventoryBean() {
		return inventoryBean;
	}

	public void setInventoryBean(PayPlatterEcomInventoryBean inventoryBean) {
		this.inventoryBean = inventoryBean;
	}

	public String getDelivery_status() {
		return delivery_status;
	}

	public void setDelivery_status(String delivery_status) {
		this.delivery_status = delivery_status;
	}

	public Date getShipping_date() {
		return shipping_date;
	}

	public void setShipping_date(Date shipping_date) {
		this.shipping_date = shipping_date;
	}

	public Integer getPayerId() {
		return payerId;
	}

	public void setPayerId(Integer payerId) {
		this.payerId = payerId;
	}
	

}
