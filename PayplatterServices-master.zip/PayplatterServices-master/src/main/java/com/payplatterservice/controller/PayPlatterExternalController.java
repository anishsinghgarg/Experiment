package com.payplatterservice.controller;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PayplatterCentralInvoicesModel;
import com.payplatterservice.model.PlatterPayTransactionBean;
import com.payplatterservice.model.SampleFormModel;
import com.payplatterservice.model.SampleTransModel;
import com.payplatterservice.model.TempTableMISDataEcoTouristCenterModel;
import com.payplatterservice.model.TempTableMISDataHorticultureAppModel;
import com.payplatterservice.model.TempTableModelTrakingPayment;
import com.payplatterservice.security.KeyGenerator;
import com.payplatterservice.service.MerchantService;
import com.payplatterservice.service.MerchantServicesService;
import com.payplatterservice.service.PlatterPayService;
import com.payplatterservice.service.TransactionsService;
import com.payplatterservice.service.TransitportFormServices;

@RestController
public class PayPlatterExternalController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(PayPlatterExternalController.class);
	@Autowired
	TransitportFormServices services;

	@Autowired
	TransactionsService txnServices;

	@Autowired
	MerchantServicesService merServices;
	@Autowired
	MerchantService merchantServices;

	@Autowired
	PlatterPayService platterPayServices;

	@SuppressWarnings("unused")
	@RequestMapping(value = "/trekkingFormDetails/", method = RequestMethod.POST, produces = "application/json")
	public String trakingFormDetails(@RequestBody TempTableModelTrakingPayment trakingPayment,
			UriComponentsBuilder ucBuilder) throws IOException {
		SampleTransModel sampleTransModel = null;
		SampleFormModel formModel = new SampleFormModel();
		MerchantsModel merModel = null;
		String statusmsg = null;
		String statusCode = null;
		String transid = null;
		PayPlatterTransactionModel payPlatertransModel = null;
		PlatterPayTransactionBean platterPayBean = new PlatterPayTransactionBean();
		try {
			merModel = new MerchantsModel();
			merModel.setId(39);
			merModel = merchantServices.getMerchantDetailsByID(merModel);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		formModel.setFormInstId(49);
		formModel.setFormTemplateId(merModel.getId());

		formModel.setName(trakingPayment.getFirstName() + " " + trakingPayment.getLastName());
		formModel.setEmail(trakingPayment.getEmail());
		formModel.setContact(trakingPayment.getContact());

		formModel.setFormDate(new Date());
		if (trakingPayment != null) {
			System.out.println("model Return ID : " + formModel.getFormId());
			payPlatertransModel = new PayPlatterTransactionModel();

			try {
				platterPayBean = platterPayServices.getTransactionDetails("clientTxnId", trakingPayment.getTransId());
			} catch (Exception e) {
				statusmsg = "Invalid Transaction Id!!";
				statusCode = "0001";
				return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
			}

			Integer inserting_txn_id = txnServices.getMaximumTransactionId();
			Integer result = txnServices.setTransactionId(inserting_txn_id);

			if (inserting_txn_id < 1) {
				statusmsg = "Unable to Create Transaction!!";
				statusCode = "0001";
				return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
			}
			logger.info("PlatterPay Id:" + inserting_txn_id);
			payPlatertransModel.setId(inserting_txn_id);
			payPlatertransModel = txnServices.getTransactionBeanByID(payPlatertransModel);

			try {
				logger.info("PlatterPay Transaction Payment Mode : " + platterPayBean.getPaymentMode() + " ID : "
						+ platterPayBean.getTxnId());

				trakingPayment.setTransPaymode(trakingPayment.getTransPaymode());

				payPlatertransModel.setPpTransId(platterPayBean.getTxnId());
				payPlatertransModel.setActAmount(platterPayBean.getActAmount());
				payPlatertransModel.setTransAmount(Double.valueOf(trakingPayment.getTotalamt().toString()));
				payPlatertransModel.setPgRespCode(platterPayBean.getPayPlatterRespCode());
				payPlatertransModel.setTransStatus(platterPayBean.getStatus());
				payPlatertransModel.setTransAmount(platterPayBean.getPayeeAmount());
				payPlatertransModel.setPgTransId(platterPayBean.getPGTxnId());
				payPlatertransModel.setTransId(platterPayBean.getClientTxnId());

				payPlatertransModel.setPayment_processor_id(1);
				payPlatertransModel.setContact(trakingPayment.getContact());
				payPlatertransModel.setEmail(trakingPayment.getEmail());
				payPlatertransModel.setName(trakingPayment.getFirstName() + " " + trakingPayment.getLastName());

				payPlatertransModel.setTransaction_type("EXTERNAL");
				payPlatertransModel.setTxnCreateDate(new Date());
				payPlatertransModel.setTxncloseDate(new Date());
				logger.info("Merchant Id : " + merModel.getId());
				payPlatertransModel.setMerchantsBean(merModel);
				payPlatertransModel = txnServices.createTransactionOfPayer(payPlatertransModel);

			} catch (Exception e) {
				e.printStackTrace();
				statusmsg = "Trekking Form Details Not Saved Due to Some Mandatry Parameter is NULL!!!!";
				statusCode = "0001";
				return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
			}
			if (payPlatertransModel != null) {
				try {
					Date trek_date = new Date();
					trek_date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(trakingPayment.getTrekDate());
					trakingPayment.setTrekDate(trakingPayment.getTrekDate());
				} catch (Exception e) {
					// TODO: handle exception
				}
				try {
					trakingPayment.setForm_instanceId(payPlatertransModel.getId());

					trakingPayment.setTransId(payPlatertransModel.getTransId());
					trakingPayment.setTotalamt(payPlatertransModel.getTransAmount().toString());
					trakingPayment.setPpTransId(payPlatertransModel.getPpTransId());
					trakingPayment.setPgTransId(payPlatertransModel.getPgTransId());
					trakingPayment.setStatus(payPlatertransModel.getTransStatus());

					trakingPayment.setCreated_date(new Date());
					// trakingPayment.setId(services.getMaximumTrekkingFormId());
					trakingPayment = services.saveTempTableFormDetails(trakingPayment);

					logger.info("Return From Temp Table :: " + trakingPayment.getId());
					statusmsg = "Trekking Form Details Saved  Success Fully!!!!";
					statusCode = "200";
					return "{\"status\":\"SUCCESS\",\"ResponseMSG\":\"" + statusmsg + "\"}";
				} catch (Exception e) {
					// TODO: handle exception
					logger.info("Return From Temp Table :: " + trakingPayment.getId());
					statusmsg = "Trekking Form Details Not Saved Due to Some Mandatry Parameter is NULL!!!!";
					statusCode = "0001";
					return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
				}

			}
			statusmsg = "Trekking Form Details Saved Successfully!!!!";
			statusCode = "200";
			return "{\"status\":\"SUCCESS\",\"ResponseMSG\":\"" + statusmsg + "\"}";

		} else {
			statusmsg = "Trekking Form Details Not Saved Due to Some Mandatry Parameter is NULL!!!!";
			statusCode = "0001";
			return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
		}

	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/touristCenterFormDetails/", method = RequestMethod.POST, produces = "application/json")
	public String touristCenterFormDetails(@RequestBody TempTableMISDataEcoTouristCenterModel trakingPayment,
			UriComponentsBuilder ucBuilder) throws IOException {
		SampleTransModel sampleTransModel = null;
		SampleFormModel formModel = new SampleFormModel();
		MerchantsModel merModel = null;
		String statusmsg = null;
		String statusCode = null;
		String transid = null;
		PlatterPayTransactionBean platterPayBean = new PlatterPayTransactionBean();
		PayPlatterTransactionModel payPlatertransModel = null;

		formModel.setName(trakingPayment.getFirstName() + " " + trakingPayment.getLastName());
		formModel.setEmail(trakingPayment.getEmail());
		formModel.setContact(trakingPayment.getContact());
		try {
			merModel = new MerchantsModel();
			merModel.setId(38);
			merModel = merchantServices.getMerchantDetailsByID(merModel);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		formModel.setFormInstId(48);
		formModel.setFormTemplateId(merModel.getId());
		formModel.setFormDate(new Date());
		if (trakingPayment != null) {
			System.out.println("model Return ID : " + formModel.getFormId());
			payPlatertransModel = new PayPlatterTransactionModel();
			try {
				platterPayBean = platterPayServices.getTransactionDetails("clientTxnId", trakingPayment.getTransId());
			} catch (Exception e) {
				statusmsg = "Invalid Transaction Id!!";
				statusCode = "0001";
				return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
			}
			Integer inserting_txn_id = txnServices.getMaximumTransactionId();
			Integer result = txnServices.setTransactionId(inserting_txn_id);

			if (inserting_txn_id < 1) {
				statusmsg = "Unable to Create Transaction!!";
				statusCode = "0001";
				return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
			}
			logger.info("PlatterPay Id:" + inserting_txn_id);
			payPlatertransModel.setId(inserting_txn_id);
			payPlatertransModel = txnServices.getTransactionBeanByID(payPlatertransModel);

			try {
				logger.info("PlatterPay Transaction Payment Mode : " + platterPayBean.getPaymentMode() + " ID : "
						+ platterPayBean.getTxnId());
				trakingPayment.setTransPaymode(platterPayBean.getPaymentMode());

				payPlatertransModel.setPpTransId(platterPayBean.getTxnId());
				payPlatertransModel.setActAmount(platterPayBean.getActAmount());
				payPlatertransModel.setTransAmount(Double.valueOf(trakingPayment.getTotalamt().toString()));
				payPlatertransModel.setPgRespCode(platterPayBean.getPayPlatterRespCode());
				payPlatertransModel.setTransStatus(platterPayBean.getStatus());
				payPlatertransModel.setTransAmount(platterPayBean.getPayeeAmount());
				payPlatertransModel.setPgTransId(platterPayBean.getPGTxnId());
				payPlatertransModel.setTransId(platterPayBean.getClientTxnId());

				payPlatertransModel.setPayment_processor_id(1);
				payPlatertransModel.setContact(trakingPayment.getContact());
				payPlatertransModel.setEmail(trakingPayment.getEmail());
				payPlatertransModel.setName(trakingPayment.getFirstName() + " " + trakingPayment.getLastName());

				payPlatertransModel.setTransaction_type("EXTERNAL");
				payPlatertransModel.setTxnCreateDate(new Date());
				payPlatertransModel.setTxncloseDate(new Date());
				logger.info("Merchant Id : " + merModel.getId());
				payPlatertransModel.setMerchantsBean(merModel);
				payPlatertransModel = txnServices.createTransactionOfPayer(payPlatertransModel);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (payPlatertransModel != null) {
				try {
					trakingPayment.setForm_instanceId(payPlatertransModel.getId());

					trakingPayment.setTransId(payPlatertransModel.getTransId());
					trakingPayment.setTotalamt(payPlatertransModel.getTransAmount().toString());
					trakingPayment.setPpTransId(payPlatertransModel.getPpTransId());
					trakingPayment.setPgTransId(payPlatertransModel.getPgTransId());
					trakingPayment.setStatus(payPlatertransModel.getTransStatus());

					trakingPayment.setCreated_date(new Date());
					trakingPayment.setId(services.getMaximumTouristCenterFormId());
					trakingPayment = services.saveTempTableForMISFormDetails(trakingPayment);
					logger.info("Return From Temp Table :: " + trakingPayment.getId());
					statusmsg = "Tourist Center Form Details Saved  Successfully!!!!";
					statusCode = "200";
					return "{\"status\":\"SUCCESS\",\"ResponseMSG\":\"" + statusmsg + "\"}";
				} catch (Exception e) {
					// TODO: handle exception
					logger.info("Return From Temp Table :: " + trakingPayment.getId());
					statusmsg = "Tourist Center Form Details Not Saved Due to Some Mandatry Parameter is NULL!!!!";
					statusCode = "0001";
					return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
				}

			}
			statusmsg = "Traking Form Details Saved  Success Fully!!!!";
			statusCode = "200";
			return "{\"status\":\"SUCCESS\",\"ResponseMSG\":\"" + statusmsg + "\"}";

		} else {
			statusmsg = "Tourist Center Form Details Not Saved Due to Some Mandatry Parameter is NULL!!!!";
			statusCode = "0001";
			return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
		}

	}

	@RequestMapping(value = "/saveAppFormData/", method = RequestMethod.POST, produces = "application/json")
	public synchronized String saveAppFormData(@RequestBody TempTableMISDataHorticultureAppModel horticultureModel,
			UriComponentsBuilder ucBuilder) {
		String statusmsg = null;
		String statusCode = null;
		MerchantsModel merModel = null;
		PayPlatterTransactionModel payPlatertransModel = null;
		/*
		 * try { merModel = new MerchantsModel(); merModel.setId(38); merModel =
		 * merchantServices.getMerchantDetailsByID(merModel);
		 * 
		 * } catch (Exception e) { e.printStackTrace(); }
		 */
		try {
			// horticultureModel.setId(services.getMaximumHorticultureId());

			horticultureModel = services.saveFormData(horticultureModel);
			if (horticultureModel != null || horticultureModel.getBillNo() != null) {
				statusmsg = "Horticulture App Form Details Saved  Success Fully!!!!";
				statusCode = "200";
				return "{\"status\":\"SUCCESS\",\"ResponseMSG\":\"" + statusmsg + "\"}";
			} else {
				statusmsg = "Horticulture App Form Details Not Saved Due to Server Error!!!!";
				statusCode = "0001";
				return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\",\"currentBillNo\":\""
						+ horticultureModel.getBillNo() + "\"}";
			}
		} catch (Exception e) {
			// TODO: handle exception
			statusmsg = "Horticulture App Form Details Not Saved Due to Server Error!!!!";
			statusCode = "0001";
			return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
		}

	}

	@RequestMapping(value = "/appReceiptCount/", method = RequestMethod.POST, produces = "application/json")
	public String appReceiptCount(@RequestBody TempTableMISDataHorticultureAppModel model,
			UriComponentsBuilder ucBuilder) {
		String statusmsg = null;
		String statusCode = null;
		String receiptCount = null;
		try {

			model = services.getHorticultureAppReceiptCount(model);
			if (model != null) {
				statusmsg = "Horticulture App Form Details!!!!";
				statusCode = "200";
				return "{\"status\":\"SUCCESS\",\"ResponseMSG\":\"" + statusmsg + "\",\"TotalCount\":\""
						+ model.getTotalCount() + "\",\"AdultCount\":\"" + model.getAdultCount()
						+ "\",\"childCount\":\"" + model.getChildCount() + "\"," + "\"cameraCount\":\""
						+ model.getCameraCount() + "\",\"videoCamera\":\"" + model.getVideoCamera()
						+ "\",\"twoWheeler\":\"" + model.getTwoWheeler() + "\",\"fourWheeler\":\""
						+ model.getFourWheeler() + "\"" + ",\"maxWheeler\":\"" + model.getMaxWheeler()
						+ "\",\"cashAmount\":\"" + model.getCashAmount() + "\",\"cardAmount\":\""
						+ model.getCardAmount() + "\",\"heavyShootingCount\":\"" + model.getHeavyShootingCount()
						+ "\",\"walkerCount\":\"" + model.getWalkerCount() + "\",\"rentRecoveryAmount\":\""
						+ model.getRentRecoveryAmount() + "\",\"heavyShootingAmount\":\""
						+ model.getHeavyShootingAmount() + "\",\"rentRecoveryCount\":\"" + model.getRentRecoveryCount()
						+ "\"}";
			} else {
				statusmsg = "Horticulture App Server Error!!!!";
				statusCode = "0001";
				return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			statusmsg = "Horticulture App Server Error!!!!";
			statusCode = "0001";
			return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
		}

	}

	@RequestMapping(value = "/lastReceitNo/", method = RequestMethod.POST, produces = "application/json")
	public String lastReceitNo(@RequestBody TempTableMISDataHorticultureAppModel model,
			UriComponentsBuilder ucBuilder) {
		String statusmsg = null;
		String statusCode = null;
		String receiptCount = null;
		try {

			model = services.getHorticultureAppLastBillNo(model);
			if (model != null) {
				statusmsg = "Horticulture App Form Details!!!!";
				statusCode = "200";
				return "{\"status\":\"SUCCESS\",\"ResponseMSG\":\"" + statusmsg + "\",\"TotalCount\":\""
						+ model.getTotalCount() + "\",\"lastBillNumber\":\"" + model.getBillNo()
						+ "\",\"timeOfBillGenerated\":\"" + model.getTimeOfBillGenerated() + "\"}";
			} else {
				statusmsg = "Horticulture App Server Error!!!!";
				statusCode = "0001";
				return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			statusmsg = "Horticulture App Server Error!!!!";
			statusCode = "0003";
			return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusmsg + "\"}";
		}

	}

}
