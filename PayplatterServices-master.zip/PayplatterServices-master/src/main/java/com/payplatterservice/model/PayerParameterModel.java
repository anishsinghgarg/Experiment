package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "client_payer_upload")
public class PayerParameterModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer id;
	private String PRODUCT_TYPE;
	private String SERVICE_TYPE;
	private String PAYER_UNIQUE_ID;
	// private String PAYMENT_STATUS;
	private String COLLECTION_AGENT_CODE;
	private String COLLECTION_AGENT_NAME;
	private String PAYER_ID;
	private String PAYER_FIRST_NAME;
	private String PAYER_LAST_NAME;
	private String PAYER_STREET_ADD1;
	private String PAYER_STREET_ADD2;
	private String PAYER_ADDRESS_AREA;
	private String PAYER_ADDRESS_CITY;
	private String PAYER_ADDRESS_STATE;
	private String PAYER_ADDRESS_ZIP;
	private String PAYER_ADDRESS_COUNTRY;
	private String PAYER_MOBILE;
	private String PAYER_PHONE;
	private String PAYER_EMAIL;
	private String LAST_PAYMENT_DATE;
	private String PAYMENT_ORIGINAL_DUE_DATE, PAYMENT_NAME;
	private String PAYMENT_ORIGINAL_AMOUNT,PAYMENT_MODE;
	private String LATE_PAYMENT_CHARGES;
	private String PREVIOUS_PAYMENT_OUSTANDING;
	private String OTHER_CHARGES;
	private String FINAL_PAYABLE_AMOUNT;
	private String ADDITIONAL_FIELD1;
	private String ADDITIONAL_FIELD2;
	private String ADDITIONAL_FIELD3;
	private String ADDITIONAL_FIELD4;
	private String ADDITIONAL_FIELD5;
	private String ADDITIONAL_FIELD6;
	private String ADDITIONAL_FIELD7;
	private String ADDITIONAL_FIELD8;
	private String ADDITIONAL_FIELD9;
	private String ADDITIONAL_FIELD10;
	private String INVOICE_NO;
	@Column(unique = true)
	private String SECRET_KEY;
	private String STATUS, CLIENT_CODE;
	@Column(unique = true)
	private String PAYMENT_UNIQUE_REF;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATED_DATE", nullable = false, columnDefinition = "TIMESTAMP default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP")
	private Date CREATED_DATE = new Date();

	private Double PAID_AMOUNT,BASE_AMOUNT;
	private Date PAYMENT_TRANSACTION_DATE;
	private String PAYMENT_TRANSACTION_ID;
	private String CLIENT_ID;
	@Column(columnDefinition = "varchar(255) default 'N'")
	private String SEND_LINK;
	private String APP_NAME;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPRODUCT_TYPE() {
		return PRODUCT_TYPE;
	}
	public void setPRODUCT_TYPE(String pRODUCT_TYPE) {
		PRODUCT_TYPE = pRODUCT_TYPE;
	}
	public String getSERVICE_TYPE() {
		return SERVICE_TYPE;
	}
	public void setSERVICE_TYPE(String sERVICE_TYPE) {
		SERVICE_TYPE = sERVICE_TYPE;
	}
	public String getPAYER_UNIQUE_ID() {
		return PAYER_UNIQUE_ID;
	}
	public void setPAYER_UNIQUE_ID(String pAYER_UNIQUE_ID) {
		PAYER_UNIQUE_ID = pAYER_UNIQUE_ID;
	}
	public String getCOLLECTION_AGENT_CODE() {
		return COLLECTION_AGENT_CODE;
	}
	public void setCOLLECTION_AGENT_CODE(String cOLLECTION_AGENT_CODE) {
		COLLECTION_AGENT_CODE = cOLLECTION_AGENT_CODE;
	}
	public String getCOLLECTION_AGENT_NAME() {
		return COLLECTION_AGENT_NAME;
	}
	public void setCOLLECTION_AGENT_NAME(String cOLLECTION_AGENT_NAME) {
		COLLECTION_AGENT_NAME = cOLLECTION_AGENT_NAME;
	}
	public String getPAYER_ID() {
		return PAYER_ID;
	}
	public void setPAYER_ID(String pAYER_ID) {
		PAYER_ID = pAYER_ID;
	}
	public String getPAYER_FIRST_NAME() {
		return PAYER_FIRST_NAME;
	}
	public void setPAYER_FIRST_NAME(String pAYER_FIRST_NAME) {
		PAYER_FIRST_NAME = pAYER_FIRST_NAME;
	}
	public String getPAYER_LAST_NAME() {
		return PAYER_LAST_NAME;
	}
	public void setPAYER_LAST_NAME(String pAYER_LAST_NAME) {
		PAYER_LAST_NAME = pAYER_LAST_NAME;
	}
	public String getPAYER_STREET_ADD1() {
		return PAYER_STREET_ADD1;
	}
	public void setPAYER_STREET_ADD1(String pAYER_STREET_ADD1) {
		PAYER_STREET_ADD1 = pAYER_STREET_ADD1;
	}
	public String getPAYER_STREET_ADD2() {
		return PAYER_STREET_ADD2;
	}
	public void setPAYER_STREET_ADD2(String pAYER_STREET_ADD2) {
		PAYER_STREET_ADD2 = pAYER_STREET_ADD2;
	}
	public String getPAYER_ADDRESS_AREA() {
		return PAYER_ADDRESS_AREA;
	}
	public void setPAYER_ADDRESS_AREA(String pAYER_ADDRESS_AREA) {
		PAYER_ADDRESS_AREA = pAYER_ADDRESS_AREA;
	}
	public String getPAYER_ADDRESS_CITY() {
		return PAYER_ADDRESS_CITY;
	}
	public void setPAYER_ADDRESS_CITY(String pAYER_ADDRESS_CITY) {
		PAYER_ADDRESS_CITY = pAYER_ADDRESS_CITY;
	}
	public String getPAYER_ADDRESS_STATE() {
		return PAYER_ADDRESS_STATE;
	}
	public void setPAYER_ADDRESS_STATE(String pAYER_ADDRESS_STATE) {
		PAYER_ADDRESS_STATE = pAYER_ADDRESS_STATE;
	}
	public String getPAYER_ADDRESS_ZIP() {
		return PAYER_ADDRESS_ZIP;
	}
	public void setPAYER_ADDRESS_ZIP(String pAYER_ADDRESS_ZIP) {
		PAYER_ADDRESS_ZIP = pAYER_ADDRESS_ZIP;
	}
	public String getPAYER_ADDRESS_COUNTRY() {
		return PAYER_ADDRESS_COUNTRY;
	}
	public void setPAYER_ADDRESS_COUNTRY(String pAYER_ADDRESS_COUNTRY) {
		PAYER_ADDRESS_COUNTRY = pAYER_ADDRESS_COUNTRY;
	}
	public String getPAYER_MOBILE() {
		return PAYER_MOBILE;
	}
	public void setPAYER_MOBILE(String pAYER_MOBILE) {
		PAYER_MOBILE = pAYER_MOBILE;
	}
	public String getPAYER_PHONE() {
		return PAYER_PHONE;
	}
	public void setPAYER_PHONE(String pAYER_PHONE) {
		PAYER_PHONE = pAYER_PHONE;
	}
	public String getPAYER_EMAIL() {
		return PAYER_EMAIL;
	}
	public void setPAYER_EMAIL(String pAYER_EMAIL) {
		PAYER_EMAIL = pAYER_EMAIL;
	}
	public String getLAST_PAYMENT_DATE() {
		return LAST_PAYMENT_DATE;
	}
	public void setLAST_PAYMENT_DATE(String lAST_PAYMENT_DATE) {
		LAST_PAYMENT_DATE = lAST_PAYMENT_DATE;
	}
	public String getPAYMENT_ORIGINAL_DUE_DATE() {
		return PAYMENT_ORIGINAL_DUE_DATE;
	}
	public void setPAYMENT_ORIGINAL_DUE_DATE(String pAYMENT_ORIGINAL_DUE_DATE) {
		PAYMENT_ORIGINAL_DUE_DATE = pAYMENT_ORIGINAL_DUE_DATE;
	}
	public String getPAYMENT_NAME() {
		return PAYMENT_NAME;
	}
	public void setPAYMENT_NAME(String pAYMENT_NAME) {
		PAYMENT_NAME = pAYMENT_NAME;
	}
	public String getPAYMENT_ORIGINAL_AMOUNT() {
		return PAYMENT_ORIGINAL_AMOUNT;
	}
	public void setPAYMENT_ORIGINAL_AMOUNT(String pAYMENT_ORIGINAL_AMOUNT) {
		PAYMENT_ORIGINAL_AMOUNT = pAYMENT_ORIGINAL_AMOUNT;
	}
	public String getPAYMENT_MODE() {
		return PAYMENT_MODE;
	}
	public void setPAYMENT_MODE(String pAYMENT_MODE) {
		PAYMENT_MODE = pAYMENT_MODE;
	}
	public String getLATE_PAYMENT_CHARGES() {
		return LATE_PAYMENT_CHARGES;
	}
	public void setLATE_PAYMENT_CHARGES(String lATE_PAYMENT_CHARGES) {
		LATE_PAYMENT_CHARGES = lATE_PAYMENT_CHARGES;
	}
	public String getPREVIOUS_PAYMENT_OUSTANDING() {
		return PREVIOUS_PAYMENT_OUSTANDING;
	}
	public void setPREVIOUS_PAYMENT_OUSTANDING(String pREVIOUS_PAYMENT_OUSTANDING) {
		PREVIOUS_PAYMENT_OUSTANDING = pREVIOUS_PAYMENT_OUSTANDING;
	}
	public String getOTHER_CHARGES() {
		return OTHER_CHARGES;
	}
	public void setOTHER_CHARGES(String oTHER_CHARGES) {
		OTHER_CHARGES = oTHER_CHARGES;
	}
	public String getFINAL_PAYABLE_AMOUNT() {
		return FINAL_PAYABLE_AMOUNT;
	}
	public void setFINAL_PAYABLE_AMOUNT(String fINAL_PAYABLE_AMOUNT) {
		FINAL_PAYABLE_AMOUNT = fINAL_PAYABLE_AMOUNT;
	}
	public String getADDITIONAL_FIELD1() {
		return ADDITIONAL_FIELD1;
	}
	public void setADDITIONAL_FIELD1(String aDDITIONAL_FIELD1) {
		ADDITIONAL_FIELD1 = aDDITIONAL_FIELD1;
	}
	public String getADDITIONAL_FIELD2() {
		return ADDITIONAL_FIELD2;
	}
	public void setADDITIONAL_FIELD2(String aDDITIONAL_FIELD2) {
		ADDITIONAL_FIELD2 = aDDITIONAL_FIELD2;
	}
	public String getADDITIONAL_FIELD3() {
		return ADDITIONAL_FIELD3;
	}
	public void setADDITIONAL_FIELD3(String aDDITIONAL_FIELD3) {
		ADDITIONAL_FIELD3 = aDDITIONAL_FIELD3;
	}
	public String getADDITIONAL_FIELD4() {
		return ADDITIONAL_FIELD4;
	}
	public void setADDITIONAL_FIELD4(String aDDITIONAL_FIELD4) {
		ADDITIONAL_FIELD4 = aDDITIONAL_FIELD4;
	}
	public String getADDITIONAL_FIELD5() {
		return ADDITIONAL_FIELD5;
	}
	public void setADDITIONAL_FIELD5(String aDDITIONAL_FIELD5) {
		ADDITIONAL_FIELD5 = aDDITIONAL_FIELD5;
	}
	public String getADDITIONAL_FIELD6() {
		return ADDITIONAL_FIELD6;
	}
	public void setADDITIONAL_FIELD6(String aDDITIONAL_FIELD6) {
		ADDITIONAL_FIELD6 = aDDITIONAL_FIELD6;
	}
	public String getADDITIONAL_FIELD7() {
		return ADDITIONAL_FIELD7;
	}
	public void setADDITIONAL_FIELD7(String aDDITIONAL_FIELD7) {
		ADDITIONAL_FIELD7 = aDDITIONAL_FIELD7;
	}
	public String getADDITIONAL_FIELD8() {
		return ADDITIONAL_FIELD8;
	}
	public void setADDITIONAL_FIELD8(String aDDITIONAL_FIELD8) {
		ADDITIONAL_FIELD8 = aDDITIONAL_FIELD8;
	}
	public String getADDITIONAL_FIELD9() {
		return ADDITIONAL_FIELD9;
	}
	public void setADDITIONAL_FIELD9(String aDDITIONAL_FIELD9) {
		ADDITIONAL_FIELD9 = aDDITIONAL_FIELD9;
	}
	public String getADDITIONAL_FIELD10() {
		return ADDITIONAL_FIELD10;
	}
	public void setADDITIONAL_FIELD10(String aDDITIONAL_FIELD10) {
		ADDITIONAL_FIELD10 = aDDITIONAL_FIELD10;
	}
	public String getINVOICE_NO() {
		return INVOICE_NO;
	}
	public void setINVOICE_NO(String iNVOICE_NO) {
		INVOICE_NO = iNVOICE_NO;
	}
	public String getSECRET_KEY() {
		return SECRET_KEY;
	}
	public void setSECRET_KEY(String sECRET_KEY) {
		SECRET_KEY = sECRET_KEY;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	public String getCLIENT_CODE() {
		return CLIENT_CODE;
	}
	public void setCLIENT_CODE(String cLIENT_CODE) {
		CLIENT_CODE = cLIENT_CODE;
	}
	public String getPAYMENT_UNIQUE_REF() {
		return PAYMENT_UNIQUE_REF;
	}
	public void setPAYMENT_UNIQUE_REF(String pAYMENT_UNIQUE_REF) {
		PAYMENT_UNIQUE_REF = pAYMENT_UNIQUE_REF;
	}
	public Date getCREATED_DATE() {
		return CREATED_DATE;
	}
	public void setCREATED_DATE(Date cREATED_DATE) {
		CREATED_DATE = cREATED_DATE;
	}
	public Double getPAID_AMOUNT() {
		return PAID_AMOUNT;
	}
	public void setPAID_AMOUNT(Double pAID_AMOUNT) {
		PAID_AMOUNT = pAID_AMOUNT;
	}
	public Double getBASE_AMOUNT() {
		return BASE_AMOUNT;
	}
	public void setBASE_AMOUNT(Double bASE_AMOUNT) {
		BASE_AMOUNT = bASE_AMOUNT;
	}
	public Date getPAYMENT_TRANSACTION_DATE() {
		return PAYMENT_TRANSACTION_DATE;
	}
	public void setPAYMENT_TRANSACTION_DATE(Date pAYMENT_TRANSACTION_DATE) {
		PAYMENT_TRANSACTION_DATE = pAYMENT_TRANSACTION_DATE;
	}
	public String getPAYMENT_TRANSACTION_ID() {
		return PAYMENT_TRANSACTION_ID;
	}
	public void setPAYMENT_TRANSACTION_ID(String pAYMENT_TRANSACTION_ID) {
		PAYMENT_TRANSACTION_ID = pAYMENT_TRANSACTION_ID;
	}
	public String getCLIENT_ID() {
		return CLIENT_ID;
	}
	public void setCLIENT_ID(String cLIENT_ID) {
		CLIENT_ID = cLIENT_ID;
	}
	public String getSEND_LINK() {
		return SEND_LINK;
	}
	public void setSEND_LINK(String sEND_LINK) {
		SEND_LINK = sEND_LINK;
	}
	public String getAPP_NAME() {
		return APP_NAME;
	}
	public void setAPP_NAME(String aPP_NAME) {
		APP_NAME = aPP_NAME;
	}

	
}
