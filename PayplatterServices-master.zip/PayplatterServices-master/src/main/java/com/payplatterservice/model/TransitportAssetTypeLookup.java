package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "transitport_asset_type_lookup")
public class TransitportAssetTypeLookup implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer asset_type_id;
	private String asset_type_name;
	private String asset_availability_type;
	public Integer getAsset_type_id() {
		return asset_type_id;
	}
	public void setAsset_type_id(Integer asset_type_id) {
		this.asset_type_id = asset_type_id;
	}
	public String getAsset_type_name() {
		return asset_type_name;
	}
	public void setAsset_type_name(String asset_type_name) {
		this.asset_type_name = asset_type_name;
	}
	public String getAsset_availability_type() {
		return asset_availability_type;
	}
	public void setAsset_availability_type(String asset_availability_type) {
		this.asset_availability_type = asset_availability_type;
	}
	
	

}
