package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "payer_merchant_config")
public class PayerMerchantModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer id;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "merchantId_Fk", referencedColumnName = "Id")
	private MerchantsModel merchantsBean;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "payerId_Fk", referencedColumnName = "id")
	@JsonSerialize(using = ToStringSerializer.class)
	private PayerModel payerBean;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public MerchantsModel getMerchantsBean() {
		return merchantsBean;
	}

	public void setMerchantsBean(MerchantsModel merchantsBean) {
		this.merchantsBean = merchantsBean;
	}

	public PayerModel getPayerBean() {
		return payerBean;
	}

	public void setPayerBean(PayerModel payerBean) {
		this.payerBean = payerBean;
	}

}
