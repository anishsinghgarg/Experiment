package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "reports_tb_14")
public class TempTableMISDataHorticultureAppModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer id;
	private Integer form_instanceId;
	private String adultCount, childCount, cameraCount,rentRecoveryAmount,heavyShootingAmount, videoCamera, twoWheeler, fourWheeler, maxWheeler, cashAmount,totalCount,
			cardAmount,timeOfBillGenerated,ppTxnId,  billNo, mId, walkerCount, heavyShootingCount, rentRecoveryCount,additionalParam,contact;
	private Date created_date, modifiedDate;

	private String status,pgTransId;
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getForm_instanceId() {
		return form_instanceId;
	}

	public void setForm_instanceId(Integer form_instanceId) {
		this.form_instanceId = form_instanceId;
	}

	public String getAdultCount() {
		return adultCount;
	}

	public void setAdultCount(String adultCount) {
		this.adultCount = adultCount;
	}

	public String getChildCount() {
		return childCount;
	}

	public void setChildCount(String childCount) {
		this.childCount = childCount;
	}

	public String getCameraCount() {
		return cameraCount;
	}

	public void setCameraCount(String cameraCount) {
		this.cameraCount = cameraCount;
	}

	public String getVideoCamera() {
		return videoCamera;
	}

	public void setVideoCamera(String videoCamera) {
		this.videoCamera = videoCamera;
	}

	public String getTwoWheeler() {
		return twoWheeler;
	}

	public void setTwoWheeler(String twoWheeler) {
		this.twoWheeler = twoWheeler;
	}

	public String getFourWheeler() {
		return fourWheeler;
	}

	public void setFourWheeler(String fourWheeler) {
		this.fourWheeler = fourWheeler;
	}

	public String getMaxWheeler() {
		return maxWheeler;
	}

	public void setMaxWheeler(String maxWheeler) {
		this.maxWheeler = maxWheeler;
	}

	public String getCashAmount() {
		return cashAmount;
	}

	public void setCashAmount(String cashAmount) {
		this.cashAmount = cashAmount;
	}

	public String getCardAmount() {
		return cardAmount;
	}

	public void setCardAmount(String cardAmount) {
		this.cardAmount = cardAmount;
	}

	public String getBillNo() {
		return billNo;
	}

	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}

	public String getmId() {
		return mId;
	}

	public void setmId(String mId) {
		this.mId = mId;
	}

	public String getWalkerCount() {
		return walkerCount;
	}

	public void setWalkerCount(String walkerCount) {
		this.walkerCount = walkerCount;
	}

	public String getHeavyShootingCount() {
		return heavyShootingCount;
	}

	public void setHeavyShootingCount(String heavyShootingCount) {
		this.heavyShootingCount = heavyShootingCount;
	}

	public String getRentRecoveryCount() {
		return rentRecoveryCount;
	}

	public void setRentRecoveryCount(String rentRecoveryCount) {
		this.rentRecoveryCount = rentRecoveryCount;
	}

	public String getTimeOfBillGenerated() {
		return timeOfBillGenerated;
	}

	public void setTimeOfBillGenerated(String timeOfBillGenerated) {
		this.timeOfBillGenerated = timeOfBillGenerated;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getAdditionalParam() {
		return additionalParam;
	}

	public void setAdditionalParam(String additionalParam) {
		this.additionalParam = additionalParam;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	public String getPpTxnId() {
		return ppTxnId;
	}

	public void setPpTxnId(String ppTxnId) {
		this.ppTxnId = ppTxnId;
	}

	public String getRentRecoveryAmount() {
		return rentRecoveryAmount;
	}

	public void setRentRecoveryAmount(String rentRecoveryAmount) {
		this.rentRecoveryAmount = rentRecoveryAmount;
	}

	public String getHeavyShootingAmount() {
		return heavyShootingAmount;
	}

	public void setHeavyShootingAmount(String heavyShootingAmount) {
		this.heavyShootingAmount = heavyShootingAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPgTransId() {
		return pgTransId;
	}

	public void setPgTransId(String pgTransId) {
		this.pgTransId = pgTransId;
	}

}
