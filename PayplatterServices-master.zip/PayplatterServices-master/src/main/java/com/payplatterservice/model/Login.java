package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "login_users")
public class Login implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer loginId;
	@Column(unique = true)
	private String userName;

	private String password;
	private String profile;
	private String firstName;
	private String lastName, contact_no;

	@Column(unique = true)
	private String emailId;

	private Date createdDate,otp_expirydate,modifiedPassDate;
	
	@ManyToOne(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "merchantId_Fk", referencedColumnName = "id")
	private MerchantsModel merchantsBean;
	
	@ManyToOne(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "payerId_Fk", referencedColumnName = "id")
	private PayerModel payerBean;
	@Column(name = "is_first_login", columnDefinition = "VARCHAR(10) default 'N'")
	private String is_first_login;

	public Integer getLoginId() {
		return loginId;
	}

	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public MerchantsModel getMerchantsBean() {
		return merchantsBean;
	}

	public void setMerchantsBean(MerchantsModel merchantsBean) {
		this.merchantsBean = merchantsBean;
	}

	public PayerModel getPayerBean() {
		return payerBean;
	}

	public void setPayerBean(PayerModel payerBean) {
		this.payerBean = payerBean;
	}

	public Date getOtp_expirydate() {
		return otp_expirydate;
	}

	public void setOtp_expirydate(Date otp_expirydate) {
		this.otp_expirydate = otp_expirydate;
	}

	public Date getModifiedPassDate() {
		return modifiedPassDate;
	}

	public void setModifiedPassDate(Date modifiedPassDate) {
		this.modifiedPassDate = modifiedPassDate;
	}

	public String getIs_first_login() {
		return is_first_login;
	}

	public void setIs_first_login(String is_first_login) {
		this.is_first_login = is_first_login;
	}
	
	
	
}
