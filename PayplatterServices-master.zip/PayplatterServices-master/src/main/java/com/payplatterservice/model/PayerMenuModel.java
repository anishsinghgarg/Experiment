package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "payer_menu_config")
public class PayerMenuModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer Id;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "menu_id_fk", referencedColumnName = "menu_id")
	private LookupMenuModel menuBean;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "merchant_id_fk", referencedColumnName = "id")
	private MerchantsModel merchantsBean;


	public Integer getId() {
		return Id;
	}


	public void setId(Integer id) {
		Id = id;
	}


	public LookupMenuModel getMenuBean() {
		return menuBean;
	}


	public void setMenuBean(LookupMenuModel menuBean) {
		this.menuBean = menuBean;
	}


	public MerchantsModel getMerchantsBean() {
		return merchantsBean;
	}


	public void setMerchantsBean(MerchantsModel merchantsBean) {
		this.merchantsBean = merchantsBean;
	}
	


}
