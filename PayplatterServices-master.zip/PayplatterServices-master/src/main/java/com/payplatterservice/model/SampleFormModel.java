package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;


@Entity
@Table(name = "transitport_captured_data_form")
public class SampleFormModel implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer formId;
	@Type(type="text")
	private String formData;
	private Integer formTemplateId;
	@Column(unique = true)
	private String formTransId;
	private String formClientId;
	private Date formDate;
	private Integer formInstId, formApplicantId, formFeeId;
	private Double transAmount, businessAmount, dynamicAmount;
	private String name,contact,email,formFeeName,formStartDate,formEndDate,code, payerID;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer business_context_data_id;
	
	private String form_status;
	@Column(unique = true)
	private String formNumber;
	private String photo_ext,signature_ext;
	
	@Transient
	private String pgId_Fk, tempMID_Fk;
		
	@Lob
	@Column(name = "photograph", columnDefinition = "mediumblob")
	private byte[] photograph;
	
	@Lob
	@Column(name = "signature", columnDefinition = "mediumblob")
	private byte[] signature;
	
	private Date dobDate;
	@Transient
	private String dob;
	public Integer getFormId() {
		return formId;
	}
	public void setFormId(Integer formId) {
		this.formId = formId;
	}
	
	public Integer getFormTemplateId() {
		return formTemplateId;
	}
	public void setFormTemplateId(Integer formTemplateId) {
		this.formTemplateId = formTemplateId;
	}
	public String getFormTransId() {
		return formTransId;
	}
	public void setFormTransId(String formTransId) {
		this.formTransId = formTransId;
	}
	public String getFormClientId() {
		return formClientId;
	}
	public void setFormClientId(String formClientId) {
		this.formClientId = formClientId;
	}
	public Date getFormDate() {
		return formDate;
	}
	public void setFormDate(Date formDate) {
		this.formDate = formDate;
	}
	public Integer getFormInstId() {
		return formInstId;
	}
	public void setFormInstId(Integer formInstId) {
		this.formInstId = formInstId;
	}
	public Integer getFormApplicantId() {
		return formApplicantId;
	}
	public void setFormApplicantId(Integer formApplicantId) {
		this.formApplicantId = formApplicantId;
	}
	public Integer getFormFeeId() {
		return formFeeId;
	}
	public void setFormFeeId(Integer formFeeId) {
		this.formFeeId = formFeeId;
	}
	public Double getTransAmount() {
		return transAmount;
	}
	public void setTransAmount(Double transAmount) {
		this.transAmount = transAmount;
	}
	public Double getBusinessAmount() {
		return businessAmount;
	}
	public void setBusinessAmount(Double businessAmount) {
		this.businessAmount = businessAmount;
	}
	public Double getDynamicAmount() {
		return dynamicAmount;
	}
	public void setDynamicAmount(Double dynamicAmount) {
		this.dynamicAmount = dynamicAmount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFormFeeName() {
		return formFeeName;
	}
	public void setFormFeeName(String formFeeName) {
		this.formFeeName = formFeeName;
	}
	public String getFormStartDate() {
		return formStartDate;
	}
	public void setFormStartDate(String formStartDate) {
		this.formStartDate = formStartDate;
	}
	public String getFormEndDate() {
		return formEndDate;
	}
	public void setFormEndDate(String formEndDate) {
		this.formEndDate = formEndDate;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getPayerID() {
		return payerID;
	}
	public void setPayerID(String payerID) {
		this.payerID = payerID;
	}
	public Integer getBusiness_context_data_id() {
		return business_context_data_id;
	}
	public void setBusiness_context_data_id(Integer business_context_data_id) {
		this.business_context_data_id = business_context_data_id;
	}
	public String getForm_status() {
		return form_status;
	}
	public void setForm_status(String form_status) {
		this.form_status = form_status;
	}
	public String getFormNumber() {
		return formNumber;
	}
	public void setFormNumber(String formNumber) {
		this.formNumber = formNumber;
	}
	public String getPhoto_ext() {
		return photo_ext;
	}
	public void setPhoto_ext(String photo_ext) {
		this.photo_ext = photo_ext;
	}
	public String getSignature_ext() {
		return signature_ext;
	}
	public void setSignature_ext(String signature_ext) {
		this.signature_ext = signature_ext;
	}
	public byte[] getPhotograph() {
		return photograph;
	}
	public void setPhotograph(byte[] photograph) {
		this.photograph = photograph;
	}
	public byte[] getSignature() {
		return signature;
	}
	public void setSignature(byte[] signature) {
		this.signature = signature;
	}
	public Date getDobDate() {
		return dobDate;
	}
	public void setDobDate(Date dobDate) {
		this.dobDate = dobDate;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPgId_Fk() {
		return pgId_Fk;
	}
	public void setPgId_Fk(String pgId_Fk) {
		this.pgId_Fk = pgId_Fk;
	}
	public String getTempMID_Fk() {
		return tempMID_Fk;
	}
	public void setTempMID_Fk(String tempMID_Fk) {
		this.tempMID_Fk = tempMID_Fk;
	}
	public String getFormData() {
		return formData;
	}
	public void setFormData(String formData) {
		this.formData = formData;
	}
	
	
	
}
