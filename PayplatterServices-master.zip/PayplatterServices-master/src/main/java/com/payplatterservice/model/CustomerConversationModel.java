package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "customer_conversation")
public class CustomerConversationModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue()
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer conversation_id;

	@Column(name = "conversation_by", columnDefinition = "VARCHAR(10)")
	private String conversation_by;

	@Type(type = "text")
	private String conversation;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP default CURRENT_TIMESTAMP")
	private Date created_date = new Date();

	@Lob
	@Column(name = "attachment", columnDefinition = "mediumblob")
	private byte[] attachment;
	
	
	private String attachment_path;

	public Integer getConversation_id() {
		return conversation_id;
	}

	public void setConversation_id(Integer conversation_id) {
		this.conversation_id = conversation_id;
	}

	public String getConversation_by() {
		return conversation_by;
	}

	public void setConversation_by(String conversation_by) {
		this.conversation_by = conversation_by;
	}

	public String getConversation() {
		return conversation;
	}

	public void setConversation(String conversation) {
		this.conversation = conversation;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public byte[] getAttachment() {
		return attachment;
	}

	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}

	public String getAttachment_path() {
		return attachment_path;
	}

	public void setAttachment_path(String attachment_path) {
		this.attachment_path = attachment_path;
	}
	
	
	
}
