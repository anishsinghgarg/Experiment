package com.yash.training.aws;


import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;

public class SQSDeleteQueue {
    public static void main(String[] args) {
        AmazonSQS sqsClient = AmazonSQSClientBuilder.standard()
                .withCredentials(new InstanceProfileCredentialsProvider(false))
                .withRegion(Regions.US_EAST_1).build();

        deleteSQSQueue(sqsClient);
    }

    //DELETE SQS QUEUE
    private static void deleteSQSQueue(AmazonSQS sqsClient) {
        String queueUrl = sqsClient.getQueueUrl("Yash-queue").getQueueUrl();
        String fifoQueueUrl = sqsClient.getQueueUrl("Yash-queue.fifo").getQueueUrl();

        sqsClient.deleteQueue(queueUrl);
        sqsClient.deleteQueue(fifoQueueUrl);
    }
}
