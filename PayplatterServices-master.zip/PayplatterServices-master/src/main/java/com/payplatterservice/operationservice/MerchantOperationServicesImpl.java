package com.payplatterservice.operationservice;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.hibernate.Session;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payplatterservice.controller.MerchantActionController;
import com.payplatterservice.model.BCObjectKeyModel;
import com.payplatterservice.model.Login;
import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.ObjectKeyModel;
import com.payplatterservice.model.PayPlatterCentralOutStandingModel;
import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PayerMerchantModel;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PayerParameterModel;
import com.payplatterservice.model.PayplatterCentralInvoicesModel;
import com.payplatterservice.model.PersonnelAppointmentModel;
import com.payplatterservice.model.TransitportPersonnelAvailabilityModel;
import com.payplatterservice.model.TransitportPersonnelModel;
import com.payplatterservice.security.Email;
import com.payplatterservice.security.Encryption;
import com.payplatterservice.security.KeyGenerator;
import com.payplatterservice.service.LoginService;
import com.payplatterservice.service.MerchantService;
import com.payplatterservice.service.MerchantServicesService;
import com.payplatterservice.service.PayerService;
import com.payplatterservice.service.TransactionsService;

@Repository
public class MerchantOperationServicesImpl implements MerchantOperationServices {

	private static final Logger logger = Logger.getLogger(MerchantOperationServicesImpl.class);
	private static final String String = null;
	@Autowired
	TransactionsService txnServices;
	@Autowired
	MerchantServicesService merchantServicesService;

	@Autowired
	PayerService payerServices;

	@Autowired
	MerchantService merchantServices;

	@Autowired
	LoginService loginServices;

	public String createInvoicesForEnrollPayer(ObjectKeyModel objectKey) {

		String statusmsg = null;
		String statusCode = null;
		String respMsg = null;
		logger.info("Create Invoices Type is " + objectKey.getInvoiceType() + " Payment Name :: "
				+ objectKey.getPayment_name());
		PayerParameterModel payerPramModel = new PayerParameterModel();
		try {
			// PayerParameterModel payerPramModel=new PayerParameterModel();
			PayPlatterCentralOutStandingModel invoiceOutStanding = new PayPlatterCentralOutStandingModel();
			PayplatterCentralInvoicesModel centralInvoices = new PayplatterCentralInvoicesModel();

			MerchantsModel merchantModel = new MerchantsModel();
			PayerModel prModel = new PayerModel();
			prModel.setId(objectKey.getPayerID());
			prModel = payerServices.getPayerDetailsById(prModel);
			if (prModel != null) {

				logger.info("Payer Details :: " + prModel.getFirstName() + " " + prModel.getLastName() + " "
						+ prModel.getContact());
				merchantModel.setId(objectKey.getMerchantID());
				merchantModel = merchantServices.getMerchantDetailsByID(merchantModel);
				if (merchantModel != null) {
					// Now setting values in PayerParameter Bean
					payerPramModel.setCLIENT_ID(merchantModel.getId().toString());
					payerPramModel.setCLIENT_CODE(merchantModel.getMcode());
					payerPramModel.setSEND_LINK("Y");
					// payerPramModel.setCREATED_DATE();
					payerPramModel.setSTATUS("NEW");
					payerPramModel.setPAYER_ID(prModel.getId().toString());
					payerPramModel.setPAYER_FIRST_NAME(prModel.getFirstName());
					payerPramModel.setPAYER_LAST_NAME(prModel.getLastName());
					payerPramModel.setPAYER_EMAIL(prModel.getEmailId());
					payerPramModel.setPAYER_MOBILE(prModel.getContact());
					payerPramModel.setPAYER_STREET_ADD1(prModel.getAdd1());
					payerPramModel.setPAYER_STREET_ADD2(prModel.getAdd2());
					payerPramModel.setPAYER_ADDRESS_CITY(prModel.getCity());
					payerPramModel.setPAYER_ADDRESS_STATE(prModel.getState());
					payerPramModel.setPAYER_ADDRESS_COUNTRY(prModel.getContact());
					payerPramModel.setPAYER_ADDRESS_ZIP(prModel.getZip());
					payerPramModel.setSECRET_KEY(secretKey());
					payerPramModel.setPAYMENT_NAME(objectKey.getPayment_name());
					payerPramModel.setSERVICE_TYPE(objectKey.getServiceID().toString());
					payerPramModel.setFINAL_PAYABLE_AMOUNT(objectKey.getBaseAmount());
					payerPramModel = merchantServices.createInvoicesForPayer(payerPramModel);

					centralInvoices = createInvoicesInCentralInvoices(merchantModel, payerPramModel, prModel, objectKey);
					if (centralInvoices != null) {
						/*
						 * if (centralInvoices.getDate_due() != null) { Integer
						 * dueDay = objectKey.getDueDay(); Integer latefee =
						 * objectKey.getDueDay() *
						 * Integer.parseInt(objectKey.getLatefee());
						 * logger.info("Late Fee :: " + latefee); Integer
						 * finalAmt = (int) (latefee +
						 * objectKey.getBaseAmount());
						 * logger.info("Final Amount :: " + finalAmt);
						 * 
						 * }
						 */
						payerPramModel.setINVOICE_NO(centralInvoices.getInvoice_no());
						payerPramModel = merchantServices.updateInvoiceRecord(payerPramModel);
						if (payerPramModel != null) {
							statusmsg = "Invoice created successfully!!!!!!";
							statusCode = "0000";
							respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg
									+ "\",\"InvoiceNumber\":\"" + payerPramModel.getINVOICE_NO()
									+ "\",\"CreatedFor\":\"" + payerPramModel.getPAYER_FIRST_NAME() + " "
									+ payerPramModel.getPAYER_LAST_NAME() + "\",\"CreatedDate\":\""
									+ payerPramModel.getCREATED_DATE() + "\"}";

							return respMsg;

						} else {
							statusmsg = "Invoice not created some value not mattached or some parameter NULL!!!!!!";
							statusCode = "0001";
							respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
							return respMsg;
						}
					} else {
						statusmsg = "Invoice not created some value not mattached or some parameter NULL!!!!!!";
						statusCode = "0001";
						respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
						return respMsg;
					}
				} else {
					statusmsg = "Invoice not created some value not mattached or some parameter NULL!!!!!!";
					statusCode = "0001";
					respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
					return respMsg;
				}

			} else {
				statusmsg = "Invoice not created some value not mattached or some parameter NULL!!!!!!";
				statusCode = "0001";
				respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
				return respMsg;
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			statusCode = "999";
			statusmsg = "Server ERROR. SO, Not able to Process for it!!!!";
			respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
			return respMsg;
		}

	}

	private PayplatterCentralInvoicesModel createInvoicesInCentralInvoices(MerchantsModel model,
			PayerParameterModel payerPramModel, PayerModel prModel, ObjectKeyModel objectKey) {
		PayplatterCentralInvoicesModel centralInvoices = new PayplatterCentralInvoicesModel();
		try {
			// Here we checking Leet fee is Applicable for this Invoices or not
			if (objectKey.getDueDay() != null) {
				logger.info("Late Fee is applicable for this Invoices after :: " + objectKey.getDueDay());
				Date date = new Date();
				Integer dueday = objectKey.getDueDay();
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				cal.add(Calendar.DATE, dueday);
				String convertedDate = dateFormat.format(cal.getTime());
				date = dateFormat.parse(convertedDate);
				logger.info("Late Fee will be applicable from :: " + date);
				centralInvoices.setDate_due(date);
				Integer latefee = objectKey.getDueDay() * Integer.parseInt(objectKey.getLatefee());
				// Integer finalAmt=(int)
				// (latefee+objectKey.getBaseAmount());
				centralInvoices.setAmount_fee_late(Float.parseFloat(objectKey.getLatefee()));
				centralInvoices.setDate_due(date);

			} else {
				logger.info("Late Fee is not applicable for this Invoices::::");
			}
			if (prModel != null) {
				centralInvoices.setPayer_id(prModel.getId());
				centralInvoices.setName_first(prModel.getFirstName());
				centralInvoices.setName_last(prModel.getLastName());
				centralInvoices.setAddress(prModel.getAdd1());
				centralInvoices.setEmail(prModel.getEmailId());
				centralInvoices.setContact(prModel.getContact());

			} else {
				// centralInvoices.setPayer_id(prModel.getId());
				centralInvoices.setName_first(objectKey.getPayerFName());
				centralInvoices.setName_last(objectKey.getPayerLName());
				centralInvoices.setEmail(objectKey.getPayerEmail());
				centralInvoices.setContact(objectKey.getPayerMobNo());

			}
			centralInvoices.setMerchant_id(model.getId());
			centralInvoices.setStatus("open");
			centralInvoices.setTable_name("client_payer_upload");
			centralInvoices.setAmount_base(Float.parseFloat(objectKey.getBaseAmount()));
			centralInvoices.setAmount_total(Float.parseFloat(objectKey.getBaseAmount()));
			centralInvoices.setDate_generated(new Date());
			centralInvoices.setInvoice_no(returnInvoiceNo(model));
			centralInvoices.setInvoice_label(objectKey.getPayment_name());

			centralInvoices = merchantServices.createInvoiceInCentralInvoicesTable(centralInvoices);
			return centralInvoices;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}

	}

	public String secretKey() {
		String key = null;
		KeyGenerator generator = new KeyGenerator();
		try {
			key = generator.anotherLinkKey();
		} catch (Exception e) {
			// TODO: handle exception
			key = generator.anotherLinkKey();
		}
		return key;
	}

	public String returnInvoiceNo(MerchantsModel merchantsBean) {
		String key = null;
		KeyGenerator keygenerator = new KeyGenerator();
		try {
			key = keygenerator.createInvoiceId(merchantsBean);
		} catch (Exception e) {
			// TODO: handle exception
			key = keygenerator.anotherLinkKey();
		}
		return key;
	}

	@Override
	public String validateUserExitOrNot(PayerModel prmodel) {
		String statusmsg = null;
		String statusCode = null;
		String respMsg = null;
		Login login = new Login();
		MerchantsModel merchantModel = new MerchantsModel();
		PayerModel payerModel = new PayerModel();
		PayerMerchantModel payerMerchantModel = new PayerMerchantModel();

		try {
			payerModel = payerServices.isUserExist(prmodel);
			if (payerModel != null) {
				merchantModel.setId(prmodel.getMerchantID());
				merchantModel = merchantServices.getMerchantDetailsByID(merchantModel);
				payerMerchantModel.setMerchantsBean(merchantModel);
				payerMerchantModel.setPayerBean(payerModel);
				payerServices.addPayerMerchantConfig(payerMerchantModel);
				logger.info("This user already Exist in system :::::::::::::");
				logger.info("Details " + payerModel.getEmailId() + " & " + payerModel.getContact());
				statusmsg = "Payer created successfully!!!!!!";
				statusCode = "0000";
				respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg
						+ "\",\"InvoiceNumber\":\"" + payerModel.getFirstName() + " " + payerModel.getLastName()
						+ "\",\"CreatedFor\":\"" + payerModel.getEmailId() + "\",\"CreatedDate\":\""
						+ payerModel.getCreatedDate() + "\"}";

				return respMsg;
			} else {
				payerModel = payerServices.createPayer(prmodel);
				if (payerModel != null) {
					merchantModel.setId(payerModel.getMerchantID());
					merchantModel = merchantServices.getMerchantDetailsByID(merchantModel);
					payerMerchantModel.setMerchantsBean(merchantModel);
					payerMerchantModel.setPayerBean(payerModel);
					payerServices.addPayerMerchantConfig(payerMerchantModel);

					try {
						login = createLogin(payerModel, merchantModel);
					} catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException
							| InvalidAlgorithmParameterException | NoSuchAlgorithmException | NoSuchPaddingException
							| UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();

						statusCode = "999";
						statusmsg = "Server ERROR. SO, Not able to Process for it!!!!";
						respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
						return respMsg;
					}

					if (login != null) {
						statusmsg = "Payer created successfully!!!!!!";
						statusCode = "0000";
						respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg
								+ "\",\"InvoiceNumber\":\"" + payerModel.getFirstName() + " "
								+ payerModel.getLastName() + "\",\"CreatedFor\":\"" + payerModel.getEmailId()
								+ "\",\"CreatedDate\":\"" + payerModel.getCreatedDate() + "\"}";

						return respMsg;

					} else {
						statusCode = "0003";
						statusmsg = "This Email/Contact already exist in this systems. SO, Not able to Process for it!!!!";
						respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
						return respMsg;

					}
				} else {
					statusCode = "999";
					statusmsg = "Not able to Process for it!!!!";
					respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
					return respMsg;

				}

			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			statusCode = "999";
			statusmsg = "Not able to Process for it!!!!";
			respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
			return respMsg;

		}
	}

	private Login createLogin(PayerModel model, MerchantsModel merchantModel) throws InvalidKeyException,
			IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException,
			NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException {
		Login login = new Login();

		login.setFirstName(model.getFirstName());
		login.setLastName(model.getLastName());
		login.setEmailId(model.getEmailId());
		login.setContact_no(model.getContact());
		login.setProfile("PAYER");
		login.setCreatedDate(new Date());
		login.setPayerBean(model);
		login.setIs_first_login("Y");

		String username = KeyGenerator.usenameLogic(model.getEmailId());
		username = "P".concat(username.toUpperCase().concat(model.getId().toString()));
		login.setUserName(username);

		String password = KeyGenerator.generatePswd(6, 8, 1, 2, 0);
		password = Encryption.encrypt("passwordmuskilba", "1234567898765432", password);
		login.setPassword(password);
		login = loginServices.createLogin(login);
		if (login != null) {

			@SuppressWarnings("unused")
			List<MerchantConfigPreferencesModel> list = new ArrayList<MerchantConfigPreferencesModel>();
			HashMap<String, Object> filterMap=new HashMap<String, Object>();
			filterMap.put("merchant_id", merchantModel.getId());
			String key="merchant_id";
			String value=merchantModel.getId().toString();
			list = merchantServices.getAllPreferencesBasedOnMerchant(key ,value);
			for (MerchantConfigPreferencesModel merchantConfigPreferencesModel : list) {
				if (merchantConfigPreferencesModel.getLookupPramMOdel().getParameter_name().equals("PAYER_APP_WELCOME")
						&& merchantConfigPreferencesModel.getParameter_value().equals("Y")) {
					logger.info("Merchant Preferences is : "
							+ merchantConfigPreferencesModel.getLookupPramMOdel().getParameter_name()
							+ " & Possible Value " + merchantConfigPreferencesModel.getParameter_value());

					sendWelcomeMailToPayer(login, model, merchantModel);
				}
			}

		}
		return login;
	}

	private void sendWelcomeMailToPayer(Login login, PayerModel model, MerchantsModel merchantModel) {
		logger.info("Start to send Mail ::::::::::::::::::");

		// TODO Auto-generated method stub
		Email mailSender = new Email();
		String payerUserName = login.getUserName();
		String payerPassword = login.getPassword();
		String PayerLastName = model.getLastName();
		try {
			PayerLastName = (PayerLastName == null) || (PayerLastName.isEmpty()) ? "" : PayerLastName;

		} catch (Exception e2) {
			PayerLastName = "";
		}

		String PayerName = model.getFirstName() + " " + PayerLastName;
		String merchantName = merchantModel.getLegalBusinessName();
		Integer Mid = merchantModel.getId();
		String urlAppLink = "http://156.67.219.28:8100/";
		String Writer_type = "PAYER_WELCOME_EMAIL";

		String encryptedUserPass = null;
		try {
			encryptedUserPass = "&userName=" + payerUserName + "&password="
					+ Encryption.decrypt("passwordmuskilba", "1234567898765432", payerPassword);
		} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | UnsupportedEncodingException
				| InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			encryptedUserPass = Encryption.encrypt("dexpertappencdec", "0000000000000000", encryptedUserPass);
		} catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException
				| InvalidAlgorithmParameterException | NoSuchAlgorithmException | NoSuchPaddingException
				| UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		encryptedUserPass = "?param=" + encryptedUserPass;
		String AppLink = urlAppLink + encryptedUserPass;

		new Thread(() -> {

			try {

				mailSender.sendLogincredtoPayer(model.getEmailId(), "Welcome to PayPlatter", urlAppLink, PayerName,
						payerUserName, Encryption.decrypt("passwordmuskilba", "1234567898765432", payerPassword),
						merchantName, model, merchantModel);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}).start();
	}

	public String createInvoicesForGuestPayer(ObjectKeyModel objectKey) {
		String statusmsg = null;
		String statusCode = null;
		String respMsg = null;

		logger.info("Create Invoices Type is " + objectKey.getInvoiceType());
		PayerParameterModel payerPramModel = new PayerParameterModel();
		PayplatterCentralInvoicesModel centralInvoices = new PayplatterCentralInvoicesModel();
		MerchantsModel merchantModel = new MerchantsModel();
		PayerModel prModel = null;
		try {
			merchantModel.setId(objectKey.getMerchantID());
			merchantModel = merchantServices.getMerchantDetailsByID(merchantModel);
			if (merchantModel != null) {
				payerPramModel.setCLIENT_ID(merchantModel.getId().toString());
				payerPramModel.setCLIENT_CODE(merchantModel.getMcode());
				payerPramModel.setSEND_LINK("Y");
				payerPramModel.setSTATUS("NEW");
				// payerPramModel.setPAYER_ID(prModel.getId().toString());
				payerPramModel.setPAYER_FIRST_NAME(objectKey.getPayerFName());
				payerPramModel.setPAYER_LAST_NAME(objectKey.getPayerLName());
				payerPramModel.setPAYER_EMAIL(objectKey.getPayerEmail());
				payerPramModel.setPAYER_MOBILE(objectKey.getPayerMobNo());
				/*
				 * payerPramModel.setPAYER_STREET_ADD1(prModel.getAdd1());
				 * payerPramModel.setPAYER_STREET_ADD2(prModel.getAdd2());
				 * payerPramModel.setPAYER_ADDRESS_CITY(prModel.getCity());
				 * payerPramModel.setPAYER_ADDRESS_STATE(prModel.getState());
				 * payerPramModel
				 * .setPAYER_ADDRESS_COUNTRY(prModel.getContact());
				 * payerPramModel.setPAYER_ADDRESS_ZIP(prModel.getZip());
				 */
				payerPramModel.setSECRET_KEY(secretKey());
				payerPramModel.setPAYMENT_NAME(objectKey.getPayment_name());
				payerPramModel.setSERVICE_TYPE(objectKey.getServiceID().toString());
				payerPramModel.setFINAL_PAYABLE_AMOUNT(objectKey.getBaseAmount());
				payerPramModel = merchantServices.createInvoicesForPayer(payerPramModel);
				if (payerPramModel != null) {
					centralInvoices = createInvoicesInCentralInvoices(merchantModel, payerPramModel, prModel, objectKey);
					if (centralInvoices != null) {
						/*
						 * if (centralInvoices.getDate_due() != null) { Integer
						 * dueDay = objectKey.getDueDay(); Integer latefee =
						 * objectKey.getDueDay() *
						 * Integer.parseInt(objectKey.getLatefee());
						 * logger.info("Late Fee :: " + latefee); Integer
						 * finalAmt = (int) (latefee +
						 * objectKey.getBaseAmount());
						 * logger.info("Final Amount :: " + finalAmt);
						 * 
						 * }
						 */
						payerPramModel.setINVOICE_NO(centralInvoices.getInvoice_no());
						payerPramModel = merchantServices.updateInvoiceRecord(payerPramModel);
						if (payerPramModel != null) {
							statusmsg = "Invoice created successfully!!!!!!";
							statusCode = "0000";
							respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg
									+ "\",\"InvoiceNumber\":\"" + payerPramModel.getINVOICE_NO()
									+ "\",\"CreatedFor\":\"" + payerPramModel.getPAYER_FIRST_NAME() + " "
									+ payerPramModel.getPAYER_LAST_NAME() + "\",\"CreatedDate\":\""
									+ payerPramModel.getCREATED_DATE() + "\"}";

							return respMsg;

						} else {
							statusmsg = "Invoice not created some value not mattached or some parameter NULL!!!!!!";
							statusCode = "0001";
							respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
							return respMsg;
						}
					} else {
						logger.info("Central Incoices model return NULL :::");
						statusmsg = "Invoice not created some value not mattached or some parameter NULL!!!!!!";
						statusCode = "0001";
						respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
						return respMsg;
					}

				} else {
					logger.info("Invoice Not Created :::::::::");
					statusmsg = "Invoice not created some value not mattached or some parameter NULL!!!!!!";
					statusCode = "0001";
					respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
					return respMsg;
				}

			} else {
				logger.info("Invoice Not Created :::::::::");
				statusmsg = "Invoice not created some value not mattached or some parameter NULL!!!!!!";
				statusCode = "0001";
				respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
				return respMsg;
			}

		} catch (NullPointerException e) {
			e.printStackTrace();
			statusCode = "999";
			statusmsg = "Server ERROR. SO, Not able to Process for it!!!!";
			respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
			return respMsg;
		} catch (Exception e) {
			e.printStackTrace();
			statusCode = "999";
			statusmsg = "Server ERROR. SO, Not able to Process for it!!!!";
			respMsg = "{\"StatusCode\":\"" + statusCode + "\",\"StatusMSG\":\"" + statusmsg + "\"}";
			return respMsg;
		}

	}

	@Override
	public List<PayerModel> getMerchantPayerList(MerchantsModel model) {
		List<PayerMerchantModel> listConfig = new ArrayList<PayerMerchantModel>();
		listConfig = payerServices.getMerchantPayerConfig(model);
		List<PayerModel> listPayer = new ArrayList<PayerModel>();
		PayerModel payerModel = null;
		if (listConfig != null) {
			for (int i = 0; i < listConfig.size(); i++) {
				payerModel = new PayerModel();
				PayerMerchantModel config = listConfig.get(i);
				payerModel = payerServices.getPayerDetailsById(config.getPayerBean());
				listPayer.add(payerModel);
			}
		}

		return listPayer;
	}

	@Override
	public List<Object> getBusinessContextReport(BCObjectKeyModel objectKeyModel) {
		List<Object> object = new ArrayList<Object>();
		if (objectKeyModel != null) {

			if (objectKeyModel.getBusinessContextName().equalsIgnoreCase("AppointmentReport")
					|| objectKeyModel.getBusinessContextName() != null) {
				List<TransitportPersonnelModel> personnelList = new ArrayList<TransitportPersonnelModel>();
				personnelList = merchantServices.getMerchantPersonnelList(objectKeyModel.getMerchantID());
				if (personnelList.size() > 0) {
					List<PersonnelAppointmentModel> appointment = null;
					TransitportPersonnelModel personnel = null;
					ArrayList<Integer> tokenId = new ArrayList<Integer>();
					for (int i = 0; i < personnelList.size(); i++) {
						personnel = personnelList.get(i);
						tokenId.add(personnel.getPersonnel_id());

					}
					appointment = new ArrayList<PersonnelAppointmentModel>();
					HashMap<String, Object> mapFilter = new HashMap<String, Object>();
					mapFilter.put("form_instance_id", tokenId);
					appointment = merchantServicesService.getAppointmentDetails(mapFilter);

					object.add(appointment);

				}

			}
		}
		return object;
	}

}
