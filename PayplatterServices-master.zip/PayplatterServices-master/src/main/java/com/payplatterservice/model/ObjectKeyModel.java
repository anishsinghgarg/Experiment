package com.payplatterservice.model;

import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

public class ObjectKeyModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer merchantID;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer payerID;
	private String invoiceType;
	private String payment_name;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer dueDay;
	private String latefee;
	@JsonSerialize(using = ToStringSerializer.class)
	private String baseAmount;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer serviceID;
	private String finalAmt;
	private String payerFName;
	private String payerLName;
	private String payerEmail;
	private String payerMobNo;

	public Integer getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(Integer merchantID) {
		this.merchantID = merchantID;
	}

	public Integer getPayerID() {
		return payerID;
	}

	public void setPayerID(Integer payerID) {
		this.payerID = payerID;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getPayment_name() {
		return payment_name;
	}

	public void setPayment_name(String payment_name) {
		this.payment_name = payment_name;
	}

	public Integer getDueDay() {
		return dueDay;
	}

	public void setDueDay(Integer dueDay) {
		this.dueDay = dueDay;
	}

	public String getLatefee() {
		return latefee;
	}

	public void setLatefee(String latefee) {
		this.latefee = latefee;
	}

	public String getBaseAmount() {
		return baseAmount;
	}

	public void setBaseAmount(String baseAmount) {
		this.baseAmount = baseAmount;
	}

	public Integer getServiceID() {
		return serviceID;
	}

	public void setServiceID(Integer serviceID) {
		this.serviceID = serviceID;
	}

	public String getFinalAmt() {
		return finalAmt;
	}

	public void setFinalAmt(String finalAmt) {
		this.finalAmt = finalAmt;
	}

	public String getPayerFName() {
		return payerFName;
	}

	public void setPayerFName(String payerFName) {
		this.payerFName = payerFName;
	}

	public String getPayerLName() {
		return payerLName;
	}

	public void setPayerLName(String payerLName) {
		this.payerLName = payerLName;
	}

	public String getPayerEmail() {
		return payerEmail;
	}

	public void setPayerEmail(String payerEmail) {
		this.payerEmail = payerEmail;
	}

	public String getPayerMobNo() {
		return payerMobNo;
	}

	public void setPayerMobNo(String payerMobNo) {
		this.payerMobNo = payerMobNo;
	}

}
