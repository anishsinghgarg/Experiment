package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.Length;


import com.payplatterservice.model.*;

@Entity
@Table(name = "merchandise_master")
public class PayPlatterEcomMerchandiseMasterBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer Id;
	private String name, payplatter_charges_percent, model, brand, packaging;

	@Length(max = 2000)
	private String long_description;

	private Double base_price, shipping_cost, discount;

	@Lob
	@Column(columnDefinition = "mediumblob")
	private byte[] image, image1, image2, image3;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP default CURRENT_TIMESTAMP")
	private Date created_date = new Date();

	@ManyToOne(targetEntity = MerchantsModel.class)
	@JoinColumn(name = "merchant_Id_fk", referencedColumnName = "Id")
	private MerchantsModel merchantsBean;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "m_prod_conf_Id_fk", referencedColumnName = "Id")
	private PayPlatterEcomMerchantProductCategoriesConfBean merchantProductCategoriesConfBean;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPayplatter_charges_percent() {
		return payplatter_charges_percent;
	}

	public void setPayplatter_charges_percent(String payplatter_charges_percent) {
		this.payplatter_charges_percent = payplatter_charges_percent;
	}

	public String getLong_description() {
		return long_description;
	}

	public void setLong_description(String long_description) {
		this.long_description = long_description;
	}

	public Double getBase_price() {
		return base_price;
	}

	public void setBase_price(Double base_price) {
		this.base_price = base_price;
	}

	public Double getShipping_cost() {
		return shipping_cost;
	}

	public void setShipping_cost(Double shipping_cost) {
		this.shipping_cost = shipping_cost;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public byte[] getImage1() {
		return image1;
	}

	public void setImage1(byte[] image1) {
		this.image1 = image1;
	}

	public byte[] getImage2() {
		return image2;
	}

	public void setImage2(byte[] image2) {
		this.image2 = image2;
	}

	public byte[] getImage3() {
		return image3;
	}

	public void setImage3(byte[] image3) {
		this.image3 = image3;
	}

	public MerchantsModel getMerchantsBean() {
		return merchantsBean;
	}

	public void setMerchantsBean(MerchantsModel merchantsBean) {
		this.merchantsBean = merchantsBean;
	}

	public PayPlatterEcomMerchantProductCategoriesConfBean getMerchantProductCategoriesConfBean() {
		return merchantProductCategoriesConfBean;
	}

	public void setMerchantProductCategoriesConfBean(
			PayPlatterEcomMerchantProductCategoriesConfBean merchantProductCategoriesConfBean) {
		this.merchantProductCategoriesConfBean = merchantProductCategoriesConfBean;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}


	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getPackaging() {
		return packaging;
	}

	public void setPackaging(String packaging) {
		this.packaging = packaging;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	

}
