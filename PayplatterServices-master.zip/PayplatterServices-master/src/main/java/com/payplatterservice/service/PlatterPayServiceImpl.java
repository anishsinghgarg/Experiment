package com.payplatterservice.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.jboss.logging.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.config.TxNamespaceHandler;

import com.payplatterservice.configuration.DBConnection;
import com.payplatterservice.model.PlatterPayTransactionBean;

@Repository
public class PlatterPayServiceImpl implements PlatterPayService {

	private static final Logger logger = Logger.getLogger(PlatterPayServiceImpl.class);

	@Override
	public PlatterPayTransactionBean getTransactionDetails(String key, String clientRefNumber) {
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		PlatterPayTransactionBean txnBean = new PlatterPayTransactionBean();
		try {
			String sql = "SELECT * FROM platterpay.transaction_detail where " + key + "='" + clientRefNumber + "'";
			logger.info("SQL Query get Transaction Details  ::" + sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				txnBean.setTxnId(rs.getString("txnId"));
				txnBean.setStatus(rs.getString("status"));
				txnBean.setActAmount(rs.getDouble("actAmount"));
				txnBean.setPayeeAmount(rs.getDouble("payeeAmount"));
				txnBean.setTransDate(rs.getTimestamp("transDate"));
				txnBean.setPayeeFirstName(rs.getString("payeeFirstName"));
				txnBean.setPayeeLstName(rs.getString("payeeLstName"));
				txnBean.setPayeeMob(rs.getString("payeeMob"));
				txnBean.setPGPayMode(rs.getString("PGPayMode"));
				txnBean.setPayeeEmail(rs.getString("payeeEmail"));
				txnBean.setPaymentMode(rs.getString("paymentMode"));
				txnBean.setClientTxnId(rs.getString("clientTxnId"));
				txnBean.setPGTxnId(rs.getString("PGTxnId"));

			}
			return txnBean;
		} catch (Exception e) {

			return null;
		} finally {

			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();

			}
			try {
				rs.close();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}

	}

}
