package com.payplatterservice.controller;

import java.io.Serializable;
import java.text.ParseException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PlatterPayTransactionBean;
import com.payplatterservice.model.TempStatusInquiryModel;
import com.payplatterservice.security.KeyGenerator;
import com.payplatterservice.service.LoginService;
import com.payplatterservice.service.MerchantService;
import com.payplatterservice.service.MerchantServicesService;
import com.payplatterservice.service.TransactionsService;

@RestController
public class TransactionActionController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(TransactionActionController.class);
	@Autowired
	TransactionsService services;

	@Autowired
	MerchantServicesService merServices;

	@Autowired
	MerchantService merchantServices;

	@Autowired
	LoginService loginservices;

	@RequestMapping(value = "/createTransactionPayerWise/", method = RequestMethod.POST, produces = "application/json")
	public synchronized String createTransactionPayerWise(@RequestBody PayPlatterTransactionModel model,
			UriComponentsBuilder ucBuilder) {
		String statusMsg = null;
		String statusCode = null;
		String transid = null;
		PayPlatterTransactionModel txnModel = new PayPlatterTransactionModel();
		synchronized (this) {
			model.setTxnCreateDate(new Date());
			MerchantsModel merModel = null;

			try {

				try {
					merModel = new MerchantsModel();
					merModel.setId(Integer.parseInt(model.getTempMID_Fk()));
					logger.info("Merchant ID : " + model.getTempMID_Fk());
					merModel = merchantServices.getMerchantDetailsByID(merModel);

				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}

				KeyGenerator key = new KeyGenerator();
				transid = key.createsTransxId("PP");

				transid = "AMR" + transid;
				System.out.println("Generated TxnId is =" + transid);
			} catch (ParseException e1) {

				e1.printStackTrace();
			}
			/*Integer inserting_txn_id = services.getMaximumTransactionId();
			Integer result = services.setTransactionId(inserting_txn_id);
			if (inserting_txn_id < 1) {
				statusMsg = "Unable to Create Transaction!!";
				statusCode = "0001";
				return "{\"status\":\"Fail\",\"ResponseMSG\":\"" + statusMsg + "\"}";
			}
			txnModel.setId(inserting_txn_id);
			txnModel = services.getTransactionBeanByID(txnModel);*/
			try {
			
				model.setMerchantsBean(merModel);
				model.setTransId(transid);
				model.setPpTransId(transid);
				model.setId(txnModel.getId());
				txnModel = services.updateTransaction(model);
				if (txnModel != null) {
					statusMsg = "Transaction Created Successfully";
					statusCode = "200";
					logger.info("Response Code : " + statusCode);
					return "{\"status\":\"success\",\"TxnMSG\":\"" + statusMsg + "\",\"StatusCode\":\"" + statusCode
							+ "\",\"TxnCreatedBy\":\"" + txnModel.getName() + "\",\"TxnId\":\"" + txnModel.getTransId() + "\"}";
				} else {
					statusMsg = "Transaction Not Created";
					statusCode = "300";
					logger.info("Response Code : " + statusCode);
					return "{\"status\":\"fail\",\"TxnMSG\":\"" + statusMsg + "\",\"StatusCode\":\"" + statusCode
							+ "\",\"TxnCreatedBy\":\"" + txnModel.getName() + "\",\"TxnId\":\"" + txnModel.getTransId() + "\"}";
				}

			} catch (Exception e) {
				statusMsg = "Transaction Not Created Due To Server Error or Duplicate Transaction ID";
				statusCode = "999";
				logger.info("Response Code : " + statusCode);
				e.printStackTrace();

				return "{\"status\":\"fail\",\"TxnMSG\":\"" + statusMsg + "\",\"StatusCode\":\"" + statusCode
						+ "\",\"TxnCreatedBy\":\"null\",\"TxnId\":\"" + model.getTransId() + "\"}";

			}
		}
	}

	@RequestMapping(value = "/updateTransaction/", method = RequestMethod.POST, produces = "application/json")
	public String updateTransaction(@RequestBody PayPlatterTransactionModel model, UriComponentsBuilder ucBuilder) {
		String statusMsg = null;
		String statusCode = null;
		synchronized (this) {
			try {
				PayPlatterTransactionModel txnModel = new PayPlatterTransactionModel();
				txnModel = services.getTxnDetailsByID(model);
				logger.info("Details :: " + txnModel.getTransId() + " & " + txnModel.getContact());
				if (txnModel != null) {
					txnModel.setTransStatus(model.getTransStatus());
					txnModel.setPgRespCode(model.getPgRespCode());
					txnModel.setTxncloseDate(new Date());
					txnModel.setRemark(model.getRemark());
					txnModel.setTransPaymode(model.getTransPaymode());
					txnModel.setPgTransId(model.getPgTransId());
					model = services.updateTransaction(txnModel);
					if (model != null) {
						statusMsg = "Transaction Updated Successfully";
						statusCode = "200";
					}

				} else {
					statusMsg = "Transaction Not Updated";
					statusCode = "300";
				}

				return "{\"status\":\"success\",\"TxnMSG\":\"" + statusMsg + "\",\"StatusCode\":\"" + statusCode
						+ "\",\"TxnCreatedBy\":\"" + model.getName() + "\",\"emailId\":\"" + model.getEmail()
						+ "\",\"TxnId\":\"" + model.getTransId() + "\"}";

			} catch (Exception e) {
				// TODO: handle exception
				statusMsg = "Transaction Not Updated Due To Server Error or Duplicate Transaction ID";
				statusCode = "999";
				e.printStackTrace();

				return "{\"status\":\"fail\",\"TxnMSG\":\"" + statusMsg + "\",\"StatusCode\":\"" + statusCode
						+ "\",\"TxnCreatedBy\":\"null\",\"emailId\":\"null\",\"TxnId\":\"" + model.getTransId() + "\"}";
			}
		}

	}

	// Status Inquiry Request For JSON Format Response

	@RequestMapping(value = "/statusInquiry/", method = RequestMethod.POST, produces = "application/json")
	public TempStatusInquiryModel statusInquiry(@RequestBody PlatterPayTransactionBean model,
			UriComponentsBuilder ucBuilder) {
		TempStatusInquiryModel tempModel = new TempStatusInquiryModel();
		logger.info("Request Param Value Client Code " + model.getClientName() + " & Client Transaction Id : "
				+ model.getClientTxnId());
		tempModel = services.transactionStatusInquiry(model);

		return tempModel;
	}

	// Status Inquiry Request For XML Format Response

	/*
	 * @RequestMapping(value="/statusInquiry/",method=RequestMethod.POST,
	 * produces="application/xml") public TempStatusInquiryModel
	 * statusInquiry(@RequestBody PlatterPayTransactionBean
	 * model,UriComponentsBuilder ucBuilder){ TempStatusInquiryModel
	 * tempModel=new TempStatusInquiryModel();
	 * tempModel=services.transactionStatusInquiry(model);
	 * 
	 * return tempModel; }
	 */
	
	

}
