/**
 * 
 */
package com.payplatterservice.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.CriteriaBuilder.In;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payplatterservice.model.MerchantServicesDetailsBean;
import com.payplatterservice.model.MerchantServicesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PayPlatterEcomMerchandiseBookingsBean;
import com.payplatterservice.model.PayerModel;
import com.payplatterservice.model.PayplatterBusinessContextServiceMappings;
import com.payplatterservice.model.PayplatterBusinessContexts;
import com.payplatterservice.model.PersonnelAppointmentModel;
import com.payplatterservice.model.SampleFormModel;
import com.payplatterservice.model.SamplePickupModel;
import com.payplatterservice.model.ServicesMasterModel;
import com.payplatterservice.model.TransitportAssetReservationsModel;
import com.payplatterservice.model.VenueAppointmentModel;

/**
 * @author Dexpert
 *
 */
@Repository
public class MerchantServicesServiceImpl implements MerchantServicesService {

	private static final Logger logger = Logger.getLogger(MerchantServicesServiceImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("deprecation")
	public List<PayplatterBusinessContextServiceMappings> getServicesList(MerchantsModel model) {
		Session session = sessionFactory.openSession();
		List<PayplatterBusinessContextServiceMappings> fresult = new ArrayList<PayplatterBusinessContextServiceMappings>();
		List<ServicesMasterModel> result = new ArrayList();
		List<MerchantServicesModel> list = new ArrayList();

		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<PayplatterBusinessContextServiceMappings> query = builder
				.createQuery(PayplatterBusinessContextServiceMappings.class);
		Root<PayplatterBusinessContextServiceMappings> root = query
				.from(PayplatterBusinessContextServiceMappings.class);
		try {
			/*
			 * query.select(root).where(builder.equal(root.get("merchant_id"),
			 * model.getId()));
			 */
			query.select(root)
					.where(builder.and(builder.equal(root.get("merchant_id"), model.getId()),
							builder.equal(root.get("is_visible_app"), "Y")),
							builder.equal(root.get("configuration_status"), "Complete"));
			Query<PayplatterBusinessContextServiceMappings> q = session.createQuery(query);
			fresult = q.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.clear();
			session.close();
		}
		return fresult;
	}

	@Override
	public ServicesMasterModel getServiceMasterByID(Integer service_id) {
		Session session = sessionFactory.openSession();
		try {
			return (ServicesMasterModel) session.get(ServicesMasterModel.class, service_id);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	@Override
	public PayplatterBusinessContexts getBusinessContextByID(Integer context_id) {
		Session session = sessionFactory.openSession();
		try {
			return session.get(PayplatterBusinessContexts.class, context_id);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	@Override
	public List<SampleFormModel> getformCapturedData(PayplatterBusinessContextServiceMappings contextMappingID,
			PayerModel model) {
		List<SampleFormModel> formData = new ArrayList<SampleFormModel>();
		Session session = sessionFactory.openSession();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<SampleFormModel> query = builder.createQuery(SampleFormModel.class);
			Root<SampleFormModel> root = query.from(SampleFormModel.class);
			logger.info("Payer Id :: " + model.getId());

			query.select(root).where(builder.and(builder.equal(root.get("payerID"), model.getId()), builder
					.equal(root.get("business_context_data_id"), Integer.valueOf(contextMappingID.getMapping_id()))));
			Query<SampleFormModel> q = session.createQuery(query);
			formData = q.getResultList();
			return formData;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public List<PersonnelAppointmentModel> getAppointmentDetails(ArrayList<Integer> integerTakenList) {
		Session session = sessionFactory.openSession();
		List<PersonnelAppointmentModel> list = new ArrayList<PersonnelAppointmentModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PersonnelAppointmentModel> query = builder.createQuery(PersonnelAppointmentModel.class);
			Root<PersonnelAppointmentModel> root = query.from(PersonnelAppointmentModel.class);

			In<Integer> inOrgTypeCode = builder.in(root.get("form_instance_id"));
			if (integerTakenList.isEmpty()) {
				inOrgTypeCode.value((Integer) null);
			} else {
				for (Integer orgTypeCode : integerTakenList) {
					inOrgTypeCode.value(orgTypeCode);
				}
			}
			query.select(root).where(inOrgTypeCode);
			Query<PersonnelAppointmentModel> q = session.createQuery(query);
			list = q.getResultList();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public PayplatterBusinessContextServiceMappings getBusinessContextBasedOnMerchant(MerchantsModel merModel) {
		Session session = sessionFactory.openSession();
		PayplatterBusinessContextServiceMappings fresult = new PayplatterBusinessContextServiceMappings();
		List<ServicesMasterModel> result = new ArrayList();
		List<MerchantServicesModel> list = new ArrayList();
		logger.info("Business Context ID :: " + merModel.getContextID() + " & Mapping ID : " + merModel.getMappingID());
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<PayplatterBusinessContextServiceMappings> query = builder
				.createQuery(PayplatterBusinessContextServiceMappings.class);
		Root<PayplatterBusinessContextServiceMappings> root = query
				.from(PayplatterBusinessContextServiceMappings.class);
		try {
			if (merModel.getMappingID().intValue() == 0) {

				query.select(root).where(builder.and(builder.equal(root.get("merchant_id"), merModel.getId()),
						builder.equal(root.get("context_id"), merModel.getContextID())));
			}
			if (merModel.getMappingID().intValue() > 0) {
				Expression<Integer> name = root.get("mapping_id");

				query.select(root).where(builder.and(builder.equal(root.get("merchant_id"), merModel.getId()),
						builder.equal(root.get("context_id"), merModel.getContextID())));
				// ,builder.lt(name, merModel.getMappingID())));

			}
			query.select(root).orderBy(new javax.persistence.criteria.Order[] { builder.asc(root.get("mapping_id")) });

			Query<PayplatterBusinessContextServiceMappings> q = session.createQuery(query).setMaxResults(10);
			fresult = q.getResultList().get(0);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.clear();
			session.close();
		}
		return fresult;
	}

	@Override
	public List<VenueAppointmentModel> getVenuBookingDetails(ArrayList<Integer> integerTakenList) {
		Session session = sessionFactory.openSession();
		List<VenueAppointmentModel> list = new ArrayList<VenueAppointmentModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<VenueAppointmentModel> query = builder.createQuery(VenueAppointmentModel.class);
			Root<VenueAppointmentModel> root = query.from(VenueAppointmentModel.class);

			In<Integer> inOrgTypeCode = builder.in(root.get("form_instance_id"));
			if (integerTakenList.isEmpty()) {
				inOrgTypeCode.value((Integer) null);
			} else {
				for (Integer orgTypeCode : integerTakenList) {
					inOrgTypeCode.value(orgTypeCode);
				}
			}
			query.select(root).where(inOrgTypeCode);
			Query<VenueAppointmentModel> q = session.createQuery(query);
			list = q.getResultList();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public List<SamplePickupModel> getSamplePickupDetails(ArrayList<Integer> integerTakenList) {
		Session session = sessionFactory.openSession();
		List<SamplePickupModel> list = new ArrayList<SamplePickupModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<SamplePickupModel> query = builder.createQuery(SamplePickupModel.class);
			Root<SamplePickupModel> root = query.from(SamplePickupModel.class);

			In<Integer> inOrgTypeCode = builder.in(root.get("form_instance_id"));
			if (integerTakenList.isEmpty()) {
				inOrgTypeCode.value((Integer) null);
			} else {
				for (Integer orgTypeCode : integerTakenList) {
					inOrgTypeCode.value(orgTypeCode);
				}
			}
			query.select(root).where(inOrgTypeCode);
			Query<SamplePickupModel> q = session.createQuery(query);
			list = q.getResultList();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	@Override
	public List<SampleFormModel> getFormDataDetails(PersonnelAppointmentModel model) {
		Session session = sessionFactory.openSession();
		List<SampleFormModel> list = new ArrayList<SampleFormModel>();
		try {

			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<SampleFormModel> query = builder.createQuery(SampleFormModel.class);
			Root<SampleFormModel> root = query.from(SampleFormModel.class);

			query.select(root).where(builder.equal(root.get("formId"), model.getForm_instance_id()));
			Query<SampleFormModel> q = session.createQuery(query);
			list = q.getResultList();

			return list;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return list;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public List<PayPlatterEcomMerchandiseBookingsBean> getOrderReportDetails(
			PayPlatterEcomMerchandiseBookingsBean model) {
		Session session = sessionFactory.openSession();
		List<PayPlatterEcomMerchandiseBookingsBean> list = new ArrayList<PayPlatterEcomMerchandiseBookingsBean>();
		try {

			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayPlatterEcomMerchandiseBookingsBean> query = builder
					.createQuery(PayPlatterEcomMerchandiseBookingsBean.class);
			Root<PayPlatterEcomMerchandiseBookingsBean> root = query.from(PayPlatterEcomMerchandiseBookingsBean.class);

			query.select(root).where(builder.and(builder.equal(root.get("merchant_id"), model.getMerchant_id()),
					builder.equal(root.get("payerBean").get("id"), model.getPayerId())));
			Query<PayPlatterEcomMerchandiseBookingsBean> q = session.createQuery(query);
			list = q.getResultList();

			return list;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return list;
		} finally {
			session.clear();
			session.close();
		}
	}

	public PayPlatterEcomMerchandiseBookingsBean getOrderReportDetailsByOrderId(
			PayPlatterEcomMerchandiseBookingsBean model) {
		Session session = sessionFactory.openSession();
		PayPlatterEcomMerchandiseBookingsBean bean = new PayPlatterEcomMerchandiseBookingsBean();
		try {

			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PayPlatterEcomMerchandiseBookingsBean> query = builder
					.createQuery(PayPlatterEcomMerchandiseBookingsBean.class);
			Root<PayPlatterEcomMerchandiseBookingsBean> root = query.from(PayPlatterEcomMerchandiseBookingsBean.class);

			query.select(root).where(builder.and(builder.equal(root.get("booking_id"), model.getBooking_id())));
			Query<PayPlatterEcomMerchandiseBookingsBean> q = session.createQuery(query);
			bean = (PayPlatterEcomMerchandiseBookingsBean) q.getResultList().get(0);

			return bean;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return bean;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public PayPlatterEcomMerchandiseBookingsBean updateOrderStatus(PayPlatterEcomMerchandiseBookingsBean model) {

		Session session = sessionFactory.openSession();
		PayPlatterEcomMerchandiseBookingsBean bean = new PayPlatterEcomMerchandiseBookingsBean();

		try {
			String status = model.getDelivery_status();
			Integer booking_id = model.getBooking_id();
			String hql = "update merchandise_bookings set delivery_status = :delivery_status where booking_id = :booking_id";
			Query query = session.createQuery(hql);
			query.setString("delivery_status", status);
			query.setInteger("booking_id", booking_id);
			int rowCount = query.executeUpdate();
			logger.info("sql is Update Row Count::" + rowCount);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.clear();
			session.close();
		}
		return null;
	}

	@Override
	public List<PersonnelAppointmentModel> getAppointmentDetails(HashMap<String, Object> mapFilter) {
		Session session = sessionFactory.openSession();
		List<PersonnelAppointmentModel> list = new ArrayList<PersonnelAppointmentModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<PersonnelAppointmentModel> query = builder.createQuery(PersonnelAppointmentModel.class);
			Root<PersonnelAppointmentModel> root = query.from(PersonnelAppointmentModel.class);
			ArrayList<Integer> personnelTakenList = new ArrayList<>();
			if (mapFilter != null && mapFilter.size() > 0) {
				List<String> keys = new ArrayList<String>(mapFilter.keySet());
				for (int i = 0; i < keys.size(); i++) {
					if (keys.get(i).contentEquals("form_instance_id")) {
						personnelTakenList = (ArrayList<Integer>) mapFilter.get(keys.get(i));
						In<Integer> inOrgTypeCode = builder.in(root.get("form_instance_id"));
						if (personnelTakenList.isEmpty()) {
							inOrgTypeCode.value((Integer) null);
						} else {
							for (Integer orgTypeCode : personnelTakenList) {
								inOrgTypeCode.value(orgTypeCode);
							}
							query.select(root).where(inOrgTypeCode);
						}
					}
					if (keys.get(i).contentEquals("personnel_id")) {
						personnelTakenList = (ArrayList<Integer>) mapFilter.get(keys.get(i));
						In<Integer> inOrgTypeCode = builder.in(root.get("personnel_id"));
						if (personnelTakenList.isEmpty()) {
							inOrgTypeCode.value((Integer) null);
						} else {
							for (Integer orgTypeCode : personnelTakenList) {

								inOrgTypeCode.value(orgTypeCode);
							}
							query.select(root).where(inOrgTypeCode);
						}
					}

				}

				Query<PersonnelAppointmentModel> q = session.createQuery(query);
				list = q.getResultList();
				return list;
			} else {
				System.out.println("Map Filter is Null ::::::::");
				return null;
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public List<TransitportAssetReservationsModel> getVenuReservationsDetails(ArrayList<Integer> integerTakenList) {
		Session session = sessionFactory.openSession();
		List<TransitportAssetReservationsModel> list = new ArrayList<TransitportAssetReservationsModel>();
		try {
			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<TransitportAssetReservationsModel> query = builder
					.createQuery(TransitportAssetReservationsModel.class);
			Root<TransitportAssetReservationsModel> root = query.from(TransitportAssetReservationsModel.class);

			In<Integer> inOrgTypeCode = builder.in(root.get("form_instance_id"));
			if (integerTakenList.isEmpty()) {
				inOrgTypeCode.value((Integer) null);
			} else {
				for (Integer orgTypeCode : integerTakenList) {
					inOrgTypeCode.value(orgTypeCode);
				}
			}
			query.select(root).where(inOrgTypeCode);
			Query<TransitportAssetReservationsModel> q = session.createQuery(query);
			list = q.getResultList();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}
}
