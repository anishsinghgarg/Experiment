package com.platterpayservices.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;


public class ClientDetailsMapping implements Serializable{

	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer mappingId;
	private Integer priority;
	private String epUsername, epPass, epMrchntId, feeForward, epUrl;
	private Integer clientId, paymodeId, endpointId, feeId;
	private String epParam1, epParam2, epParam3;
	private String hasSlabs;
	@Transient
	private ClientDetails client;
	@Transient
	private ConfigLookupDataModel paymode;
	@Transient
	private EndpointDataModel endpoint;
	@OneToOne(cascade = CascadeType.ALL)
	private FeeDataModel fee;
	
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FeeDataModel>feeSet;

	public Integer getMappingId() {
		return mappingId;
	}

	public void setMappingId(Integer mappingId) {
		this.mappingId = mappingId;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getEpUsername() {
		return epUsername;
	}

	public void setEpUsername(String epUsername) {
		this.epUsername = epUsername;
	}

	public String getEpPass() {
		return epPass;
	}

	public void setEpPass(String epPass) {
		this.epPass = epPass;
	}

	public String getEpMrchntId() {
		return epMrchntId;
	}

	public void setEpMrchntId(String epMrchntId) {
		this.epMrchntId = epMrchntId;
	}

	public String getFeeForward() {
		return feeForward;
	}

	public void setFeeForward(String feeForward) {
		this.feeForward = feeForward;
	}

	public String getEpUrl() {
		return epUrl;
	}

	public void setEpUrl(String epUrl) {
		this.epUrl = epUrl;
	}

	public Integer getClientId() {
		return clientId;
	}

	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}

	public Integer getPaymodeId() {
		return paymodeId;
	}

	public void setPaymodeId(Integer paymodeId) {
		this.paymodeId = paymodeId;
	}

	public Integer getEndpointId() {
		return endpointId;
	}

	public void setEndpointId(Integer endpointId) {
		this.endpointId = endpointId;
	}

	public Integer getFeeId() {
		return feeId;
	}

	public void setFeeId(Integer feeId) {
		this.feeId = feeId;
	}

	public String getEpParam1() {
		return epParam1;
	}

	public void setEpParam1(String epParam1) {
		this.epParam1 = epParam1;
	}

	public String getEpParam2() {
		return epParam2;
	}

	public void setEpParam2(String epParam2) {
		this.epParam2 = epParam2;
	}

	public String getEpParam3() {
		return epParam3;
	}

	public void setEpParam3(String epParam3) {
		this.epParam3 = epParam3;
	}

	public String getHasSlabs() {
		return hasSlabs;
	}

	public void setHasSlabs(String hasSlabs) {
		this.hasSlabs = hasSlabs;
	}

	public ClientDetails getClient() {
		return client;
	}

	public void setClient(ClientDetails client) {
		this.client = client;
	}

	public ConfigLookupDataModel getPaymode() {
		return paymode;
	}

	public void setPaymode(ConfigLookupDataModel paymode) {
		this.paymode = paymode;
	}

	public EndpointDataModel getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(EndpointDataModel endpoint) {
		this.endpoint = endpoint;
	}

	public FeeDataModel getFee() {
		return fee;
	}

	public void setFee(FeeDataModel fee) {
		this.fee = fee;
	}

	public Set<FeeDataModel> getFeeSet() {
		return feeSet;
	}

	public void setFeeSet(Set<FeeDataModel> feeSet) {
		this.feeSet = feeSet;
	}
	
	

}
