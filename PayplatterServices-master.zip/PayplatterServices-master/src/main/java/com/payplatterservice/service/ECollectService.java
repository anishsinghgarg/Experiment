package com.payplatterservice.service;

import com.payplatterservice.model.PlatterPayTransactionBean;

public interface ECollectService {

	PlatterPayTransactionBean txnRequestValidation(String tokenNO, String txnAmount, String mobNo);

	String updateTransaction(String challanNO, String payStatus, String payStatus2, String payode, String txnCompliteDate,
			String bENE_BANK_NAME, String bENE_ACCOUNT_NO, String bENE_ACCOUNT_NO2, String bENE_FULL_NAME,
			String bENE_ACCOUNT_IFSC, String rMTR_FULL_NAME, String rMTR_ACCOUNT_NUMBER, String rMTR_BANK_NAME,
			String rMTR_ACCOUNT_IFSC, String vIRTUAL_ACCOUNT_NO);

}
