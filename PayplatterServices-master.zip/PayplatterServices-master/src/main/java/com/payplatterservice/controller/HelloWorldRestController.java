package com.payplatterservice.controller;
 
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.List;
 


import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.payplatterservice.model.Login;
import com.payplatterservice.model.User;
import com.payplatterservice.security.Encryption;
import com.payplatterservice.service.LoginService;
import com.payplatterservice.service.UserService;
 
@RestController
public class HelloWorldRestController implements Serializable{
 
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Autowired
    UserService userService;  //Service which will do all data retrieval/manipulation work
 
    @Autowired
    LoginService loginservices;
    
    
    /*
    @RequestMapping(value="/validateLogin/{userName}/{password}",method=RequestMethod.GET)
    public String validateLogin(@PathVariable String userName,@PathVariable String password){
    	Login login=new Login();
    	login.setUserName(userName);login.setPassword(password);
    	login=loginservices.validateLigin(login);
    	
    	System.out.println("Login Validation Profile :" +login.getProfile());
    	return null;
    }*/
     
    //-------------------Retrieve All Users--------------------------------------------------------
     
   /* @RequestMapping(value = "/validateLogin/", method = RequestMethod.POST)
	public String validateLogin(@RequestBody Login loginV, UriComponentsBuilder ucBuilder) throws InvalidKeyException,
			NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		Login login = new Login();
		Encryption encCode = new Encryption();
		String userName = null;
		String password = null;
		String statusmsg = null;
		String statusCode = null;
		System.out.println("UserName is ="+loginV.getUserName());
		if (loginV.getPassword().equals("Need to Decrypt with " + loginV.getUserName().trim())) {
			String param = null;
			param = encCode.decrypt("dexpertappencdec", "0000000000000000", loginV.getUserName()+"=");
			Map<String, String> querypair = new LinkedHashMap<String, String>();
			try {
				querypair = encCode.splitQuery(param);
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}

			loginV.setUserName(querypair.get("userName"));
			loginV.setPassword(querypair.get("password"));

			System.out.println(" New User Name is =" + loginV.getUserName());
			System.out.println(" New Pass is =" + loginV.getPassword());
			password = encCode.encrypt("passwordmuskilba", "1234567898765432", loginV.getPassword());
			loginV.setPassword(password);
		} else {
			password = encCode.encrypt("passwordmuskilba", "1234567898765432", loginV.getPassword());
			loginV.setPassword(password);
		}
		try {
			if (loginV != null) {
				login = loginservices.validateLigin(loginV);
				System.out.println("Return Profile :: " + login.getProfile());
				statusmsg = "Login Successfully Done!!!!!!";
				statusCode = "0000";
				String respMsg = "{\"status\":\"success\",\"LoginMSG\":\"" + statusmsg + "\",\"UserProfile\":\""
						+ login.getProfile() + "\",\"StatusCode\":\"" + statusCode + "\",\"UserName\":\""
						+ login.getFirstName() + " " + login.getLastName() + "\",\"emailId\":\"" + login.getEmailId()
						+ "\"}";
				System.out.println("Response msg ::" + respMsg);
				return "{\"status\":\"success\",\"LoginMSG\":\"" + statusmsg + "\",\"UserProfile\":\""
						+ login.getProfile() + "\",\"StatusCode\":\"" + statusCode + "\",\"UserName\":\""
						+ login.getFirstName() + " " + login.getLastName() + "\",\"emailId\":\"" + login.getEmailId()
						+ "\"}";
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
    
    */
    
    @RequestMapping(value = "/user/", method = RequestMethod.GET)
    public ResponseEntity<List<User>> listAllUsers() {
        List<User> users = userService.findAllUsers();
        if(users.isEmpty()){
            return new ResponseEntity<List<User>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<User>>(users, HttpStatus.OK);
    }
 
 
    //-------------------Retrieve Single User--------------------------------------------------------
     
    @RequestMapping(value = "/user/{id}", method = RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<User> getUser(@PathVariable("id") long id) {
        System.out.println("Fetching User with id " + id);
        User user = userService.findById(id);
        if (user == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<User>(user, HttpStatus.OK);
    }
 
     
     
    //-------------------Create a User--------------------------------------------------------
     
    @RequestMapping(value = "/users/", method = RequestMethod.POST)
    public ResponseEntity<User> createUser(@RequestBody User user, UriComponentsBuilder ucBuilder) {
        System.out.println("Creating User " + user.getName());
        System.out.println(user.getPassword());
        System.out.println(user.getUsername());
        user.setName(user.getUsername());
        /*if (userService.isUserExist(user)) {
            System.out.println("A User with name " + user.getName() + " already exist");
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);
        }
 
        userService.saveUser(user);*/
 
        return new ResponseEntity<User>(user, HttpStatus.CREATED);
    }
 
     
    //------------------- Update a User --------------------------------------------------------
     
    @RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
    public ResponseEntity<User> updateUser(@PathVariable("id") long id, @RequestBody User user) {
        System.out.println("Updating User " + id);
         
        User currentUser = userService.findById(id);
         
        if (currentUser==null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }
 
        currentUser.setName(user.getName());
        currentUser.setAge(user.getAge());
        currentUser.setSalary(user.getSalary());
         
        userService.updateUser(currentUser);
        return new ResponseEntity<User>(currentUser, HttpStatus.OK);
    }
 
    //------------------- Delete a User --------------------------------------------------------
     
    @RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<User> deleteUser(@PathVariable("id") long id) {
        System.out.println("Fetching & Deleting User with id " + id);
 
        User user = userService.findById(id);
        if (user == null) {
            System.out.println("Unable to delete. User with id " + id + " not found");
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }
 
        userService.deleteUserById(id);
        return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
    }
 
     
    //------------------- Delete All Users --------------------------------------------------------
     
    @RequestMapping(value = "/user/", method = RequestMethod.DELETE)
    public ResponseEntity<User> deleteAllUsers() {
        System.out.println("Deleting All Users");
 
        userService.deleteAllUsers();
        return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
    }
 
}