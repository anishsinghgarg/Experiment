package com.payplatterservice.service;

import com.platterpayservices.model.ClientDetails;
import com.platterpayservices.model.ClientDetailsMapping;
import com.platterpayservices.model.EndpointDataModel;
import com.platterpayservices.model.FeeDataModel;

public interface PlatterPayOnBoardingServices {

	ClientDetails onBoardClient(ClientDetails clientDetails);

	ClientDetailsMapping saveClientMappingDetails(ClientDetails clientMapping,EndpointDataModel ep);
	
	FeeDataModel getFeeDetails(String key,String value);

	FeeDataModel setDefaultFeeConfigurations(FeeDataModel fee);

	Integer getTableMaxPrimID(String tableName,String column);
	boolean isValidKeyIV(String key, String value);

	EndpointDataModel getEPDetails(String key, String value);

	int saveIntoMappling(FeeDataModel feeDetails, ClientDetailsMapping clientMapping);

}
