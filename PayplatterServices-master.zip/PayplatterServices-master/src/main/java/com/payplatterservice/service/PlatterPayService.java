package com.payplatterservice.service;

import com.payplatterservice.model.PlatterPayTransactionBean;

public interface PlatterPayService {

	PlatterPayTransactionBean getTransactionDetails(String key, String clientRefNumber);

}
