package com.payplatterservice.service;

import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.PaymentProcessorModel;

public interface CouplingProjectService {

	boolean isMerchantExist(MerchantsModel model);

	PaymentProcessorModel paymentProcessorDetails(Integer pgId_Fk);

	MerchantsModel saveMerchantInfoDetails(MerchantsModel model);

	boolean isMerchantExistInMerchantMaster(MerchantsModel model);

	Long getTotalRowCount();

}
