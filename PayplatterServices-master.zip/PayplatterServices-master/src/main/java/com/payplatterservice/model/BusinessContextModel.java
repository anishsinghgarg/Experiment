package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Set;

public class BusinessContextModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private PersonnelAppointmentModel personnelAppointment;
	
	private SamplePickupModel sampleModel;

	public PersonnelAppointmentModel getPersonnelAppointment() {
		return personnelAppointment;
	}

	public void setPersonnelAppointment(PersonnelAppointmentModel personnelAppointment) {
		this.personnelAppointment = personnelAppointment;
	}

	public SamplePickupModel getSampleModel() {
		return sampleModel;
	}

	public void setSampleModel(SamplePickupModel sampleModel) {
		this.sampleModel = sampleModel;
	}


	
	
	
}
