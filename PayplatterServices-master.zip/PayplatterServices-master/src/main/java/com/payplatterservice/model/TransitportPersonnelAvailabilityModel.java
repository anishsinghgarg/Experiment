package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;


@Entity
@Table(name = "transitport_personnel_availability")
public class TransitportPersonnelAvailabilityModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer availability_id;
	private String scope_date;
	private String scope_time_start, scope_time_end;
	private String availabilty;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer personnel_id,available_appointments;
	private Date date_available;
	private Float start_time,end_time;

	@Column(name = "status", updatable = false, nullable = false, columnDefinition = "VARCHAR (20) default 'OPEN'")
	private String status;
	
	@Transient
	private Integer replication_factor;

	public Integer getAvailability_id() {
		return availability_id;
	}

	public void setAvailability_id(Integer availability_id) {
		this.availability_id = availability_id;
	}

	public String getScope_date() {
		return scope_date;
	}

	public void setScope_date(String scope_date) {
		this.scope_date = scope_date;
	}

	public String getScope_time_start() {
		return scope_time_start;
	}

	public void setScope_time_start(String scope_time_start) {
		this.scope_time_start = scope_time_start;
	}

	public String getScope_time_end() {
		return scope_time_end;
	}

	public void setScope_time_end(String scope_time_end) {
		this.scope_time_end = scope_time_end;
	}

	public String getAvailabilty() {
		return availabilty;
	}

	public void setAvailabilty(String availabilty) {
		this.availabilty = availabilty;
	}

	public Integer getPersonnel_id() {
		return personnel_id;
	}

	public void setPersonnel_id(Integer personnel_id) {
		this.personnel_id = personnel_id;
	}

	public Integer getAvailable_appointments() {
		return available_appointments;
	}

	public void setAvailable_appointments(Integer available_appointments) {
		this.available_appointments = available_appointments;
	}

	public Date getDate_available() {
		return date_available;
	}

	public void setDate_available(Date date_available) {
		this.date_available = date_available;
	}

	public Float getStart_time() {
		return start_time;
	}

	public void setStart_time(Float start_time) {
		this.start_time = start_time;
	}

	public Float getEnd_time() {
		return end_time;
	}

	public void setEnd_time(Float end_time) {
		this.end_time = end_time;
	}

	public Integer getReplication_factor() {
		return replication_factor;
	}

	public void setReplication_factor(Integer replication_factor) {
		this.replication_factor = replication_factor;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
