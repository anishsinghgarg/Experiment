package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "inventory_serial_number")
public class PayPlatterEcomInventorySerialNumberBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer inventory_serial_numbers;
	private String status;
	private String serial_number;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP default CURRENT_TIMESTAMP")
	private Date created_date = new Date();

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "inverntory_id_fk", referencedColumnName = "inventory_id")
	private PayPlatterEcomInventoryBean inventoryBean;

	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "booking_id_fk", referencedColumnName = "booking_id")
	private MerchandiseBookingsBean merchandiseBookingsBean;*/
	
	private Integer booking_id;
	
	@Transient
	private PayPlatterEcomMerchandiseBookingsBean booking_data;

	public Integer getInventory_serial_numbers() {
		return inventory_serial_numbers;
	}

	public void setInventory_serial_numbers(Integer inventory_serial_numbers) {
		this.inventory_serial_numbers = inventory_serial_numbers;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSerial_number() {
		return serial_number;
	}

	public void setSerial_number(String serial_number) {
		this.serial_number = serial_number;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public PayPlatterEcomInventoryBean getInventoryBean() {
		return inventoryBean;
	}

	public void setInventoryBean(PayPlatterEcomInventoryBean inventoryBean) {
		this.inventoryBean = inventoryBean;
	}

	public Integer getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(Integer booking_id) {
		this.booking_id = booking_id;
	}

	public PayPlatterEcomMerchandiseBookingsBean getBooking_data() {
		return booking_data;
	}

	public void setBooking_data(PayPlatterEcomMerchandiseBookingsBean booking_data) {
		this.booking_data = booking_data;
	}



}
