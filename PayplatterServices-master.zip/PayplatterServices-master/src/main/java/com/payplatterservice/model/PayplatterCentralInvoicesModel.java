package com.payplatterservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "payplatter_central_invoices")
public class PayplatterCentralInvoicesModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer invoice_id;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer outstanding_id, record_id;
	private String invoice_label, table_name;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer payer_id;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer merchant_id;
	private Date date_generated, date_due, date_due_late, date_closed, date_paid;
	@JsonSerialize(using = ToStringSerializer.class)
	private Float amount_total, amount_paid, amount_base, amount_fee_convenience, amount_fee_late, amount_tax;
	private String name_first, name_last, name_middle, address, contact, email, comment1, comment2, status, txnId,
			merchant_name;

	@Column(unique = true)
	private String invoice_no;

	public Integer getInvoice_id() {
		return invoice_id;
	}

	public void setInvoice_id(Integer invoice_id) {
		this.invoice_id = invoice_id;
	}

	public Integer getOutstanding_id() {
		return outstanding_id;
	}

	public void setOutstanding_id(Integer outstanding_id) {
		this.outstanding_id = outstanding_id;
	}

	public Integer getRecord_id() {
		return record_id;
	}

	public void setRecord_id(Integer record_id) {
		this.record_id = record_id;
	}

	public String getInvoice_label() {
		return invoice_label;
	}

	public void setInvoice_label(String invoice_label) {
		this.invoice_label = invoice_label;
	}

	public String getTable_name() {
		return table_name;
	}

	public void setTable_name(String table_name) {
		this.table_name = table_name;
	}

	public Integer getPayer_id() {
		return payer_id;
	}

	public void setPayer_id(Integer payer_id) {
		this.payer_id = payer_id;
	}

	public Integer getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}

	public Date getDate_generated() {
		return date_generated;
	}

	public void setDate_generated(Date date_generated) {
		this.date_generated = date_generated;
	}

	public Date getDate_due() {
		return date_due;
	}

	public void setDate_due(Date date_due) {
		this.date_due = date_due;
	}

	public Date getDate_due_late() {
		return date_due_late;
	}

	public void setDate_due_late(Date date_due_late) {
		this.date_due_late = date_due_late;
	}

	public Date getDate_closed() {
		return date_closed;
	}

	public void setDate_closed(Date date_closed) {
		this.date_closed = date_closed;
	}

	public Date getDate_paid() {
		return date_paid;
	}

	public void setDate_paid(Date date_paid) {
		this.date_paid = date_paid;
	}

	public Float getAmount_total() {
		return amount_total;
	}

	public void setAmount_total(Float amount_total) {
		this.amount_total = amount_total;
	}

	public Float getAmount_paid() {
		return amount_paid;
	}

	public void setAmount_paid(Float amount_paid) {
		this.amount_paid = amount_paid;
	}

	public Float getAmount_base() {
		return amount_base;
	}

	public void setAmount_base(Float amount_base) {
		this.amount_base = amount_base;
	}

	public Float getAmount_fee_convenience() {
		return amount_fee_convenience;
	}

	public void setAmount_fee_convenience(Float amount_fee_convenience) {
		this.amount_fee_convenience = amount_fee_convenience;
	}

	public Float getAmount_fee_late() {
		return amount_fee_late;
	}

	public void setAmount_fee_late(Float amount_fee_late) {
		this.amount_fee_late = amount_fee_late;
	}

	public Float getAmount_tax() {
		return amount_tax;
	}

	public void setAmount_tax(Float amount_tax) {
		this.amount_tax = amount_tax;
	}

	public String getName_first() {
		return name_first;
	}

	public void setName_first(String name_first) {
		this.name_first = name_first;
	}

	public String getName_last() {
		return name_last;
	}

	public void setName_last(String name_last) {
		this.name_last = name_last;
	}

	public String getName_middle() {
		return name_middle;
	}

	public void setName_middle(String name_middle) {
		this.name_middle = name_middle;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getComment1() {
		return comment1;
	}

	public void setComment1(String comment1) {
		this.comment1 = comment1;
	}

	public String getComment2() {
		return comment2;
	}

	public void setComment2(String comment2) {
		this.comment2 = comment2;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getMerchant_name() {
		return merchant_name;
	}

	public void setMerchant_name(String merchant_name) {
		this.merchant_name = merchant_name;
	}

	public String getInvoice_no() {
		return invoice_no;
	}

	public void setInvoice_no(String invoice_no) {
		this.invoice_no = invoice_no;
	}

}
