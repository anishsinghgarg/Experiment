package com.payplatterservice.service;

import java.util.List;

import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PlatterPayTransactionBean;
import com.payplatterservice.model.TempStatusInquiryModel;

public interface TransactionsService {

	List<PayPlatterTransactionModel> getPayerTransModel(PayPlatterTransactionModel trans);

	PayPlatterTransactionModel getPayerTransModels(PayPlatterTransactionModel txnDetails);

	PayPlatterTransactionModel createTransactionOfPayer(PayPlatterTransactionModel model);

	PayPlatterTransactionModel updateTransaction(PayPlatterTransactionModel model);

	PayPlatterTransactionModel getTxnDetailsByID(PayPlatterTransactionModel model);

	List<String> getOldTxnList(String code);

	TempStatusInquiryModel transactionStatusInquiry(PlatterPayTransactionBean model);

	int getMaximumTransactionId();

	Integer setTransactionId(Integer id);

	PayPlatterTransactionModel getTransactionBeanByID(PayPlatterTransactionModel model);

}
