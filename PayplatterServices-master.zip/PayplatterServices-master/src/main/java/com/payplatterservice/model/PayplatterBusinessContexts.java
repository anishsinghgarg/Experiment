package com.payplatterservice.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.annotations.Proxy;
import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "payplatter_business_context_lookups")
public class PayplatterBusinessContexts implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer context_id;
	private String name, description;
	private String requires_form, page_to_include, context_bean_table_name, bypass;
	@JsonSerialize(using = ToStringSerializer.class)
	private Integer payment_flow_id;
	private String bean_object;
	private String bc_category;

	/*@ManyToMany(targetEntity = LookupMenuModel.class, cascade = { CascadeType.ALL }, fetch=FetchType.EAGER)
	@JoinTable(name = "payplatter_business_context_lookups_lookup_menus", joinColumns = { @JoinColumn(name = "payplatter_business_context_lookups_context_id") }, inverseJoinColumns = { @JoinColumn(name = "owned_menu_menu_id") })
	*/
	@Transient
	private PayplatterBusinessContextServiceMappings servicesMappingData;
	
	@Transient
	private TransitportPersonnelModel personnelModel;
	
	
	

	public Integer getContext_id() {
		return context_id;
	}

	public void setContext_id(Integer context_id) {
		this.context_id = context_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRequires_form() {
		return requires_form;
	}

	public void setRequires_form(String requires_form) {
		this.requires_form = requires_form;
	}

	public String getPage_to_include() {
		return page_to_include;
	}

	public void setPage_to_include(String page_to_include) {
		this.page_to_include = page_to_include;
	}

	public String getContext_bean_table_name() {
		return context_bean_table_name;
	}

	public void setContext_bean_table_name(String context_bean_table_name) {
		this.context_bean_table_name = context_bean_table_name;
	}

	public String getBypass() {
		return bypass;
	}

	public void setBypass(String bypass) {
		this.bypass = bypass;
	}

	public Integer getPayment_flow_id() {
		return payment_flow_id;
	}

	public void setPayment_flow_id(Integer payment_flow_id) {
		this.payment_flow_id = payment_flow_id;
	}

	public String getBean_object() {
		return bean_object;
	}

	public void setBean_object(String bean_object) {
		this.bean_object = bean_object;
	}

	public PayplatterBusinessContextServiceMappings getServicesMappingData() {
		return servicesMappingData;
	}

	public void setServicesMappingData(PayplatterBusinessContextServiceMappings servicesMappingData) {
		this.servicesMappingData = servicesMappingData;
	}

	public TransitportPersonnelModel getPersonnelModel() {
		return personnelModel;
	}

	public void setPersonnelModel(TransitportPersonnelModel personnelModel) {
		this.personnelModel = personnelModel;
	}

	public String getBc_category() {
		return bc_category;
	}

	public void setBc_category(String bc_category) {
		this.bc_category = bc_category;
	}

	
}
