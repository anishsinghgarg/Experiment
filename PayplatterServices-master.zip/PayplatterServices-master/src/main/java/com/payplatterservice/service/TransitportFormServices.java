package com.payplatterservice.service;

import com.payplatterservice.model.SampleFormModel;
import com.payplatterservice.model.TempTableMISDataEcoTouristCenterModel;
import com.payplatterservice.model.TempTableMISDataHorticultureAppModel;
import com.payplatterservice.model.TempTableModelTrakingPayment;

public interface TransitportFormServices {

	SampleFormModel saveFormDetails(SampleFormModel model);

	TempTableModelTrakingPayment saveTempTableFormDetails(TempTableModelTrakingPayment model);

	TempTableMISDataEcoTouristCenterModel saveTempTableForMISFormDetails(TempTableMISDataEcoTouristCenterModel trakingPayment);

	SampleFormModel updateFormDetails(SampleFormModel model);

	int getMaximumFormId();

	int getMaximumTrekkingFormId();

	int getMaximumTouristCenterFormId();

	TempTableMISDataHorticultureAppModel saveFormData(TempTableMISDataHorticultureAppModel model);

	Integer getMaximumHorticultureId();

	TempTableMISDataHorticultureAppModel getHorticultureAppReceiptCount(TempTableMISDataHorticultureAppModel model);

	TempTableMISDataHorticultureAppModel getHorticultureAppLastBillNo(TempTableMISDataHorticultureAppModel model);

}
