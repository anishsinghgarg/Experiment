package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;

@Entity
@Table(name = "payplatter_business_context_to_service_mappings")
public class PayplatterBusinessContextServiceMappings implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer mapping_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer service_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer context_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer merchant_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer form_id;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer payment_flow_id;

	private String status,configuration_status,is_visible_web,is_visible_app;
	@Transient
	private ServicesMasterModel servicedata;
	@Transient
	private MerchantsModel merchantdata;
	@Transient
	private PayplatterBusinessContexts contextdata;
	
	
	@Transient
	private String imgPath;
	
	public Integer getMapping_id() {
		return mapping_id;
	}
	public void setMapping_id(Integer mapping_id) {
		this.mapping_id = mapping_id;
	}
	public Integer getService_id() {
		return service_id;
	}
	public void setService_id(Integer service_id) {
		this.service_id = service_id;
	}
	public Integer getContext_id() {
		return context_id;
	}
	public void setContext_id(Integer context_id) {
		this.context_id = context_id;
	}
	public Integer getMerchant_id() {
		return merchant_id;
	}
	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}
	public Integer getForm_id() {
		return form_id;
	}
	public void setForm_id(Integer form_id) {
		this.form_id = form_id;
	}
	public Integer getPayment_flow_id() {
		return payment_flow_id;
	}
	public void setPayment_flow_id(Integer payment_flow_id) {
		this.payment_flow_id = payment_flow_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getConfiguration_status() {
		return configuration_status;
	}
	public void setConfiguration_status(String configuration_status) {
		this.configuration_status = configuration_status;
	}
	public ServicesMasterModel getServicedata() {
		return servicedata;
	}
	public void setServicedata(ServicesMasterModel servicedata) {
		this.servicedata = servicedata;
	}
	public MerchantsModel getMerchantdata() {
		return merchantdata;
	}
	public void setMerchantdata(MerchantsModel merchantdata) {
		this.merchantdata = merchantdata;
	}
	public PayplatterBusinessContexts getContextdata() {
		return contextdata;
	}
	public void setContextdata(PayplatterBusinessContexts contextdata) {
		this.contextdata = contextdata;
	}
	public String getImgPath() {
		return imgPath;
	}
	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
	public String getIs_visible_web() {
		return is_visible_web;
	}
	public void setIs_visible_web(String is_visible_web) {
		this.is_visible_web = is_visible_web;
	}
	public String getIs_visible_app() {
		return is_visible_app;
	}
	public void setIs_visible_app(String is_visible_app) {
		this.is_visible_app = is_visible_app;
	}

}
