package com.payplatterservice.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payplatterservice.configuration.DBConnection;
import com.payplatterservice.model.PayPlatterTransactionModel;
import com.payplatterservice.model.PayerMerchantModel;
import com.payplatterservice.model.PlatterPayTransactionBean;
import com.payplatterservice.model.TempStatusInquiryModel;

@Repository
public class TransactionsServiceImpl implements TransactionsService {

	private static final Logger logger = Logger.getLogger(TransactionsServiceImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<PayPlatterTransactionModel> getPayerTransModel(PayPlatterTransactionModel trans) {
		Session session = sessionFactory.openSession();
		List<PayPlatterTransactionModel> list = new ArrayList<PayPlatterTransactionModel>();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<PayPlatterTransactionModel> query = builder.createQuery(PayPlatterTransactionModel.class);
		Root<PayPlatterTransactionModel> root = query.from(PayPlatterTransactionModel.class);
		try {
			Query<PayPlatterTransactionModel> q = null;

			Expression<Integer> name = root.get("id");

			if (trans.getId().intValue() == 0) {

				if (trans.getFilterflag().equalsIgnoreCase("False")) {
					logger.info("Filter Flag is False :::::::::::");
					if (trans.getEmail() != null) {
						query.select(root).where(builder.and(builder.equal(root.get("email"), trans.getEmail()),
								builder.equal(root.get("payer_type"), "CONSUMERS")));
						query.select(root)
								.orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });
						q = session.createQuery(query).setMaxResults(5);
					}
					if (trans.getTransId() != null) {
						query.select(root).where(builder.and(builder.equal(root.get("transId"), trans.getTransId()),
								builder.equal(root.get("payer_type"), "CONSUMERS")));
						query.select(root)
								.orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });
						q = session.createQuery(query).setMaxResults(5);
					}
					if (trans.getContact() != null) {
						query.select(root).where(builder.equal(root.get("contact"), trans.getContact()));
						query.select(root).orderBy(
								new javax.persistence.criteria.Order[] { builder.desc(root.get("txnCreateDate")) });
						q = session.createQuery(query).setMaxResults(5);
					}
					if (trans.getAddress() != null) {
						query.select(root).where(builder.equal(root.get("address"), trans.getAddress()));
						query.select(root).orderBy(
								new javax.persistence.criteria.Order[] { builder.desc(root.get("txnCreateDate")) });
						q = session.createQuery(query).setMaxResults(5);
					}
					if (trans.getPgTransId() != null) {
						query.select(root).where(builder.and(builder.equal(root.get("pgTransId"), trans.getPgTransId()),
								builder.equal(root.get("transStatus"), "success")));
						q = session.createQuery(query).setMaxResults(1);
					}

				}

				else if (trans.getFilterflag().equalsIgnoreCase("True")) {

					if (trans.getEmail() != null) {
						query.select(root)
								.where(builder.and(builder.equal(root.get("email"), trans.getEmail()),
										builder.equal(root.get("payer_type"), "CONSUMERS")),
										builder.equal(root.get("transStatus"), trans.getTransStatus()),
										builder.equal(root.get("transPaymode"), trans.getTransPaymode()),
										builder.lt(name, trans.getId()));

						query.select(root)
								.orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });
						q = session.createQuery(query).setMaxResults(5);
					}
					if (trans.getTransId() != null) {

						query.select(root)
								.where(builder.and(builder.equal(root.get("transId"), trans.getTransId()),
										builder.equal(root.get("payer_type"), "CONSUMERS")),
										builder.equal(root.get("transStatus"), trans.getTransStatus()),
										builder.equal(root.get("transPaymode"), trans.getTransPaymode()),
										builder.lt(name, trans.getId()));
						query.select(root).where(builder.and(builder.equal(root.get("transId"), trans.getTransId()),
								builder.equal(root.get("payer_type"), "CONSUMERS")));

						query.select(root)
								.orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });
						q = session.createQuery(query).setMaxResults(5);
					}
				}

			}

			if (trans.getId().intValue() > 0) {
				logger.info("Filter Flag is True ::::::::::: Index >0");

				if (trans.getFilterflag().equalsIgnoreCase("False")) {
					logger.info("Filter Flag is False ::::::::::: Index >0");
					if (trans.getEmail() != null) {
						query.select(root)
								.where(builder.and(builder.equal(root.get("email"), trans.getEmail()),
										builder.equal(root.get("payer_type"), "CONSUMERS")),
										builder.lt(name, trans.getId()));
						query.select(root)
								.orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });
						q = session.createQuery(query).setMaxResults(5);
					}
					if (trans.getTransId() != null) {
						query.select(root)
								.where(builder.and(builder.equal(root.get("transId"), trans.getTransId()),
										builder.equal(root.get("payer_type"), "CONSUMERS")),
										builder.lt(name, trans.getId()));
						query.select(root)
								.orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });
						q = session.createQuery(query).setMaxResults(5);
					}
				}

				else if (trans.getFilterflag().equalsIgnoreCase("True")) {

					if (trans.getEmail() != null) {

						query.select(root)
								.where(builder.and(builder.equal(root.get("email"), trans.getEmail()),
										builder.equal(root.get("payer_type"), "CONSUMERS")),
										builder.equal(root.get("transStatus"), trans.getTransStatus()),
										builder.equal(root.get("transPaymode"), trans.getTransPaymode()),
										builder.lt(name, trans.getId()));
						query.select(root)
								.orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });
						q = session.createQuery(query).setMaxResults(5);
					}
					if (trans.getTransId() != null) {

						query.select(root)
								.where(builder.and(builder.equal(root.get("transId"), trans.getTransId()),
										builder.equal(root.get("payer_type"), "CONSUMERS")),
										builder.equal(root.get("transStatus"), trans.getTransStatus()),
										builder.equal(root.get("transPaymode"), trans.getTransPaymode()),
										builder.lt(name, trans.getId()));
						query.select(root)
								.orderBy(new javax.persistence.criteria.Order[] { builder.desc(root.get("id")) });
						q = session.createQuery(query).setMaxResults(5);

					}
				}

			}

			return q.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			session.close();
		}

	}

	@Override
	public PayPlatterTransactionModel getPayerTransModels(PayPlatterTransactionModel txnDetails) {
		Session session = sessionFactory.openSession();
		PayPlatterTransactionModel result = new PayPlatterTransactionModel();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<PayPlatterTransactionModel> query = builder.createQuery(PayPlatterTransactionModel.class);
		Root<PayPlatterTransactionModel> root = query.from(PayPlatterTransactionModel.class);
		try {
			query.select(root).where(builder.equal(root.get("id"), txnDetails.getId()));
			Query<PayPlatterTransactionModel> q = session.createQuery(query);
			if (q.getResultList().size() > 0) {
				result = q.getResultList().get(0);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.clear();
			session.close();
		}

		return result;
	}

	@Override
	public PayPlatterTransactionModel createTransactionOfPayer(PayPlatterTransactionModel model) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(model);
			session.getTransaction().commit();

			return model;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		} finally {

			session.close();
		}

	}

	@Override
	public PayPlatterTransactionModel updateTransaction(PayPlatterTransactionModel model) {
		Session session = sessionFactory.openSession();
		try {
			session.beginTransaction();
			session.saveOrUpdate(model);
			session.getTransaction().commit();

			return model;
		} catch (Exception e) {
			// TODO: handle exception

			e.printStackTrace();
			return null;
		} finally {
			session.clear();
			session.close();
		}
	}

	@Override
	public PayPlatterTransactionModel getTxnDetailsByID(PayPlatterTransactionModel model) {
		Session session = sessionFactory.openSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<PayPlatterTransactionModel> query = builder.createQuery(PayPlatterTransactionModel.class);
		Root<PayPlatterTransactionModel> root = query.from(PayPlatterTransactionModel.class);

		try {
			query.select(root).where(builder.equal(root.get("transId"), model.getTransId()));
			Query<PayPlatterTransactionModel> q = session.createQuery(query);

			model = q.getResultList().get(0);
			logger.info("Model Details ::: " + model.getTransId());
			return model;

		} catch (Exception e) {
			// TODO: handle exception
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}

	public List<String> getOldTxnList(String txnId) {
		Session session = sessionFactory.openSession();
		List<String> list = new ArrayList<String>();
		try {
			Criteria criteria = session.createCriteria(PayPlatterTransactionModel.class);
			// criteria.setProjection(Projections.property("transId"));
			criteria.add(Restrictions.eq("transId", txnId));
			list = criteria.list();

		} catch (Exception e) {
			/* log.error("Exception in getting List"); */
			e.printStackTrace();
		} finally {
			session.close();
		}
		return list;
	}

	@Override
	public TempStatusInquiryModel transactionStatusInquiry(PlatterPayTransactionBean model) {
		TempStatusInquiryModel tempModel = new TempStatusInquiryModel();
		DBConnection conn = new DBConnection();
		Connection con = null;
		Statement stmt = null;

		con = conn.getConnection();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			String sql = "SELECT * FROM transaction_detail where clientName='" + model.getClientName()
					+ "' and clientTxnId ='" + model.getClientTxnId() + "'";
			logger.info("Status Inquiry Sql Query : " + sql);
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				tempModel.setTxnId(rs.getString("txnId"));
				tempModel.setStatus(rs.getString("status"));
				tempModel.setPayeeAmount(rs.getDouble("payeeAmount"));
				tempModel.setPaymentMode(rs.getString("paymentMode"));
				tempModel.setTransCompleteDate(rs.getString("transCompleteDate"));
				tempModel.setClientTxnId(rs.getString("clientTxnId"));
				tempModel.setPayPlatterRespCode(rs.getString("platterpay_response_code"));

			} else {
				logger.info("Client Code " + model.getClientName() + " & CLient Trans ID :" + model.getClientTxnId()
						+ "For this Client Details No Record Found!!");
				tempModel.setStatus("TRANSACTION NOT FOUND");
				tempModel.setPayPlatterRespCode("404");
			}
		} catch (Exception e) {
			// TODO: handle exception
			tempModel.setStatus("SERVER ERROR");
			tempModel.setPayPlatterRespCode("999");
			logger.info("In Catch Block Getting Exception :" + e.getMessage());

		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return tempModel;
	}

	@Override
	public int getMaximumTransactionId() {
		Session session = sessionFactory.openSession();
		int id = 0;
		try {
			id = (Integer) session.createQuery("select max(id) from PayPlatterTransactionModel").uniqueResult() + 1;
			System.out.println("Last ID of Transaction Table is =" + (id - 1));
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}

		System.out.println("Need to Insert With ID=" + id);

		return id;
	}

	@Override
	public Integer setTransactionId(Integer id) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		int result = -1;
		try {
			String sql = null;
			sql = "INSERT INTO transactions_details (id) VALUES(" + id + ")";
			System.out.println("transactions_details Query is ::" + sql);
			SQLQuery sqlQuery = session.createSQLQuery(sql);
			result = sqlQuery.executeUpdate();
			tx.commit();
			System.out.println("Response Query is ::" + result);

		} catch (RuntimeException se) {
			se.getMessage();
		} finally {
			session.close();
		}
		return result;
	}

	@Override
	public PayPlatterTransactionModel getTransactionBeanByID(PayPlatterTransactionModel model) {
		Session session = sessionFactory.openSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<PayPlatterTransactionModel> query = builder.createQuery(PayPlatterTransactionModel.class);
		Root<PayPlatterTransactionModel> root = query.from(PayPlatterTransactionModel.class);

		try {
			query.select(root).where(builder.equal(root.get("id"), model.getId()));
			Query<PayPlatterTransactionModel> q = session.createQuery(query);

			model = q.getResultList().get(0);
			logger.info("Model Details ::: " + model.getTransId());
			return model;

		} catch (Exception e) {
			// TODO: handle exception
			return null;
		} finally {
			session.clear();
			session.close();
		}

	}
}
