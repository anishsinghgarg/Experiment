package com.payplatterservice.operationservice;

import com.platterpayservices.model.ClientDetails;

public interface PlatterPayOnboarding {

	ClientDetails generateClientDetails(ClientDetails clientDetails);

}
