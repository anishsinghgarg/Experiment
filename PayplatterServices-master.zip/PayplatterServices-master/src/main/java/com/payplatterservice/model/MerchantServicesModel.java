package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "master_services")
public class MerchantServicesModel implements Serializable{

	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer Id;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "servicesId_Fk", referencedColumnName = "Id")
	private ServicesMasterModel servicesModel;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "mid_Fk", referencedColumnName = "id")
	private MerchantsModel merchantModel;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public ServicesMasterModel getServicesModel() {
		return servicesModel;
	}

	public void setServicesModel(ServicesMasterModel servicesModel) {
		this.servicesModel = servicesModel;
	}

	public MerchantsModel getMerchantModel() {
		return merchantModel;
	}

	public void setMerchantModel(MerchantsModel merchantModel) {
		this.merchantModel = merchantModel;
	}
	
	
	
}
