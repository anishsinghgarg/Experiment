package com.payplatterservice.operationservice;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpSession;

import org.jboss.logging.Logger;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.ParseException;
import org.springframework.stereotype.Repository;

import com.payplatterservice.model.MerchantConfigPreferencesModel;
import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.model.SearchKeyModel;
import com.payplatterservice.model.TransitportAssetReservationsModel;
import com.payplatterservice.model.TransitportAssetAvailabilityModel;
import com.payplatterservice.model.TransitportAssetsModel;
import com.payplatterservice.service.MerchantService;
import com.payplatterservice.service.PayerService;

@Repository
public class PayerOperationServicesImpl implements PayerOperationServices {

	private static final Logger logger = Logger.getLogger(PayerOperationServicesImpl.class);
	@Autowired
	MerchantService merchantServices;
	@Autowired
	PayerService payerServices;
	@Autowired
	private HttpSession session;

	@SuppressWarnings("unchecked")
	@Override
	public List<MerchantsModel> getMerchantSearchAvability(SearchKeyModel searchkey) {
		List<Object> listObjectPer = null;
		List<MerchantsModel> merchantList = null;
		ArrayList<Integer> IntegerTakenList = new ArrayList<>();
		HashMap<String, Object> filter = new HashMap<>();
		MerchantsModel merchantModel = new MerchantsModel();
		List<MerchantConfigPreferencesModel> list = new ArrayList<MerchantConfigPreferencesModel>();
		if (searchkey != null) {

			String key = "";
			Integer IndID = null;
			String value = "";

			// merchantModel.setCity(searchkey.getCity());
			// merchantModel.setState(searchkey.getState());
			if (searchkey.getSearchKey().equals("health")) {

				IndID = 14;

			} else if (searchkey.getSearchKey().equals("housing")) {

				IndID = 22;

			} else if (searchkey.getSearchKey().equals("education")) {
				IndID = 2;
			} else if (searchkey.getSearchKey().equals("devotion")) {

				IndID = 39;
			} else {
				IndID = 0;
			}
			merchantList = new ArrayList<MerchantsModel>();
			try {
				merchantList = merchantServices.getMerchantListBasedOnSearch("ind_id", IndID);

				logger.info("Return Size : " + merchantList.size());
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

		}
		return merchantList;
	}

	@Override
	public String cancelAssetReservation(TransitportAssetsModel model) {
		TransitportAssetReservationsModel reservations = new TransitportAssetReservationsModel();
		reservations = payerServices.getAssetReservationDetailsByID(model);
		String statusMsg = "";
		String statusCode = "";
		String status = "";
		String returnStatus = "";
		Boolean update_flg = false;
		try {
			if (reservations != null) {
				for (Iterator iterator = reservations.getMulti_availability_data().iterator(); iterator.hasNext();) {
					TransitportAssetAvailabilityModel tempAvailability = (TransitportAssetAvailabilityModel) iterator
							.next();
					if (tempAvailability.getAvailability_id() == model.getAvailability_id()) {
						if (tempAvailability.getDate_available().after(new Date())) {
							logger.info("CancelDateBasedReservation Dates:" + tempAvailability.getDate_available()
									+ ":::" + new Date());
							tempAvailability
									.setAvailable_appointments(tempAvailability.getAvailable_appointments() - 1);
							tempAvailability.setStatus("OPEN");
							tempAvailability = payerServices.updateAssetAvailability(tempAvailability);
							update_flg = true;
						}
					} else {
						logger.info("Availability ID not matched !!!!!!!!!!!!!!!");
					}
				}
				if (update_flg && reservations.getMulti_availability_data().size() == 1) {
					reservations.setStatus("CANCEL");
					reservations = payerServices.updateRescheduleReservation(reservations);
					statusMsg = "Reservation Reschedule Success!!!!!";
					status = "SUCCESS";
					statusCode = "0000";
					returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode
							+ "\",\"Status Msg\":\"" + statusMsg + "\"}";

				} else {
					logger.info("Flg false or Reservation Multi-Date size is "
							+ reservations.getMulti_availability_data().size());
					statusMsg = "For the given Request Attribute Reservation not available!!!";
					status = "Fail";
					statusCode = "333";
					returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode
							+ "\",\"Status Msg\":\"" + statusMsg + "\"}";

				}
			} else {
				logger.info("Reservation Not Found :::");
				statusMsg = "For the given Request Attribute Reservation doesn't Exist!!!";
				status = "Fail";
				statusCode = "111";
				returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode + "\",\"Status Msg\":\""
						+ statusMsg + "\"}";

			}
		} catch (Exception e) {
			// TODO: handle exception
			statusMsg = "For the given Request Attribute Reservation doesn't Exist!!!";
			status = "Fail";
			statusCode = "999";
			logger.info("Exception While Cancelling Reservation " + e.getMessage());
			returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode + "\",\"Status Msg\":\""
					+ statusMsg + "\"}";
		}
		return returnStatus;
	}

	@Override
	public List<TransitportAssetsModel> assetReservationReschedule(TransitportAssetReservationsModel model) {
		List<TransitportAssetsModel> assetList = new ArrayList<TransitportAssetsModel>();
		String date_from_str;
		String date_to_str;
		Integer no_of_units = 0;
		boolean continuity = false;
		Integer available_assets = 0;
		List<TransitportAssetAvailabilityModel> listAvailability = new ArrayList<TransitportAssetAvailabilityModel>();
		TransitportAssetReservationsModel tempReservation = new TransitportAssetReservationsModel();
		tempReservation = payerServices.getAssetReservationDetailsByID(model);
		// model=payerServices.getAssetReservationDetailsByID(model);
		logger.info("Reservation :  " + model.getReservation_id());
		if (tempReservation != null) {
			Map<String, Integer> filter_map = new HashMap<String, Integer>();
			filter_map.put("category_id", tempReservation.getAsset_category_id());
			logger.info("Category ID : " + tempReservation.getAsset_category_id());
			filter_map.put("asset_type_id", tempReservation.getAsset_type_id());
			logger.info("Asset Type ID : " + tempReservation.getAsset_type_id());
			assetList = payerServices.getAssetDetailsBasedAssetCategory("type_and_category", filter_map);
			if (assetList.size() == 0) {
				logger.info("No Assets that satisfy the criteria found. Cannot continue with Reservation");
				String errorMsg = "No Assets that satisfy the criteria found.<br/> Cannot continue with Reservation";

				return null;
			}
			Date from_date = new Date();
			Date to_date = new Date();
			logger.info("Date From : " + model.getDateFrom());
			logger.info("Date To : " + model.getDateTo());
			date_from_str = model.getDateFrom();

			date_to_str = model.getDateTo();

			date_from_str = date_from_str.concat(" 00:00:00");
			date_to_str = date_to_str.concat(" 23:59:59");

			date_from_str = date_from_str.concat(" 00:00:00");
			date_to_str = date_to_str.concat(" 23:59:59");

			int no_of_days = differanceDate(to_date, from_date) + 1;

			for (TransitportAssetsModel assetsIt : assetList) {
				logger.info("Asset Availability Size :: " + assetsIt.getAvailability().size());
				Date _date = from_date;
				logger.info("Checking availabilty for " + _date.toString());
				List<TransitportAssetAvailabilityModel> _availabilities = new ArrayList<TransitportAssetAvailabilityModel>();
				List<TransitportAssetAvailabilityModel> sort_availabilities = new ArrayList<TransitportAssetAvailabilityModel>();
				if (assetsIt.getAvailability().size() > 0) {
					for (Iterator iterator = assetsIt.getAvailability().iterator(); iterator.hasNext();) {
						TransitportAssetAvailabilityModel tempAvailModel = (TransitportAssetAvailabilityModel) iterator
								.next();
						sort_availabilities.add(tempAvailModel);
					}
					Collections.sort(sort_availabilities, new Comparator<TransitportAssetAvailabilityModel>() {
						@Override
						public int compare(TransitportAssetAvailabilityModel o1, TransitportAssetAvailabilityModel o2) {
							return o1.getDate_available().compareTo(o2.getDate_available());
						}
					});
				}

				for (TransitportAssetAvailabilityModel obj : sort_availabilities) {
					Date db_scope_date = null;
					try {
						db_scope_date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
								.parse(obj.getScope_date().concat(" 00:00:00"));
					} catch (java.text.ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					logger.info("db_scope_date " + db_scope_date + " & Date " + _date);
					if ((db_scope_date.after(_date) || db_scope_date.equals(_date))
							&& (db_scope_date.equals(to_date) || db_scope_date.before(to_date))
							&& obj.getStatus().contentEquals("open")) {
						logger.info("Date Available=" + db_scope_date);
						_availabilities.add(obj);

					} else {
						logger.info("Esc Date =" + db_scope_date);
					}
				}

				logger.info("Asset ID::::" + assetsIt.getAsset_id() + ":No of Days:::" + no_of_days + "::::::: "
						+ _availabilities.size());
				if (no_of_days > _availabilities.size()) {
					logger.info("continuity = false->" + _date.toString());
					continuity = false;
				} else {
					logger.info("continuity = true->" + _date.toString());
					listAvailability.addAll(_availabilities);
					continuity = true;

				}
				if (continuity) {
					assetList.add(assetsIt);
					available_assets += 1;
					logger.info("Asset Availability :: " + available_assets);
				} else {
				}
				if (available_assets >= no_of_units) {
					session.setAttribute("reSecheduledReservationAvailabilityList", listAvailability);
					session.setAttribute("reSecheduledReservationDateFrom", from_date);
					session.setAttribute("reSecheduledReservationDateTo", to_date);
					session.setAttribute("reSecheduledReservationModel", model);
				}

			}
		}
		return assetList;
	}

	private int differanceDate(Date to_date, Date from_date) throws ParseException {
		logger.info(" To Date : " + to_date + " & From Date : " + from_date);
		return Days.daysBetween(new LocalDate(from_date.getTime()), new LocalDate(to_date.getTime())).getDays();
	}

	@Override
	public String saveRescheduleReservation(TransitportAssetsModel model) {
		float amount = 0;
		String statusMsg = "";
		String statusCode = "";
		String status = "";
		String returnStatus = "";
		ArrayList<Integer> temp_asset_list = new ArrayList<>();
		HashMap<String, Object> filter = new HashMap<>();
		HashMap<String, String> preference_map = new HashMap<>();
		List<TransitportAssetsModel> assetList = new ArrayList<TransitportAssetsModel>();
		List<TransitportAssetAvailabilityModel> availabilities = new ArrayList<TransitportAssetAvailabilityModel>();
		List<MerchantConfigPreferencesModel> preferencesList = new ArrayList<MerchantConfigPreferencesModel>();
		String multi_asset_id = model.getMulti_asset_id();
		logger.info("Request Asset ID : " + multi_asset_id);
		try {
			try {
				filter.put("merchantId", model.getMerchant_id());
				preferencesList = payerServices.getMerchantPreferencesList("merchant_id", model.getMerchant_id());
				logger.info("Merchant Preferences Details :: "+preferencesList.get(0).getParameter_value()+" & Param Name : "+preferencesList.get(0).getParameter_value());
				if (preferencesList.size() > 0 || preferencesList != null) {
					for (int i = 0; i < preferencesList.size(); i++) {
						preference_map.put(preferencesList.get(i).getLookupPramMOdel().getParameter_name(),
								preferencesList.get(i).getParameter_value());
						
					
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				logger.info("Exception Occur During the Preferences :: "+e.getMessage());
			}

			StringTokenizer st = new StringTokenizer(multi_asset_id, ".");
			
			while (st.hasMoreElements()) {
				logger.info("Asset ID After the Tokenizer " + st.nextElement().toString());
				try {
					temp_asset_list.add(Integer.parseInt(st.nextElement().toString()));
				} catch (Exception e) {
					// TODO: handle exception.
					statusMsg = "For the given Request Attribute Reservation doesn't Exist!!!";
					status = "Fail";
					statusCode = "999";
					logger.info("Exception While Cancelling Reservation " + e.getMessage());
					returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode
							+ "\",\"Status Msg\":\"" + statusMsg + "\"}";
					e.printStackTrace();
				}
				logger.info("Temp Asset List Size : " + temp_asset_list.size());
			}
			if (temp_asset_list.size() > 0) {
				logger.info("Temp Asset List size is >0 so asset id i am putting into map ::::::::::::::");
				filter.put("assets_id", temp_asset_list);
				assetList = payerServices.getAssetsDetails(filter);
				logger.info("Asset List size is ::::: " + assetList.size());
				try {
					availabilities = getAvailableDates(assetList,
							(Date) session.getAttribute("reSecheduledReservationDateFrom"),
							(Date) session.getAttribute("reSecheduledReservationDateTo"));
					logger.info("Avaibalities is : " + availabilities.size());
				} catch (Exception e) {
					// TODO: handle exception

					logger.info("Exception Avaibalities : " + e.getMessage());
					statusMsg = "For the given Request Attribute Reservation doesn't Exist!!!";
					status = "Fail";
					statusCode = "999";
					logger.info("Exception While Cancelling Reservation " + e.getMessage());
					returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode
							+ "\",\"Status Msg\":\"" + statusMsg + "\"}";
				}
				for (TransitportAssetAvailabilityModel availabilityModelIt : availabilities) {
					logger.info("Interating Availabilities & getting the Asset ID Here : "
							+ availabilityModelIt.getAsset_id());
					TransitportAssetsModel asset = new TransitportAssetsModel();
					asset = payerServices.getAssetReservationDetailsByID(availabilityModelIt.getAsset_id());
					amount = amount + Float.parseFloat(asset.getBooking_charges());
				}
				TransitportAssetReservationsModel reservationModel = new TransitportAssetReservationsModel();
				// reservationModel=payerServices.getReservationDetailsByID(model.getReservation_id());
				reservationModel = (TransitportAssetReservationsModel) session
						.getAttribute("reSecheduledReservationModel");
				reservationModel.setReservationDateFrom((Date) session.getAttribute("reservationDateFrom"));
				reservationModel.setReservationDateTo((Date) session.getAttribute("reservationDateTo"));
				reservationModel
						.setMulti_availability_data(new HashSet<TransitportAssetAvailabilityModel>(availabilities));
				// reservationModel.setAsset_category_id(Integer.valueOf(session.getAttribute("sesCategory_id").toString()));
				// reservationModel.setAsset_type_id(Integer.valueOf(session.getAttribute("sesType_id").toString()));
				reservationModel.setAsset_ids(multi_asset_id.substring(1, multi_asset_id.length()));
				reservationModel.setStatus("RESCHEDULE");
				logger.info("Checking Merchant Preferences "+preference_map.get("IS_RESCHEDULE_CHARGES"));
				if (preference_map.get("IS_RESCHEDULE_CHARGES")!=null&&preference_map.get("IS_RESCHEDULE_CHARGES").equalsIgnoreCase("Y")) {
					logger.info("Checking Merchant Preferences for Reschedule Charges is applicable :: ");
				}
				reservationModel = payerServices.updateRescheduleAssetReservation(reservationModel);
				statusMsg = "Reservation Rescheduled Success!!!";
				status = "SUCCESS";
				statusCode = "200";

				returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode + "\",\"Status Msg\":\""
						+ statusMsg + "\"}";
			} else {
				statusMsg = "No Asset Found!!!";
				status = "FAIL";
				statusCode = "300";

				returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode + "\",\"Status Msg\":\""
						+ statusMsg + "\"}";
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			statusMsg = "For the given Request Attribute Reservation doesn't Exist!!!";
			status = "Fail";
			statusCode = "999";
			logger.info("Exception While Cancelling Reservation " + e.getMessage());
			returnStatus = "{\"Status\":\"" + status + "\",\"Status Code\":\"" + statusCode + "\",\"Status Msg\":\""
					+ statusMsg + "\"}";
		}
		return returnStatus;
	}

	private List<TransitportAssetAvailabilityModel> getAvailableDates(List<TransitportAssetsModel> assetList,
			Date dateFrom, Date DateTo) {
		List<TransitportAssetAvailabilityModel> availabilityList = new ArrayList<TransitportAssetAvailabilityModel>();
		logger.info("To Date : " + DateTo + " & From Date : " + dateFrom);
		int no_of_days = differanceDate(DateTo, dateFrom) + 1;
		logger.info("Number Of Days :: " + no_of_days + " & Asset Size : " + assetList.size());
		try {
			for (TransitportAssetsModel assetModelIt : assetList) {
				logger.info("Asset ::::::::::::::: " + assetModelIt.getAvailability().size());
				Date _date = dateFrom;
				logger.info("Checking availabilty for " + _date.toString());
				List<TransitportAssetAvailabilityModel> _availabilities = new ArrayList<TransitportAssetAvailabilityModel>();
				List<TransitportAssetAvailabilityModel> sort_availabilities = new ArrayList<TransitportAssetAvailabilityModel>();
				if (assetModelIt.getAvailability().size() > 0) {
					for (Iterator iterator = assetModelIt.getAvailability().iterator(); iterator.hasNext();) {
						TransitportAssetAvailabilityModel tempAvailModel = (TransitportAssetAvailabilityModel) iterator
								.next();
						sort_availabilities.add(tempAvailModel);
					}
					Collections.sort(sort_availabilities, new Comparator<TransitportAssetAvailabilityModel>() {
						@Override
						public int compare(TransitportAssetAvailabilityModel o1, TransitportAssetAvailabilityModel o2) {
							return o1.getDate_available().compareTo(o2.getDate_available());
						}
					});
				}

				for (TransitportAssetAvailabilityModel obj : sort_availabilities) {
					Date db_scope_date = null;
					try {
						db_scope_date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
								.parse(obj.getScope_date().concat(" 00:00:00"));
					} catch (java.text.ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					logger.info("db_scope_date " + db_scope_date + " & Date " + _date);
					if ((db_scope_date.after(_date) || db_scope_date.equals(_date))
							&& (db_scope_date.equals(DateTo) || db_scope_date.before(DateTo))
							&& obj.getStatus().contentEquals("open")) {
						logger.info("Date Available=" + db_scope_date);
						_availabilities.add(obj);

					} else {
						logger.info("Esc Date =" + db_scope_date);
					}
				}
				logger.info("Asset ID::::" + assetModelIt.getAsset_id() + ":No of Days:::" + no_of_days + "::::::: "
						+ _availabilities.size());
				if (no_of_days > _availabilities.size()) {
					logger.info("continuity = false->" + _date.toString());

				} else {
					logger.info("continuity = true->" + _date.toString());
					availabilityList.addAll(_availabilities);

				}

			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Exception During to Saving Asset Reschedule : " + e.getMessage());
		}

		return availabilityList;
	}

}
