package com.payplatterservice.controller;

import java.io.Serializable;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.payplatterservice.model.MerchantsModel;
import com.payplatterservice.operationservice.CouplingOperationServices;
import com.payplatterservice.service.CouplingProjectService;
import com.payplatterservice.service.LoginService;
import com.payplatterservice.service.TransactionsService;

@RestController
public class CouplingProjectController implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(CouplingProjectController.class);
	
	@Autowired
	TransactionsService services;
	
	@Autowired
	LoginService loginservices;
	
	@Autowired
	CouplingProjectService couplingServices;
	
	
	@Autowired
	CouplingOperationServices couplingOperServices;
	
	
	// Ravi: 23-04-2018 For WellnessPort - PayPlatter coupling project Controller & Request Body Here
	
	@RequestMapping(value="/onBoardMerchant/",method=RequestMethod.POST,produces="application/json")
	public String onBoardMerchant(@RequestBody MerchantsModel model,UriComponentsBuilder ucBuilder){
		String returnStatus=couplingOperServices.isMerchantExist(model);
		return returnStatus;
	}
	

}
