package com.payplatterservice.security;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;


public class EncDescClass {

	
	public static void main(String[] args) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		
		
		
	
	String txnID="PPL017N21032018YE18180001145085612";
	String txnAmount="500";
	String txnCompliteDate="2018-03-21 14:17:29";
	String payAmount="500";
	String payode="NEFT ";
	String payStatus="SUCCESS";
	String RMTR_BANK_NAME="YESBank";
	String RMTR_ACCOUNT_TYPE="SA ";
	String RMTR_ACCOUNT_NUMBER="12139702361";
	String RMTR_FULL_NAME="Ravi Shankar";
	String RMTR_ACCOUNT_IFSC="YSB128";
	String BENE_FULL_NAME="Avinash";
	String BENE_ACCOUNT_TYPE="SA";
	String VIRTUAL_ACCOUNT_NO="PPL017N21032018YE18180001145085612";
	String BENE_ACCOUNT_NO="4545445";
	String BENE_ACCOUNT_IFSC="SBI1239";
	String BENE_Bank_Name="SBI";


		String paramValue = txnID.trim() + "|" + txnAmount.trim() + "|" + txnCompliteDate.trim() + "|"
				+ payAmount.trim() + "|" + payode.trim() + "|" + payStatus + "|" + RMTR_BANK_NAME + "|"
				+ RMTR_ACCOUNT_TYPE + "|" + RMTR_ACCOUNT_NUMBER + "|" + RMTR_FULL_NAME + "|" + RMTR_ACCOUNT_IFSC + "|"
				+ BENE_FULL_NAME + "|" + BENE_ACCOUNT_TYPE + "|" + VIRTUAL_ACCOUNT_NO + "|" + BENE_ACCOUNT_NO + "|"
				+ BENE_ACCOUNT_IFSC + "|" + BENE_Bank_Name;
		
		/*String tokenNO="PPL017N21032018YE18180001145085612";
		String txnAmt="500";
		String mobNo="124165465";
		String txnDate="2018-03-21 12:04:30";
		
		String paramValue = tokenNO.trim() + "|" + txnAmt.trim() + "|" + mobNo.trim() + "|" + txnDate.trim();*/
		
		Encryption encCode = new Encryption();
		System.out.println(encCode.encrypt("zcjrujdGPEqqBYHG", "DNmnGWhWeaj9wG6f", paramValue));;
		
		/*String tokenNO="PPL017N522012018YE181800011765";
		String txnAmt="230";
		String mobNo="124165465";
		String txnDate="2018-02-01 16:12:44";
		
		//String paramValue = tokenNO.trim() + "|" + txnAmt.trim() + "|" + mobNo.trim() + "|" + txnDate.trim();
		
		//String paramValue="/dMv1pyMGZC/hhqpV9LEHpKTTkLVuUItNB8RXBD8KmXpw75VO+fPo3IWLbYRfCM6/o4jY5swQGI+\nD1bwlVF+3A==";
		
		String paramValue="f0ev5PgcBovbK9TbOfwBHIQUEQ9Sf/kE0LKUvYVs2djv6FT0snEXp3/eWnbdHBKY0BA/9+v7Hd80KroJlCXvUcwxLxAPVEy3WPaQZaRIpx7Uxst+z3GEOk7l6d+VqXz4rVHorS+lIFOp7YTiP3tl8UlMLYzKMEpEIB50Ql+8MhyXiSUnht4+euE9Mz/E+9+oedRIE/TvlQ1y58nrzeVyOFG/9H6aUX2sHzuK7aeNnyBbEHPcb26tXfkWqdX+TxMLLDCH8FYdX20kvGDdmESBHhE7vfqLznWjz7KSJva+3CF+gYGKE8vPv+4zLkk9mu8gux1WN/W+FgBJF9T8ZXxaeg==";
		Encryption encCode = new Encryption();
		//System.out.println("Enc Value : "+encCode.encrypt("zcjrujdGPEqqBYHG", "DNmnGWhWeaj9wG6f", paramValue));
		paramValue=encCode.decrypt("zcjrujdGPEqqBYHG", "DNmnGWhWeaj9wG6f", paramValue);
		String result = paramValue.replaceAll("[\\-\\+\\.\\/^:,!@#&*()_{}<>?\"\']","");
		result = result.replaceAll("\\\\", "NA");
		
		System.out.println("Enc Value : "+result.trim());*/
	}
	
	// UAT :::: 2789913121705593832517881
	
/*	String txnID="PPL017N03022018YE18180004030218014";
	String txnAmount="896 ";
	String txnCompliteDate="2018-02-01 14:10:28";
	String payAmount="230";
	String payode="NEFT ";
	String payStatus="SUCCESS";
	String RMTR_BANK_NAME="YESBank";
	String RMTR_ACCOUNT_TYPE="SA ";
	String RMTR_ACCOUNT_NUMBER="12139702361";
	String RMTR_FULL_NAME="Ravi Shankar";
	String RMTR_ACCOUNT_IFSC="YSB128";
	String BENE_FULL_NAME="Avinash";
	String BENE_ACCOUNT_TYPE="SA";
	String VIRTUAL_ACCOUNT_NO="34344673434";
	String BENE_ACCOUNT_NO="4545445";
	String BENE_ACCOUNT_IFSC="SBI1239";
	String BENE_Bank_Name="SBI";
	
	
	2nd 
	
	
	String txnID="0842013121704174919894782";
		String txnAmount="1200";
		String txnCompliteDate="2017-12-13 16:57:49";
		String payAmount="1200";
		String payode="NEFT ";
		String payStatus="SUCCESS";
		String RMTR_BANK_NAME="HDFC";
		String RMTR_ACCOUNT_TYPE="SA ";
		String RMTR_ACCOUNT_NUMBER="121313212131";
		String RMTR_FULL_NAME="Ravi Shankar";
		String RMTR_ACCOUNT_IFSC="HDFC123";
		String BENE_FULL_NAME="Avinash";
		String BENE_ACCOUNT_TYPE="SA";
		String VIRTUAL_ACCOUNT_NO="34344343434";
		String BENE_ACCOUNT_NO="4545445";
		String BENE_ACCOUNT_IFSC="SBI1230";
		String BENE_Bank_Name="SBI";
	
	
	String paramValue = txnID.trim() + "|" + txnAmount.trim() + "|" + txnCompliteDate.trim() + "|"
			+ payAmount.trim() + "|" + payode.trim() + "|" + payStatus + "|" + RMTR_BANK_NAME + "|"
			+ RMTR_ACCOUNT_TYPE + "|" + RMTR_ACCOUNT_NUMBER + "|" + RMTR_FULL_NAME + "|" + RMTR_ACCOUNT_IFSC + "|"
			+ BENE_FULL_NAME + "|" + BENE_ACCOUNT_TYPE + "|" + VIRTUAL_ACCOUNT_NO + "|" + BENE_ACCOUNT_NO + "|"
			+ BENE_ACCOUNT_IFSC + "|" + BENE_Bank_Name;
	
	
	
	// UAT 
	 * 
	 * String tokenNO="6889801021802101878849780";
		String txnAmt="230";
		String mobNo="9762276139";
		String txnDate="2018-01-22 13:31:22";
		String paramValue = tokenNO.trim() + "|" + txnAmt.trim() + "|" + mobNo.trim() + "|" + txnDate.trim();
	
	
	String tokenNO="0842013121704174919894782";
	String txnAmt="1200";
	String mobNo="7040047758";
	String txnDate="2017-12-13 16:17:49";
	String paramValue = tokenNO.trim() + "|" + txnAmt.trim() + "|" + mobNo.trim() + "|" + txnDate.trim();
*/
	
	
/*	String txnID="9045122011801312247149970";
	String txnAmount="230";
	String txnCompliteDate="2018-01-22 14:31:22";
	String payAmount="230";
	String payode="NEFT ";
	String payStatus="SUCCESS";
	String RMTR_BANK_NAME="YESBank";
	String RMTR_ACCOUNT_TYPE="SA ";
	String RMTR_ACCOUNT_NUMBER="12139702361";
	String RMTR_FULL_NAME="Ravi Shankar";
	String RMTR_ACCOUNT_IFSC="YSB128";
	String BENE_FULL_NAME="Avinash";
	String BENE_ACCOUNT_TYPE="SA";
	String VIRTUAL_ACCOUNT_NO="34344673434";
	String BENE_ACCOUNT_NO="4545445";
	String BENE_ACCOUNT_IFSC="SBI1239";
	String BENE_Bank_Name="SBI";
	String paramValue = txnID.trim() + "|" + txnAmount.trim() + "|" + txnCompliteDate.trim() + "|"
			+ payAmount.trim() + "|" + payode.trim() + "|" + payStatus + "|" + RMTR_BANK_NAME + "|"
			+ RMTR_ACCOUNT_TYPE + "|" + RMTR_ACCOUNT_NUMBER + "|" + RMTR_FULL_NAME + "|" + RMTR_ACCOUNT_IFSC + "|"
			+ BENE_FULL_NAME + "|" + BENE_ACCOUNT_TYPE + "|" + VIRTUAL_ACCOUNT_NO + "|" + BENE_ACCOUNT_NO + "|"
			+ BENE_ACCOUNT_IFSC + "|" + BENE_Bank_Name;
	
	*/
	
	
}
