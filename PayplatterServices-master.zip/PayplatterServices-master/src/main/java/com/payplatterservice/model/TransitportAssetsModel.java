package com.payplatterservice.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.ManyToAny;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;


@Entity
@Table(name = "transitport_assets")
public class TransitportAssetsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer asset_id;
	private String asset_name;
	private Integer merchant_id;
	private String asset_type;
	private String phone,email,booking_charges, booking_purpose;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer asset_capacity_adult,assest_capacity_minor;
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer asset_category_id;
	@Transient
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer reservation_id;
	@Transient
	@JsonSerialize(using=ToStringSerializer.class)
	private Integer availability_id;
	
	@OneToMany(cascade = CascadeType.ALL,fetch=FetchType.EAGER,orphanRemoval = true,mappedBy="asset_id")
	private Set<TransitportAssetAvailabilityModel>availability=new HashSet<TransitportAssetAvailabilityModel>();
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="asset_type_lookup_id", referencedColumnName="asset_type_id")
	private TransitportAssetTypeLookup assetTypeLookup;
	
	@Transient
	private String multi_asset_id;
	/*@JoinColumn(name = "pgId_Fk", referencedColumnName = "id")
	private PaymentProcessorModel paymentProcessorBean;*/
	
	public Integer getAsset_id() {
		return asset_id;
	}
	public void setAsset_id(Integer asset_id) {
		this.asset_id = asset_id;
	}
	public String getAsset_name() {
		return asset_name;
	}
	public void setAsset_name(String asset_name) {
		this.asset_name = asset_name;
	}
	public Integer getMerchant_id() {
		return merchant_id;
	}
	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}
	public String getAsset_type() {
		return asset_type;
	}
	public void setAsset_type(String asset_type) {
		this.asset_type = asset_type;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBooking_charges() {
		return booking_charges;
	}
	public void setBooking_charges(String booking_charges) {
		this.booking_charges = booking_charges;
	}
	public String getBooking_purpose() {
		return booking_purpose;
	}
	public void setBooking_purpose(String booking_purpose) {
		this.booking_purpose = booking_purpose;
	}
	public Integer getAsset_capacity_adult() {
		return asset_capacity_adult;
	}
	public void setAsset_capacity_adult(Integer asset_capacity_adult) {
		this.asset_capacity_adult = asset_capacity_adult;
	}
	public Integer getAssest_capacity_minor() {
		return assest_capacity_minor;
	}
	public void setAssest_capacity_minor(Integer assest_capacity_minor) {
		this.assest_capacity_minor = assest_capacity_minor;
	}
	public Integer getAsset_category_id() {
		return asset_category_id;
	}
	public void setAsset_category_id(Integer asset_category_id) {
		this.asset_category_id = asset_category_id;
	}
	public Set<TransitportAssetAvailabilityModel> getAvailability() {
		return availability;
	}
	public void setAvailability(Set<TransitportAssetAvailabilityModel> availability) {
		this.availability = availability;
	}
	public Integer getReservation_id() {
		return reservation_id;
	}
	public void setReservation_id(Integer reservation_id) {
		this.reservation_id = reservation_id;
	}
	public Integer getAvailability_id() {
		return availability_id;
	}
	public void setAvailability_id(Integer availability_id) {
		this.availability_id = availability_id;
	}
	public TransitportAssetTypeLookup getAssetTypeLookup() {
		return assetTypeLookup;
	}
	public void setAssetTypeLookup(TransitportAssetTypeLookup assetTypeLookup) {
		this.assetTypeLookup = assetTypeLookup;
	}
	public String getMulti_asset_id() {
		return multi_asset_id;
	}
	public void setMulti_asset_id(String multi_asset_id) {
		this.multi_asset_id = multi_asset_id;
	}
	
	
	
}
