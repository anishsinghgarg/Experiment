package com.payplatterservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "context_venue_appointment")
public class VenueAppointmentModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@GenericGenerator(name = "g1", strategy = "increment")
	@Id
	@GeneratedValue(generator = "g1")
	private Integer contextDataId;
	private Integer asset_id;
	private String appointmentDate;
	private String start_time, end_time;
	private Integer availabilty_id;
	private Integer form_instance_id;
	@Column(name = "status", updatable = false, nullable = false, columnDefinition = "VARCHAR (20) default 'pending'")
	private String status;
	
	@Transient
	private TransitportAssetsModel assetData;

	public Integer getContextDataId() {
		return contextDataId;
	}

	public void setContextDataId(Integer contextDataId) {
		this.contextDataId = contextDataId;
	}

	public Integer getAsset_id() {
		return asset_id;
	}

	public void setAsset_id(Integer asset_id) {
		this.asset_id = asset_id;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getEnd_time() {
		return end_time;
	}

	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

	public Integer getAvailabilty_id() {
		return availabilty_id;
	}

	public void setAvailabilty_id(Integer availabilty_id) {
		this.availabilty_id = availabilty_id;
	}

	public Integer getForm_instance_id() {
		return form_instance_id;
	}

	public void setForm_instance_id(Integer form_instance_id) {
		this.form_instance_id = form_instance_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public TransitportAssetsModel getAssetData() {
		return assetData;
	}

	public void setAssetData(TransitportAssetsModel assetData) {
		this.assetData = assetData;
	}

}
